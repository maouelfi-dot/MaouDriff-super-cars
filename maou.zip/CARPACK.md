# Carpack Maou Drift

Tambah mobil **tanpa mengubah mod utama**: cukup taruh file `.zip` di

    config/maoudrift/carpacks/

(folder dibuat otomatis saat game pertama dijalankan). Semua zip/folder di situ dipasang otomatis sebagai
resource pack **dan** data pack, selalu aktif, tidak perlu dipilih di menu. Setelah menaruh zip: restart game atau tekan **F3+T**.

## Isi zip

    pack.mcmeta
    assets/<namespace>/vehicles/<id>.json        <- definisi tampilan (model, tekstur, cat, suara, kursi)
    assets/<namespace>/models/entity/<id>.obj    <- model badan (+ .mtl)
    assets/<namespace>/models/entity/wheel_<id>.obj
    assets/<namespace>/textures/entity/<id>.png  <- tekstur (+ <id>_s.png untuk PBR labPBR di shader)
    assets/<namespace>/car_parts/wheel_<id>.json <- velg
    assets/<namespace>/lang/en_us.json           <- nama mobil (car.<ns>.<id>, item.<ns>.<id>, entity.<ns>.<id>)
    assets/<namespace>/sounds.json + sounds/*.ogg  <- (opsional) suara tambahan
    data/<namespace>/cars/<id>.json              <- fisika (massa, torsi, wheelbase, ...)

`pack.mcmeta`:

    {"pack":{"pack_format":34,"supported_formats":{"min_inclusive":34,"max_inclusive":99},"description":"Nama pack"}}

Format `vehicles/*.json` dan `cars/*.json` sama persis dengan mobil bawaan mod (lihat contoh di
`core/src/main/resources/assets/maoudrift/vehicles/` dan `.../data/maoudrift/cars/`).

## Suara mesin
`sounds.engine.type` di vehicles json memilih jenis suara mesin sintetis bawaan:
`i4_turbo, i4, i6, flat6, v8, diesel4, supra2jz, bmw_s55, bmw_n55, bmw_m4_akrapovic`.
(Jenis suara mesin yang benar-benar baru tetap perlu ditambahkan ke mod.)

## Membuat carpack dari model FBX
1. Konversi: `blender -b --python tools/forza_fbx_to_maou.py -- <kunci> <folder_keluar>` (tambahkan entri mobil di `CARS`).
2. Bungkus: `python3 tools/make_carpack.py <folder_keluar> <id> "<Nama>" <namespace> hasil.zip supra2jz 1480`
3. Taruh `hasil.zip` di `config/maoudrift/carpacks/`.

## Catatan
- Server dedicated: taruh zip yang sama di `config/maoudrift/carpacks/` server (untuk data fisika) dan di klien (untuk model/suara).
- Satu carpack rusak hanya dilewati dan dicatat di log; game tetap jalan.
