# Maou Drift 1.2.0

Turunan **KurumaMod** (Deexel, GPL-3.0-only). Fabric 1.21.1. Kode, lisensi, dan hak cipta asli dipertahankan (lihat `LICENSE`, `NOTICE.md`).

## Mobil (4)
| ID | Mobil | Catatan |
|---|---|---|
| `maoudrift:car` (bawaan) | Toyota Supra MK IV (F&F) | dioptimalkan: 47,8 rb -> 36,7 rb segitiga, bentuk sama (hanya poligon sebidang dibuang) |
| `maoudrift:krc_supra` | Toyota Supra JZA80 KRC Widebody (2018) | ~37 rb segitiga, atlas 2048x1024 (HD), 9 warna cat, stir berputar |
| `maoudrift:zacoe_m2` | BMW M2 G87 Zacoe Widebody (2024) | ~47 rb segitiga, 9 pilihan warna cat |
| `maoudrift:varis_gts` | Varis M4 GTS (2019, livery asli) | ~51 rb segitiga |

BMW M3 GT3 dan BMW M4 F82 lama sudah dihapus.
Semua mobil: badan + interior + kaca (tembus pandang) + lampu depan/belakang + pintu kiri/kanan & kap mesin yang bisa dibuka + velg sendiri + tabrakan padat + lampu bawah (ungu).

## Kilap
* Tekstur warna **tanpa kilap palsu**. Opsi "kilap tanpa shader" sudah dihapus.
* Kilap/logam hanya muncul lewat peta `*_s.png` (labPBR: R = smoothness, G = F0/logam). Aktifkan shader pack (Iris) yang mendukung **labPBR/PBR** dan nyalakan opsinya.

## HUD
Memakai HUD asli KurumaMod (speedometer/tachometer bulat). Hotbar disembunyikan saat di dalam mobil.

## Build (tanpa PC)
Upload seluruh isi folder ke repo GitHub -> tab Actions -> unduh artifact `maoudrift-fabric-1.21.1-1.2.0.jar` (bukan `-sources`).
Butuh Fabric API. Untuk shader: Sodium + Iris.

## Konverter (menambah mobil)
`tools/forza_fbx_to_maou.py <kunci> <folder>` (Python 3.11, `pip install bpy pillow numpy`): FBX rip game -> badan, kaca, lampu, pintu/kap,
atlas tekstur asli (bake), peta labPBR, velg, JSON. Tambahkan entri di dict `CARS` (lokasi FBX, wheelbase asli).
`tools/supra_optimize.py`: kurangi poligon OBJ tanpa mengubah bentuk. `tools/maou_car_export.py`: konverter lama (blend/fbx).
Setelah menaruh hasil di `assets/maoudrift/...` dan membuat JSON (lihat contoh `vehicles/varis_m4.json`, `data/maoudrift/cars/varis_m4.json`), tekan F3+T.

## Perubahan 1.3.0
* Stir untuk Varis M4 / Varis GTS / Zacoe M2 (sebelumnya hanya Supra yang punya objek `steering_wheel`, jadi tangan pengemudi tidak muncul). Posisi bisa disetel di game dengan Ctrl+G.
* Ikon mobil statis (`textures/item/icon_*.png`) lewat kunci `icon` di `vehicles/*.json`: tab Creative tidak lagi merender mobil 3D (penyebab lag/FC).
* Turun dari mobil: pemain diturunkan di samping pintu, bukan di atas kotak tabrakan (tidak nyangkut di kap).
* Pintu otomatis terbuka lalu menutup saat naik/turun.
* Kotak tabrakan mengikuti tinggi kap/kabin/bagasi (kaki pemain tidak melayang di kap).
* Suara tiap mobil berbeda (tipe mesin, nada, turbo/blowoff/shift lewat `sounds` di JSON).
* Peta kilap `*_s.png` dinaikkan (smoothness tinggi, F0 lebih kuat) untuk shader yang membaca PBR pada entitas.
* Suara Supra: tipe mesin `supra2jz` dibuat dari sampel 2JZ-GTE (readme sumber: jangan di-reupload tanpa izin pembuatnya; cek izin sebelum membagikan mod).

## Perubahan 1.3.1 (suara mesin BMW asli)
Tiga mobil BMW sekarang memakai rekaman mesin sungguhan (bukan sintetis), tipe di `sounds.engine.type`:
| Mobil | Tipe suara | Sumber |
|---|---|---|
| `maoudrift:varis_m4` | `bmw_s55` | S55B30 (BMW M2-3-4 N/S55 Engine Sound Pack) |
| `maoudrift:varis_gts` | `bmw_m4_akrapovic` | BMW M4 Akrapovic Sound (Legacy DMC) |
| `maoudrift:zacoe_m2` | `bmw_n55` | N55B30T0 (BMW M2-3-4 N/S55 Engine Sound Pack) |
Tiap tipe punya 10 loop (900/1600/2800/4500/7000 rpm x lift/load), mono 48 kHz, bisa di-loop mulus.
Nada diratakan ke rpm tiap pita (6 silinder, f = rpm/20); pita 4500 dan 7000 rpm diperoleh dengan menaikkan nada rekaman
(sapuan rev aslinya hanya sampai sekitar 3.100-3.600 rpm), jadi terdengar sedikit lebih tipis di putaran tinggi.
Lift untuk `bmw_s55` dan pita tertentu dibuat dari loop load (rekaman decel-nya tidak bisa dipakai). Pitch/load tiap mobil direset ke 1.0.
Konverter: `tools/awc_to_engine.py <file.awc> <tipe> <folder_keluar>`. Mobil mana pun bisa pakai tipe-tipe ini lewat `sounds.engine.type`.
Catatan: "BMW M4 New Sound" tidak berisi audio (hanya `vehicles.meta` yang menunjuk suara bawaan GTA V `feltzer3`), jadi tidak bisa dikonversi.


## Perubahan 1.4.0
* Varis M4 (BMW) diganti Toyota Supra JZA80 KRC Widebody (`krc_supra`): pintu/kap bisa dibuka, stir, velg, lampu, suara 2JZ.
* Lampu kolong (underglow) baru: warna per mobil di `config/maoudrift-underglow.toml` (dibuat otomatis, dibaca ulang saat diubah). Hanya terlihat saat gelap, lembut, tanpa shader khusus.
* Sorot lampu depan (tombol L) versi ringan: pola cahaya di jalan sepanjang ~58 m mengikuti tanah + seberkas tipis; siang hari tidak digambar.
* Pintu & kap KRC kini memakai potongan asli model (bukan potongan kotak), jadi tepinya mulus saat dibuka. Konverter `tools/forza_fbx_to_maou.py` ikut diperbarui (hanya mobil yang dikonversi ulang dari FBX yang terpengaruh).
* Pintu & kap Supra, Zacoe M2, dan Varis GTS juga dipotong ulang mengikuti komponen asli model (`tools/resplit_panels.py in.obj out.obj [crease]`), bukan lagi kotak kasar.
* Supra lama: kap tidak lagi terangkat terlalu tinggi (faces liar dipindah ke badan) dan serpihan biru (material Grille3A di bawah kap) dibuang. KRC: kaca samping kini ikut pintu (`tools/fixup_panels.py`).

## Perubahan 1.5.0
* **Carpack**: taruh `.zip` di `config/maoudrift/carpacks/` untuk menambah mobil tanpa mengubah mod (lihat `CARPACK.md`, alat `tools/make_carpack.py`).
* Stir semua mobil diganti stir halus berlingkar penuh (Supra lama sebelumnya hanya busur atas). Poros putar dihitung dari bentuk stir, jadi tangan pengemudi mengikuti.
* Perbaikan UV area cat polos (garis hitam/"barcode" di tepi tile), KRC default hitam.
* Atlas tekstur dipangkas ke bagian yang dipakai (tanpa mengubah tampilan/resolusi): Zacoe -62%, GTS -24%, KRC -25%, Supra -11% memori GPU.
