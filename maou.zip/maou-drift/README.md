# Maou Drift 1.2.0

Turunan **KurumaMod** (Deexel, GPL-3.0-only). Fabric 1.21.1. Kode, lisensi, dan hak cipta asli dipertahankan (lihat `LICENSE`, `NOTICE.md`).

## Mobil (4)
| ID | Mobil | Catatan |
|---|---|---|
| `maoudrift:car` (bawaan) | Toyota Supra MK IV (F&F) | dioptimalkan: 47,8 rb -> 36,7 rb segitiga, bentuk sama (hanya poligon sebidang dibuang) |
| `maoudrift:varis_m4` | Varis M4 Widebody (2015) | ~44 rb segitiga, 9 pilihan warna cat |
| `maoudrift:zacoe_m2` | BMW M2 G87 Zacoe Widebody (2024) | ~47 rb segitiga, 9 pilihan warna cat |
| `maoudrift:varis_gts` | Varis M4 GTS (2019, livery asli) | ~51 rb segitiga |

BMW M3 GT3 dan BMW M4 F82 lama sudah dihapus.
Semua mobil: badan + interior + kaca (tembus pandang) + lampu depan/belakang + pintu kiri/kanan & kap mesin yang bisa dibuka + velg sendiri + tabrakan padat + lampu bawah (ungu).

## Kilap
* Tekstur warna **tanpa kilap palsu**. Opsi "kilap tanpa shader" sudah dihapus.
* Kilap/logam hanya muncul lewat peta `*_s.png` (labPBR: R = smoothness, G = F0/logam). Aktifkan shader pack (Iris) yang mendukung **labPBR/PBR** dan nyalakan opsinya.

## HUD
Memakai HUD asli KurumaMod (speedometer/tachometer bulat). Hotbar disembunyikan saat di dalam mobil.

## Build (tanpa PC)
Upload seluruh isi folder ke repo GitHub -> tab Actions -> unduh artifact `maoudrift-fabric-1.21.1-1.2.0.jar` (bukan `-sources`).
Butuh Fabric API. Untuk shader: Sodium + Iris.

## Konverter (menambah mobil)
`tools/forza_fbx_to_maou.py <kunci> <folder>` (Python 3.11, `pip install bpy pillow numpy`): FBX rip game -> badan, kaca, lampu, pintu/kap,
atlas tekstur asli (bake), peta labPBR, velg, JSON. Tambahkan entri di dict `CARS` (lokasi FBX, wheelbase asli).
`tools/supra_optimize.py`: kurangi poligon OBJ tanpa mengubah bentuk. `tools/maou_car_export.py`: konverter lama (blend/fbx).
Setelah menaruh hasil di `assets/maoudrift/...` dan membuat JSON (lihat contoh `vehicles/varis_m4.json`, `data/maoudrift/cars/varis_m4.json`), tekan F3+T.
