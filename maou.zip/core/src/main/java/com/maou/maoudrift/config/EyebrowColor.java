package com.maou.maoudrift.config;

/**
 * Pilihan warna lampu alis. {@link #CUSTOM} memakai nilai R/G/B dari config
 * ({@code eyebrowRed/Green/Blue}). Disimpan dengan nama.
 */
public enum EyebrowColor {

    WHITE(1.0F, 1.0F, 1.0F),
    ICE(0.55F, 0.85F, 1.0F),
    RED(1.0F, 0.10F, 0.10F),
    ORANGE(1.0F, 0.50F, 0.05F),
    YELLOW(1.0F, 0.88F, 0.20F),
    GREEN(0.15F, 1.0F, 0.35F),
    PURPLE(0.65F, 0.25F, 1.0F),
    PINK(1.0F, 0.25F, 0.65F),
    /** Warna bebas dari slider R/G/B. */
    CUSTOM(1.0F, 1.0F, 1.0F);

    private final float[] rgb;

    EyebrowColor(float r, float g, float b) {
        this.rgb = new float[] {r, g, b};
    }

    /** Warna preset. Jangan diubah isinya (array dipakai bersama). Untuk CUSTOM isinya diabaikan. */
    public float[] rgb() {
        return rgb;
    }

    /** Kunci terjemahan. */
    public String translationKey() {
        return "screen.maoudrift.eyebrow.color." + name().toLowerCase(java.util.Locale.ROOT);
    }
}
