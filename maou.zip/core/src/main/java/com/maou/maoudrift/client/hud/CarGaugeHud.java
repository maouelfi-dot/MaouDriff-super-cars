package com.maou.maoudrift.client.hud;

import com.maou.maoudrift.client.ui.GaugeShapes;
import com.maou.maoudrift.client.ui.ScreenStyle;
import com.maou.maoudrift.client.ui.UiFont;
import com.maou.maoudrift.client.ui.UiGraphics;
import com.maou.maoudrift.race.RaceText;
import com.maou.maoudrift.util.Mth;
import com.maou.maoudrift.config.ClientConfig;
import com.maou.maoudrift.config.GaugeTheme;
import com.maou.maoudrift.config.SpeedUnit;
import com.maou.maoudrift.physics.CarInput;
import com.maou.maoudrift.physics.CarSpec;
import com.maou.maoudrift.client.CarClient;
import com.maou.maoudrift.client.race.RaceClient;

/**
 * 90 年代の国産スポーツの純正メーターに寄せた 2 眼の計器。
 * <b>左に回転計、右に速度計、間にシフトインジケーターとデジタル表示。</b>
 *
 * <p>数字だけの {@link CarHud} とは役目が違う。<b>あちらはセッティングを詰めるための計器で、
 * こちらは運転するための計器。</b>針は「あとどれだけ残っているか」を角度で見せるので、
 * 数字を読まずに視界の端で分かる。H でまとめて消えるのはテレメトリだけで、
 * こちらは設定（{@link ClientConfig#showGauges}）で切る。</p>
 *
 * <p><b>回転計が左、速度計が右。</b>実車の作法で、マニュアルで走るときに<b>回転計が画面の
 * 中央寄り</b>——つまり視線の近くに来る。段を自分で選ぶ以上、見る回数が多いのは回転計のほう。</p>
 *
 * <p><b>文字盤は毎フレーム諸元から組み立てる。</b>最高速もレブリミットもセッティングと
 * カーパックで変わるので、目盛りの上限を画像に焼き込むことができない。</p>
 *
 * <h2>色</h2>
 *
 * <p>色は {@link GaugeTheme} が持ち、設定で切り替える。<b>形は共通で色だけが変わる</b>ので、
 * ここには色の定数を書かない——書くと、片方のテーマだけ直したつもりが両方に効いたり、
 * 逆に片方が取り残されたりする。</p>
 *
 * <h2>線の太さ</h2>
 *
 * <p>リング・目盛り・針の太さは {@code LINE_*} にまとめてある（<b>細</b>＝0.6〜0.85 倍）。
 * <b>太さは GUI スケールで実際の画素数が変わる</b>ことに注意。1 GUI ピクセルはスケール 4 なら
 * 4 画素、スケール 1 なら 1 画素で、{@link GaugePainter} は四角形を積むだけで画素に
 * 吸着させていないので、これより細くすると小さい画面では滲んで消える。</p>
 *
 * <h2>置き場所</h2>
 *
 * <p>メーターは<b>ホットバーの左右</b>に置く。画面の下端はバニラのホットバー（182px）と
 * その上の体力・空腹バーが使っているので、そこを避けると自然に左右へ寄る——結果として
 * 実車のメーターパネルに近い並びになる。中央のデジタル表示だけは、ホットバーより上へ逃がす。</p>
 *
 * <p><b>大きさは画面の空きから決める。</b>GUI スケールを上げている人ほど画面が狭くなり、
 * 固定の大きさではホットバーや左下のテレメトリと重なる。ホットバーの左右に残っている幅に
 * 収まるところまで縮め、{@link ClientConfig#gaugeScale} で好みの倍率を掛ける。</p>
 */
public final class CarGaugeHud {

    /** メーターの外周半径（倍率 1.0 のとき）。 */
    private static final float RADIUS = 44.0F;
    /** 画面の下端との隙間。 */
    private static final float BOTTOM_MARGIN = 6.0F;
    /** バニラのホットバーの幅の半分。この外側にメーターを置く。 */
    private static final float HOTBAR_HALF_WIDTH = 91.0F;
    /** ホットバーとメーターの間隔。 */
    private static final float HOTBAR_GAP = 8.0F;
    /** 縮める下限。これより小さいと目盛りの数字が読めない。 */
    private static final float MIN_SCALE = 0.5F;
    /**
     * 倍率をこの刻みに丸める。<b>半端な倍率だとフォントが滲んで小さい文字が読めなくなる。</b>
     *
     * <p>Minecraft のフォントは 1px 単位で作られているので、0.78 倍のような端数では
     * 単位の「km/h」が潰れる（実効 427x240 の画面で実際に読めなくなった）。</p>
     */
    private static final float SCALE_STEP = 0.25F;
    /**
     * メーターの直径が画面の高さのこれを超えないようにする。前が見えなくなるため。
     *
     * <p>直径 88px は実効 480x270 の 32.6% にあたるので、ここを 0.30 にすると
     * <b>いちばん普通の画面で 0.75 倍まで縮んでしまう</b>（0.25 刻みへ切り捨てるため）。</p>
     */
    private static final float MAX_HEIGHT_FRACTION = 0.34F;

    /** 文字盤の開始角と回る量 [度]。160 度から時計回りに 220 度。<b>空くのは真下</b>。 */
    private static final float ANGLE_START = 160.0F;
    private static final float ANGLE_SWEEP = 220.0F;

    // 線の太さ（1.0 がカタログの「いま」、ここは「細」）
    private static final float LINE_RING = 0.6F;
    private static final float LINE_TICK_MAJOR = 0.75F;
    private static final float LINE_TICK_MINOR = 0.7F;
    private static final float LINE_NEEDLE = 0.75F;
    private static final float LINE_HUB = 0.85F;

    // 文字盤の各部の半径（RADIUS を 44 としたときの値）
    private static final float BEZEL_WIDTH = 5.0F * LINE_RING;
    private static final float GLASS_RADIUS = RADIUS - BEZEL_WIDTH;
    /** レッドゾーンの弧。<b>外周のリングではなく文字盤の内側</b>に置くのが当時の作法。 */
    private static final float RED_OUTER = RADIUS - 8.5F;
    private static final float RED_WIDTH = 3.5F * LINE_RING;
    private static final float TICK_OUTER = RADIUS - 8.5F;
    private static final float TICK_MAJOR_INNER = RADIUS - 15.0F;
    private static final float TICK_MINOR_INNER = RADIUS - 12.0F;
    /** 目盛りの数字を置く半径。<b>内側へ寄せすぎると針の軸と単位の文字にぶつかる。</b> */
    private static final float LABEL_RADIUS = RADIUS - 22.5F;
    private static final float NEEDLE_OUTER = RADIUS - 11.0F;
    private static final float NEEDLE_INNER = -10.0F;
    private static final float HUB_RADIUS = 5.5F * LINE_HUB;

    /** 単位の文字と、その下に置く小計器の位置（中心からの下向き）。 */
    private static final float UNIT_DY = 12.0F;
    private static final float SUBGAUGE_TOP = 19.0F;
    /** 速度計の単位の位置。ペダルの棒を 4 段まで入れるため、回転計（{@link #UNIT_DY}）より上。 */
    private static final float SPEED_UNIT_DY = 8.8F;
    /** 段の枠の右上に添えるレバーの位置の文字の大きさ。 */
    private static final float LEVER_TEXT_SCALE = 0.5F;
    /**
     * ペダルの棒の置き場所（速度計の中心から）。<b>名前の分だけ右へずらす</b>ので、棒そのものは中心から
     * 少し右に寄る。4 段目の下端（28.8）でも文字盤の縁の内側（39）に収まり、最上段（14.4）は
     * 目盛りの端（y=12）より下にある。
     */
    private static final float PEDAL_TOP = 14.4F;
    private static final float PEDAL_LEFT = -8.4F;
    private static final float PEDAL_WIDTH = 20.0F;
    private static final float PEDAL_HEIGHT = 2.4F;
    private static final float PEDAL_PITCH = 4.0F;
    private static final float PEDAL_LABEL_GAP = 1.6F;
    /**
     * 警告灯の文字の大きさ。<b>ここだけ {@link #SMALL_TEXT_SCALE} より小さい。</b>
     *
     * <p>0.75 では灯が目立ちすぎた。0.5 にしてあるのは、GUI スケールが偶数のとき
     * フォントの 1px がちょうど画面の 1 画素に乗って滲まないから（0.6 のような端数は滲む）。</p>
     */
    private static final float LAMP_TEXT_SCALE = 0.5F;
    /** 警告灯の高さと、文字の左右の余白・灯どうしの間隔。 */
    private static final float LAMP_HEIGHT = 5.0F;
    private static final float LAMP_PADDING = 1.0F;
    private static final float LAMP_GAP = 1.0F;

    /** 目盛りの数字の大きさ。1.0 のままだと 3 桁が文字盤をふさぐ。 */
    private static final float LABEL_TEXT_SCALE = 0.75F;
    /** 単位や AT/MT のような添え字の大きさ。<b>これ以上小さくすると潰れる。</b> */
    private static final float SMALL_TEXT_SCALE = 0.75F;
    /**
     * 速度計で数字を出す区切りの数の上限。
     *
     * <p>220 度をこれ以上割ると、半径 21.5 のところで隣との間隔が 3 桁の幅（13.5px）を
     * 下回って<b>重なる</b>。5 分割なら 44 度＝16.5px あるので収まる。</p>
     *
     * <p>回転計は 1 桁（4.5px）しか出さないので、この制限は要らない。</p>
     */
    private static final int MAX_SPEED_STEPS = 5;

    // 中央のデジタル表示
    private static final float PANEL_WIDTH = 84.0F;
    private static final float PANEL_HEIGHT = 32.0F;
    /**
     * 小窓の下端をここより下へ置かない（画面の下端から数えた位置）。
     *
     * <p><b>バニラの体力バーは画面下端から 39px のところが上端</b>（Forge の
     * {@code leftHeight} が 39 から始まり、バーが 1 段増えるごとに 10 ずつ積み上がる）。
     * <b>防具を着ていると、その 1 段上（下端から 49px）にもう 1 列出る</b>ので、
     * そこに 2px の隙間を足した 51 にしてある。</p>
     *
     * <p>体力バーだけを避けるなら 42 まで下げられるが、<b>防具を着た瞬間に重なる</b>。
     * バーの増減で小窓が動くのは避けたいので、<b>いちばん出っ張る場合に合わせて
     * 固定してある</b>。</p>
     *
     * <p>メーターの中心から決めるだけだと、<b>倍率が小さいときに小窓が下がって
     * 体力バーを覆う</b>（実効 427x240 で実際に重なった）。画面の下端から数えた位置で
     * 頭打ちにすれば、どの倍率でも重ならない。</p>
     */
    private static final float HEARTS_ROW_TOP = 51.0F;
    /** シフトインジケーターの LED の数。 */
    private static final int SHIFT_LIGHTS = 21;
    /** LED の並びが描く弧の半径。大きいほど平らになる。 */
    private static final float SHIFT_ARC_RADIUS = 340.0F;
    /** LED を並べる角度の広がり [度]。 */
    private static final float SHIFT_SPREAD_DEGREES = 10.0F;
    /** LED が点きはじめる回転数の割合。ここから下は 1 つも点かない。 */
    private static final double SHIFT_LIGHT_FROM = 0.45;

    /**
     * メーターを描く高さ（Z）。<b>チャットより手前に出すために持ち上げる。</b>
     *
     * <p><b>描く順番だけでは手前にならない。</b>{@code RenderGuiEvent.Post} は Forge の
     * オーバーレイ（チャットを含む）をすべて描いた<b>後</b>に飛ぶ——ここまではバイトコードで
     * 確認したとおり——が、<b>チャットは {@code pose().translate(0, 0, 50)} で Z を上げて
     * 描かれている</b>ので、Z=0 のまま描くと深度テストで負けて<b>チャットの下に潜る</b>。</p>
     *
     * <p>バニラが使っている高さは、チャット 50・アイテム 100〜150・ツールチップ 400。
     * その間の 200 に置けば、チャットより手前で、ツールチップより奥になる。</p>
     */
    private static final float HUD_LAYER_Z = 200.0F;

    /** レブリミットのこの割合を超えたら針と LED を白く（警告色に）する。 */
    private static final double REDLINE_WARN = 0.95;
    private static final int COLOR_NEEDLE_WARN = 0xFFFFFFFF;

    /**
     * 中央の小窓（シフトインジケーターを含む）の上端。画面の Y。出していないときは NaN。
     * アクションバーをこれより上へ逃がす（{@link #overlayMessageY}）。
     */
    private static float panelTop = Float.NaN;

    /**
     * アクションバーの文字の基準点から、下敷きの下端までの距離に、小窓との隙間 2px を足したもの。
     * 文字は基準点の 4px 上から 9px、下敷きが上下に 2px 付くので、下端は基準点の 7px 下。
     */
    private static final float OVERLAY_MESSAGE_CLEARANCE = 9.0F;

    private CarGaugeHud() {
    }

    /**
     * アクションバー（{@code setOverlayMessage} の 1 行）を置く高さ。<b>中央の小窓より上へ逃がす。</b>
     *
     * <p>バニラはアクションバーを画面下端から 68px のところに置くが、小窓は下端から 51px より上を使う
     * （倍率 1 で 90px まで）ので重なる。小窓はアクションバーより後に描くので、アクションバーが
     * <b>小窓の裏に回って読めなくなっていた</b>。小窓を出していないときは元の高さのまま。</p>
     *
     * <p>{@code y} はローダーが決めた文字の基準点（体力バーが高く積まれていれば、そのぶん上がっている）。
     * それより下へは動かさない。値は前のフレームで描いた小窓のもの（アクションバーのほうが先に描かれる）。</p>
     */
    public static float overlayMessageY(float y) {
        if (!ClientConfig.showGauges || Float.isNaN(panelTop)) {
            return y;
        }
        return Math.min(y, panelTop - OVERLAY_MESSAGE_CLEARANCE);
    }

    /** HUD をすべて描き終えた後に呼ぶ（版の {@code ClientHooks#renderGuiPost}）。 */
    public static void onRenderGui(UiGraphics graphics) {
        if (!ClientConfig.showGauges || RaceHud.isShowingResults()) {
            clearBounds();
            return;
        }
        // 換装・セッティング画面が開いている間は引っ込める。どちらも下端を使うので
        // 重なるし、開いているあいだは運転の入力も止まっている
        if (ScreenStyle.isCarScreen()) {
            clearBounds();
            return;
        }
        RaceClient client = RaceClient.get();
        // 同乗者にも出す。速度も回転数も段も同期されているので描ける
        HudCar car = CarClient.get().ridingHud();
        if (client.hideGui() || car == null) {
            clearBounds();
            return;
        }
        render(graphics, client.font(), client.guiWidth(), client.guiHeight(), car);
    }

    /** 出していないことを、アクションバーの高さを聞いてくる側（{@link #overlayMessageY}）へ伝える。 */
    private static void clearBounds() {
        panelTop = Float.NaN;
    }

    private static void render(UiGraphics graphics, UiFont font, int screenWidth, int screenHeight, HudCar car) {

        // ホットバーの外側に残っている幅と、画面の高さの両方に収まるまで縮める。
        // 幅だけで決めると、GUI スケールを上げた人の画面で前が見えなくなる
        float available = (screenWidth - HOTBAR_HALF_WIDTH * 2.0F) / 2.0F - HOTBAR_GAP * 2.0F;
        float fit = Math.min(available, screenHeight * MAX_HEIGHT_FRACTION) / (RADIUS * 2.0F);
        // 切り上げると空きを超えるので、刻みへは必ず切り捨てで丸める
        float base = Math.max(MIN_SCALE,
                (float) Math.floor(Math.min(1.0F, fit) / SCALE_STEP) * SCALE_STEP);
        float scale = base * (float) ClientConfig.gaugeScale;

        float radius = RADIUS * scale;
        float centerY = screenHeight - BOTTOM_MARGIN - radius;
        float leftX = screenWidth * 0.5F - HOTBAR_HALF_WIDTH - HOTBAR_GAP - radius;
        float rightX = screenWidth * 0.5F + HOTBAR_HALF_WIDTH + HOTBAR_GAP + radius;

        CarSpec spec = car.getSpec();
        GaugeTheme theme = ClientConfig.gaugeTheme;

        graphics.pushPose();
        graphics.translateZ(HUD_LAYER_Z);
        renderTachometer(graphics, font, theme, car, spec, leftX, centerY, scale);
        renderSpeedometer(graphics, font, theme, car, spec, rightX, centerY, scale);
        // 小窓は下げられるだけ下げる。2 眼の間で高い位置にあると浮いて見えるので、
        // 体力バーの手前まで落とす（メーターの中心より下がることになる）
        float panelBottom = screenHeight - HEARTS_ROW_TOP;
        // 小窓の地（PANEL_HEIGHT）の 4px 上から、シフトインジケーターの LED が 3px 伸びる
        panelTop = panelBottom - (PANEL_HEIGHT + 4.0F + 3.0F) * scale;
        renderCenterPanel(graphics, font, theme, car, spec, screenWidth * 0.5F,
                panelBottom, scale);
        graphics.popPose();
    }

    // ------------------------------------------------------------------
    // 回転計（左）
    // ------------------------------------------------------------------

    private static void renderTachometer(UiGraphics graphics, UiFont font, GaugeTheme theme,
                                         HudCar car, CarSpec spec,
                                         float x, float y, float scale) {
        double redline = spec.redlineRpm();
        // レブリミットの少し上まで目盛りを伸ばす。実車と同じで、限界が文字盤の端に来ない
        double top = Math.ceil((redline + 500.0) / 1000.0) * 1000.0;
        double rpm = car.getRenderRpm();
        boolean warn = rpm >= redline * REDLINE_WARN;
        // レブリミットが高い車では 1000rpm ごとに数字を出すと詰まる（13000rpm で 14 個）
        double major = top > 9000.0 ? 2.0 : 1.0;

        graphics.pushPose();
        graphics.translate(x, y);
        graphics.scale(scale, scale);

        plate(graphics, theme);
        // レッドゾーンは文字盤の内側の弧。その範囲の数字も赤くする
        GaugeShapes.arc(graphics, 0.0F, 0.0F, RED_OUTER - RED_WIDTH, RED_OUTER,
                angleFor(redline / top), angleFor(1.0), theme.redline);
        ticks(graphics, theme, top / 1000.0, major, major / 2.0, redline / top);
        aidLamps(graphics, font, theme, car, false);
        needle(graphics, theme, rpm / top, warn);

        GaugeShapes.flush(graphics);

        labels(graphics, font, theme, top / 1000.0, major, redline / top);
        aidLamps(graphics, font, theme, car, true);
        centerText(graphics, font, RaceText.translatable("hud.maoudrift.rpm_scale"),
                UNIT_DY, theme.unit);

        graphics.popPose();
    }

    // ------------------------------------------------------------------
    // 速度計（右）
    // ------------------------------------------------------------------

    private static void renderSpeedometer(UiGraphics graphics, UiFont font, GaugeTheme theme,
                                          HudCar car, CarSpec spec,
                                          float x, float y, float scale) {
        SpeedUnit units = SpeedUnit.current();
        double maxKmh = units.fromMetersPerSecond(spec.topGearSpeed());
        // 20km/h 刻みから始めて、数字が重ならないところまで粗くする。
        // 最高速はセッティングとカーパックで変わるので、決め打ちにはできない
        int major = 20;
        while (maxKmh / major > MAX_SPEED_STEPS) {
            major += 20;
        }
        double top = Math.ceil(maxKmh / major) * major;
        double speed = units.fromMetersPerSecond(Math.abs(car.getRenderSpeed()));

        graphics.pushPose();
        graphics.translate(x, y);
        graphics.scale(scale, scale);

        plate(graphics, theme);
        ticks(graphics, theme, top, major, major / 2.0, Double.MAX_VALUE);
        // ペダルの踏み量。実車の燃料計の位置
        pedalBars(graphics, font, theme, car, false);
        needle(graphics, theme, speed / top, false);

        GaugeShapes.flush(graphics);

        labels(graphics, font, theme, top, major, Double.MAX_VALUE);
        pedalBars(graphics, font, theme, car, true);
        // ペダルの棒を 4 段まで入れるため、単位は回転計より少し上に置く
        centerText(graphics, font, units.unit(),
                SPEED_UNIT_DY, theme.unit);

        graphics.popPose();
    }

    // ------------------------------------------------------------------
    // 文字盤の部品（原点はメーターの中心、半径は倍率 1.0 の値）
    // ------------------------------------------------------------------

    /**
     * 文字盤の地。縁（ベゼル）とガラスの照り。
     *
     * <p><b>照りは同心の円を重ねて作る。</b>グラデーションを塗る手段が無いので、
     * 中心寄りの明るい色を薄く 2 枚重ねて近似している。枚数を増やせば滑らかになるが、
     * この大きさでは 2 枚で足りる。</p>
     */
    private static void plate(UiGraphics graphics, GaugeTheme theme) {
        GaugeShapes.arc(graphics, 0.0F, 0.0F, 0.0F, RADIUS, 0.0F, 360.0F, backdrop(theme.face));
        GaugeShapes.arc(graphics, 0.0F, 0.0F, GLASS_RADIUS, RADIUS, 0.0F, 360.0F,
                backdrop(theme.bezel));
        GaugeShapes.arc(graphics, 0.0F, 0.0F, 0.0F, GLASS_RADIUS, 0.0F, 360.0F,
                backdrop(theme.glassOuter));
        GaugeShapes.arc(graphics, 0.0F, 0.0F, 0.0F, GLASS_RADIUS * 0.66F, 0.0F, 360.0F,
                backdrop(theme.glassInner, 0.45F));
        GaugeShapes.arc(graphics, 0.0F, 0.0F, 0.0F, GLASS_RADIUS * 0.36F, 0.0F, 360.0F,
                backdrop(theme.glassInner, 0.45F));
        // 縁の内側に入る細い金属光沢
        GaugeShapes.arc(graphics, 0.0F, 0.0F, GLASS_RADIUS, GLASS_RADIUS + 0.9F * LINE_RING,
                0.0F, 360.0F, backdrop(theme.bezelRing));
    }

    /**
     * 目盛りの線。
     *
     * @param top     文字盤の上限（表示する単位のまま）
     * @param major   数字を出す間隔
     * @param minor   細い線の間隔
     * @param redFrom この割合から先は赤くする。無ければ {@link Double#MAX_VALUE}
     */
    private static void ticks(UiGraphics graphics, GaugeTheme theme,
                              double top, double major, double minor, double redFrom) {
        int count = (int) Math.round(top / minor);
        for (int i = 0; i <= count; i++) {
            double v = minor * i;
            boolean isMajor = Math.abs(v / major - Math.round(v / major)) < 1.0e-6;
            boolean hot = v / top >= redFrom - 1.0e-9;
            GaugeShapes.radialBar(graphics, 0.0F, 0.0F,
                    isMajor ? TICK_MAJOR_INNER : TICK_MINOR_INNER, TICK_OUTER,
                    angleFor(v / top),
                    isMajor ? 2.0F * LINE_TICK_MAJOR : 1.0F * LINE_TICK_MINOR,
                    isMajor ? (hot ? theme.redline : theme.tickMajor) : theme.tickMinor);
        }
    }

    /** 目盛りの数字。<b>図形を流したあとに描く。</b> */
    private static void labels(UiGraphics graphics, UiFont font, GaugeTheme theme,
                               double top, double major, double redFrom) {
        int count = (int) Math.round(top / major);
        for (int i = 0; i <= count; i++) {
            double v = major * i;
            float angle = angleFor(v / top);
            float lx = (float) Math.cos(Math.toRadians(angle)) * LABEL_RADIUS;
            float ly = (float) Math.sin(Math.toRadians(angle)) * LABEL_RADIUS;
            String text = String.format("%.0f", v);
            int color = v / top >= redFrom - 1.0e-9 ? theme.redline : theme.label;
            graphics.pushPose();
            graphics.translate(lx, ly);
            graphics.scale(LABEL_TEXT_SCALE, LABEL_TEXT_SCALE);
            graphics.drawString(font, text, -font.width(text) / 2, -font.lineHeight / 2, color, false);
            graphics.popPose();
        }
    }

    /** 針とその軸。 */
    private static void needle(UiGraphics graphics, GaugeTheme theme, double fraction, boolean warn) {
        float angle = angleFor(fraction);
        GaugeShapes.needle(graphics, 0.0F, 0.0F, NEEDLE_INNER, NEEDLE_OUTER, angle,
                3.0F * LINE_NEEDLE, warn ? COLOR_NEEDLE_WARN : theme.needle);
        GaugeShapes.arc(graphics, 0.0F, 0.0F, 0.0F, HUB_RADIUS, 0.0F, 360.0F, theme.hub);
        GaugeShapes.arc(graphics, 0.0F, 0.0F, HUB_RADIUS - 0.8F, HUB_RADIUS, 0.0F, 360.0F,
                theme.hubRing);
    }

    /** 文字盤の中央に置く小さな文字。{@code dy} は中心からの上下（正が下）。 */
    private static void centerText(UiGraphics graphics, UiFont font, RaceText text,
                                   float dy, int color) {
        graphics.pushPose();
        graphics.translate(0.0F, dy);
        graphics.scale(SMALL_TEXT_SCALE, SMALL_TEXT_SCALE);
        graphics.drawString(font, text, -font.width(text) / 2, -font.lineHeight / 2, color, false);
        graphics.popPose();
    }

    /**
     * ペダルの踏み量。速度計の中、実車の燃料計の位置。上からアクセル・ブレーキ・クラッチ・サイド。
     *
     * <p><b>キーボードでも 0/100 では動かない</b>（変化率に上限がある）ので、
     * 押している長さがそのまま棒の伸びとして見える。コントローラならなおさら。</p>
     *
     * <p><b>クラッチとサイドの段は、値が分かるときだけ出して上へ詰める。</b>クラッチはマニュアルの車で
     * クラッチペダルを割り当てた運転者だけ（キーボードやパッドの人にクラッチを意識させない）。サイドは
     * 運転している本人だけ（同期していない）。4 本に増えると色だけでは読めないので、左に名前を書く。</p>
     *
     * <p>置けるのは<b>文字盤の下の、目盛りが回ってこない範囲</b>。開始角 160 度から
     * 220 度なので、真下（90 度）の周りが空く。図形と文字で 2 回呼ぶ（{@code text}）。</p>
     */
    private static void pedalBars(UiGraphics graphics, UiFont font, GaugeTheme theme, HudCar car,
                                  boolean text) {
        double clutch = car.getRenderClutchPedal();
        double handbrake = car.getRenderHandbrake();
        float top = PEDAL_TOP;
        top = pedalRow(graphics, font, theme, "hud.maoudrift.pedal_throttle", top,
                car.getRenderThrottle(), theme.throttle, text);
        top = pedalRow(graphics, font, theme, "hud.maoudrift.pedal_brake", top,
                car.getRenderBrake(), theme.brake, text);
        if (clutch >= 0.0) {
            top = pedalRow(graphics, font, theme, "hud.maoudrift.pedal_clutch", top,
                    clutch, theme.clutch, text);
        }
        if (handbrake >= 0.0) {
            pedalRow(graphics, font, theme, "hud.maoudrift.pedal_handbrake", top,
                    handbrake, theme.handbrakeBar, text);
        }
    }

    /** ペダルの棒 1 段。次の段の上端を返す。 */
    private static float pedalRow(UiGraphics graphics, UiFont font, GaugeTheme theme, String labelKey,
                                  float top, double value, int color, boolean text) {
        if (text) {
            RaceText label = RaceText.translatable(labelKey);
            // 大文字の字面（7px）を棒の高さの真ん中へ、右端を棒の左に揃える
            float glyph = 7.0F * LAMP_TEXT_SCALE;
            graphics.pushPose();
            graphics.translate(PEDAL_LEFT - PEDAL_LABEL_GAP - font.width(label) * LAMP_TEXT_SCALE,
                    top + (PEDAL_HEIGHT - glyph) / 2.0F);
            graphics.scale(LAMP_TEXT_SCALE, LAMP_TEXT_SCALE);
            graphics.drawString(font, label, 0, 0, theme.unit, false);
            graphics.popPose();
        } else {
            GaugeShapes.rect(graphics, PEDAL_LEFT, top, PEDAL_LEFT + PEDAL_WIDTH, top + PEDAL_HEIGHT,
                    theme.aidOff);
            float filled = (float) Math.max(0.0, Math.min(1.0, value)) * PEDAL_WIDTH;
            if (filled > 0.0F) {
                GaugeShapes.rect(graphics, PEDAL_LEFT, top, PEDAL_LEFT + filled, top + PEDAL_HEIGHT, color);
            }
        }
        return top + PEDAL_PITCH;
    }

    /**
     * 警告灯。回転計の中、実車の警告灯の位置。上の段に ABS と TCS、下の段にサイドブレーキ。
     *
     * <p><b>灯そのものに名前を書く。</b>色の付いた四角だけでは何の灯なのか分からなかった。
     * 実車の警告灯と同じく、消えているときも文字は薄く見えている——点いたときに初めて
     * 名前が現れるのでは、何が点いたのか読む前に消えてしまう。</p>
     *
     * <p>図形と文字で 2 回呼ぶ（{@code text}）。図形を積んだら文字の前に
     * {@link GaugePainter#flush} が要るため、置き場所の計算を 1 か所にまとめてある。</p>
     */
    private static void aidLamps(UiGraphics graphics, UiFont font, GaugeTheme theme,
                                 HudCar car, boolean text) {
        RaceText abs = RaceText.translatable("hud.maoudrift.lamp_abs");
        RaceText tcs = RaceText.translatable("hud.maoudrift.lamp_tcs");
        RaceText handbrake = RaceText.translatable("hud.maoudrift.lamp_handbrake");
        // 上の段は左右対称にしたいので、幅の広いほうに揃える
        float pairWidth = Math.max(lampWidth(font, abs), lampWidth(font, tcs));
        float offset = pairWidth / 2.0F + LAMP_GAP / 2.0F;
        float secondRow = SUBGAUGE_TOP + LAMP_HEIGHT + LAMP_GAP;
        lamp(graphics, font, theme, abs, -offset, SUBGAUGE_TOP, pairWidth,
                car.isAbsActive() ? 1.0F : 0.0F, theme.aidOn, text);
        lamp(graphics, font, theme, tcs, offset, SUBGAUGE_TOP, pairWidth,
                car.isTractionControlActive() ? 1.0F : 0.0F, theme.aidOn, text);
        float brake = car.isHandbrakeOn() ? 1.0F : 0.0F;
        if (!car.hasTurbo()) {
            lamp(graphics, font, theme, handbrake, 0.0F, secondRow, lampWidth(font, handbrake),
                    brake, theme.handbrake, text);
            return;
        }
        // ターボ車は下の段を E-BRAKE と TURBO の 2 つにする。上の段と同じく幅を揃えて左右対称に。
        // TURBO は<b>ブーストに合わせてじわっと</b>点く（点く／消えるの 2 値だと、
        // どれだけ掛かっているのかが分からない）
        RaceText turbo = RaceText.translatable("hud.maoudrift.lamp_turbo");
        float lowerWidth = Math.max(lampWidth(font, handbrake), lampWidth(font, turbo));
        float lowerOffset = lowerWidth / 2.0F + LAMP_GAP / 2.0F;
        float boost = (float) CarClient.get().turboBoost();
        lamp(graphics, font, theme, handbrake, -lowerOffset, secondRow, lowerWidth,
                brake, theme.handbrake, text);
        lamp(graphics, font, theme, turbo, lowerOffset, secondRow, lowerWidth,
                boost, theme.turbo, text);
    }

    /** ARGB の色を {@code t} で混ぜる（0 で a、1 で b）。 */
    private static int blend(int a, int b, float t) {
        int alpha = Math.round(Mth.lerp(t, a >>> 24, b >>> 24));
        int red = Math.round(Mth.lerp(t, (a >> 16) & 0xFF, (b >> 16) & 0xFF));
        int green = Math.round(Mth.lerp(t, (a >> 8) & 0xFF, (b >> 8) & 0xFF));
        int blue = Math.round(Mth.lerp(t, a & 0xFF, b & 0xFF));
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    private static float lampWidth(UiFont font, RaceText label) {
        return font.width(label) * LAMP_TEXT_SCALE + LAMP_PADDING * 2.0F;
    }

    /**
     * 灯 1 つ。{@code level} は点き具合 0..1（ほとんどは 0 か 1。TURBO だけ途中の値を取る）。
     * 文字の色は半分を越えたら点いている側に切り替える。
     */
    private static void lamp(UiGraphics graphics, UiFont font, GaugeTheme theme, RaceText label,
                             float centerX, float top, float width, float level, int onColor,
                             boolean text) {
        float left = centerX - width / 2.0F;
        boolean on = level > 0.5F;
        if (!text) {
            GaugeShapes.rect(graphics, left, top, left + width, top + LAMP_HEIGHT,
                    blend(theme.aidOff, onColor, Mth.clamp(level, 0.0F, 1.0F)));
            return;
        }
        // 大文字の字面（7px）を灯の高さの真ん中へ
        float glyph = 7.0F * LAMP_TEXT_SCALE;
        graphics.pushPose();
        graphics.translate(centerX - font.width(label) * LAMP_TEXT_SCALE / 2.0F,
                top + (LAMP_HEIGHT - glyph) / 2.0F);
        graphics.scale(LAMP_TEXT_SCALE, LAMP_TEXT_SCALE);
        graphics.drawString(font, label, 0, 0, on ? theme.aidLabelOn : theme.aidLabel, false);
        graphics.popPose();
    }

    // ------------------------------------------------------------------
    // 中央のデジタル表示
    // ------------------------------------------------------------------

    /**
     * シフトインジケーターとデジタル速度・段。
     *
     * <p>置き場所は<b>2 眼の間、ホットバーの上</b>。下端に置くとホットバーと体力バーに
     * 重なるので、メーターの中心からわずかに下げたところで止めてある。</p>
     */
    private static void renderCenterPanel(UiGraphics graphics, UiFont font, GaugeTheme theme,
                                          HudCar car, CarSpec spec,
                                          float x, float bottomY, float scale) {
        graphics.pushPose();
        graphics.translate(x, bottomY);
        graphics.scale(scale, scale);

        float half = PANEL_WIDTH / 2.0F;
        GaugeShapes.rect(graphics, -half, -PANEL_HEIGHT, half, 0.0F, backdrop(theme.panel));
        GaugeShapes.rect(graphics, -half, -PANEL_HEIGHT, half, -PANEL_HEIGHT + 1.0F,
                theme.aidOff);
        shiftLights(graphics, theme, car, spec, -PANEL_HEIGHT - 4.0F);

        // 段。赤地に白抜きで、いちばん目立たせる
        float boxLeft = -half + 6.0F;
        float boxTop = -PANEL_HEIGHT + 5.0F;
        float boxSize = 22.0F;
        int gear = car.getRenderGear();
        // クラッチを踏まないと入らない場面で、レバーは段の位置なのに入っていない。赤地をやめて黄色い枠にし、
        // 右上にレバーの位置を添える（「入れたつもりなのに N」に気づけるように）。踏めばその場で入る
        int lever = car.getRenderLeverGear();
        boolean waiting = lever != CarInput.NO_GEAR_SELECT && lever != 0 && lever != gear;
        if (waiting) {
            GaugeShapes.rect(graphics, boxLeft, boxTop, boxLeft + boxSize, boxTop + boxSize, theme.aidOn);
            GaugeShapes.rect(graphics, boxLeft + 1.0F, boxTop + 1.0F, boxLeft + boxSize - 1.0F, boxTop + boxSize - 1.0F,
                    theme.hub);
        } else {
            GaugeShapes.rect(graphics, boxLeft, boxTop, boxLeft + boxSize, boxTop + boxSize,
                    theme.gearBox);
        }

        GaugeShapes.flush(graphics);

        String gearText = gearLabel(gear);
        float gearScale = 1.7F;
        graphics.pushPose();
        graphics.translate(boxLeft + boxSize / 2.0F - font.width(gearText) * gearScale / 2.0F,
                boxTop + boxSize / 2.0F - font.lineHeight * gearScale / 2.0F);
        graphics.scale(gearScale, gearScale);
        graphics.drawString(font, gearText, 0, 0, theme.gearText, false);
        graphics.popPose();
        if (waiting) {
            String leverText = gearLabel(lever);
            graphics.pushPose();
            graphics.translate(boxLeft + boxSize - 1.5F - font.width(leverText) * LEVER_TEXT_SCALE, boxTop + 1.5F);
            graphics.scale(LEVER_TEXT_SCALE, LEVER_TEXT_SCALE);
            graphics.drawString(font, leverText, 0, 0, theme.aidOn, false);
            graphics.popPose();
        }

        RaceText mode = RaceText.translatable(spec.isManual()
                ? "hud.maoudrift.transmission_mt" : "hud.maoudrift.transmission_at");
        graphics.pushPose();
        graphics.translate(boxLeft + boxSize / 2.0F - font.width(mode) * SMALL_TEXT_SCALE / 2.0F,
                -8.0F);
        graphics.scale(SMALL_TEXT_SCALE, SMALL_TEXT_SCALE);
        graphics.drawString(font, mode, 0, 0, theme.unit, false);
        graphics.popPose();

        // 速度。いちばん見る数字なので大きく、右詰め
        String speed = String.format("%.0f", SpeedUnit.current().fromMetersPerSecond(Math.abs(car.getRenderSpeed())));
        float speedScale = 1.6F;
        graphics.pushPose();
        graphics.translate(half - 6.0F - font.width(speed) * speedScale,
                -PANEL_HEIGHT + 6.0F);
        graphics.scale(speedScale, speedScale);
        graphics.drawString(font, speed, 0, 0, theme.text, false);
        graphics.popPose();

        RaceText unit = SpeedUnit.current().unit();
        graphics.pushPose();
        graphics.translate(half - 6.0F - font.width(unit) * SMALL_TEXT_SCALE, -8.0F);
        graphics.scale(SMALL_TEXT_SCALE, SMALL_TEXT_SCALE);
        graphics.drawString(font, unit, 0, 0, theme.unit, false);
        graphics.popPose();

        graphics.popPose();
    }

    /** 段の表示。1 以上はその数字、負は R、0 は N。 */
    private static String gearLabel(int gear) {
        return gear > 0 ? String.valueOf(gear) : gear < 0 ? "R" : "N";
    }

    /**
     * シフトインジケーター。回転数が上がるほど左から順に点き、レブ手前で赤くなる。
     *
     * <p><b>回転計より先に気づけるのが値打ち。</b>針の角度を読むより、視界の端で色が変わる
     * ほうが速い。マニュアルで走るときにいちばん効く。</p>
     *
     * <p>当時の車には無い装置なので 90 年代の文字盤とは年代が合わないが、<b>段を自分で
     * 選ぶ以上これが無いと回転計を読み続けることになる</b>ので残してある。</p>
     */
    private static void shiftLights(UiGraphics graphics, GaugeTheme theme,
                                    HudCar car, CarSpec spec, float bottomY) {
        double redline = spec.redlineRpm();
        double fraction = redline > 0.0 ? car.getRenderRpm() / redline : 0.0;
        // 下のほうは点けない。全域を使うと「いつも半分点いている」ことになって意味が薄れる
        double lit = (fraction - SHIFT_LIGHT_FROM) / (1.0 - SHIFT_LIGHT_FROM);
        int litCount = (int) Math.floor(Math.max(0.0, Math.min(1.0, lit)) * SHIFT_LIGHTS + 1.0e-6);

        // LED は緩い弧に沿って並べる。<b>中心は下、弧は上向き（∩）。</b>
        // 中心を上に置くと弧が下向き（∪）になり、両端が上がって左右のメーターへ
        // 逃げていくように見える。上向きなら中央がいちばん高く、視線の通り道に沿う
        float spread = SHIFT_SPREAD_DEGREES;
        // 弧の膨らみ（サジッタ）。これを引いておくと、いちばん低くなる両端が
        // ちょうど bottomY に来る——中央を bottomY に合わせると両端が下がって
        // 小窓に食い込む
        float sagitta = SHIFT_ARC_RADIUS
                * (1.0F - (float) Math.cos(Math.toRadians(spread)));
        float centerY = bottomY + SHIFT_ARC_RADIUS - sagitta;
        for (int i = 0; i < SHIFT_LIGHTS; i++) {
            float t = (float) i / (SHIFT_LIGHTS - 1);
            // 角度は時計回りで、真上が 270 度。中心を下に置いたので、
            // 角度が大きいほうが右になる（中心が上のときと逆）
            float angle = 270.0F - spread + spread * 2.0F * t;
            int color = i < litCount ? theme.shiftLight(t) : theme.ledOff;
            // 外側（＝上）へ伸ばす。内側へ伸ばすと弧の線より下に出て小窓に近づく
            GaugeShapes.radialBar(graphics, 0.0F, centerY,
                    SHIFT_ARC_RADIUS, SHIFT_ARC_RADIUS + 3.0F, angle, 3.0F, color);
        }
    }

    /**
     * 下敷き（文字盤と中央パネルの地）の色。<b>設定の濃さを掛ける。</b>
     *
     * <p>薄くすると後ろのチャットが透けて見える。<b>掛けるのは地だけで、目盛り・数字・針には
     * 掛けない</b>——読めなくなっては計器の意味がない。HUD 自体はチャットより手前に描かれて
     * いる（{@code RenderGuiEvent.Post} は {@code Gui#render} の後）ので、
     * <b>順序ではなく濃さの問題</b>だった。</p>
     */
    private static int backdrop(int color) {
        return backdrop(color, 1.0F);
    }

    /** 同上。{@code extra} はさらに掛ける不透明度（ガラスの照りを重ねるのに使う）。 */
    private static int backdrop(int color, float extra) {
        int alpha = Math.round((color >>> 24) * (float) ClientConfig.gaugeOpacity * extra);
        return (Math.min(255, alpha) << 24) | (color & 0x00FFFFFF);
    }

    /** 割合（0..1）を文字盤の角度へ。範囲の外はクランプする。 */
    private static float angleFor(double fraction) {
        float t = (float) Math.max(0.0, Math.min(1.0, fraction));
        return ANGLE_START + ANGLE_SWEEP * t;
    }
}
