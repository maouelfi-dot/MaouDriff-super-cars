package com.maou.maoudrift.network;

/**
 * サーバー → クライアント。ラップ計測とスタート信号の合図。
 *
 * <p><b>走行中のタイムは毎ティック送らない。</b>「ラップが始まった」を送れば、あとは
 * クライアントが自分で数えられる。確定したタイムはラップ完了時にサーバーの値で上書きされるので、
 * 表示のずれは残らない。</p>
 *
 * <p>デルタ（自己ベストとの差）も<b>サーバーが出して送る</b>。比較相手はベスト走行の
 * 通過時刻で、それを持っているのはサーバーだからで、クライアントへ配って計算させる理由がない。</p>
 *
 * @param kind        何が起きたか（{@code type} だと {@code CustomPacketPayload#type()} とぶつかる）
 * @param lights      点灯しているスタート信号の数（{@link Type#COUNTDOWN} のとき）
 * @param frozen      カウントダウン中で車を動かせないか
 * @param lap         今の周回（1 から）
 * @param totalLaps   規定周回数。タイムアタックでは 0
 * @param millis      直前のラップタイム、あるいは区間通過時点の経過 [ms]
 * @param bestMillis  ベストラップ [ms]
 * @param best        今のラップでベストを更新したか
 * @param place       完走順位（{@link Type#FINISHED} のとき）
 * @param course      コースの名前。{@link Type#LAP_STARTED}・{@link Type#LAP_COMPLETED}・
 *                    {@link Type#BEST_CLEARED} のときだけ入る（ゴーストをコースごとに持つため。他は空）
 * @param total       ゴールまでの総時間 [ms]。<b>ラップタイムとは別に要る</b>——
 *                    ゴールした人の表示はここで止めるので、最終ラップだけでは足りない
 * @param sector      区間の番号（1 から）。{@link Type#SPLIT} のとき
 * @param sectorCount 区間の総数（チェックポイント数 + 1）
 * @param delta       自己ベストの同じ地点との差 [ms]。負なら速い
 * @param hasDelta    比較できるベストがあるか。無ければ {@code delta} は無意味
 * @param raceClass   クラスの名前（空ならクラスなし）。{@link Type#LAP_STARTED}・{@link Type#LAP_COMPLETED} は
 *                    <b>これから走る周</b>の比べる相手（ゴーストもこれで選ぶ）、{@link Type#BEST_CLEARED} は
 *                    記録を消したクラス
 * @param countedClass 終えた周を記録したクラス（{@link Type#LAP_COMPLETED}）。宣言していない・決まりに外れていたら空。
 *                    {@link Type#BEST_CLEARED} のときは<b>記録を消した次元</b>（{@link #clearedDimension}）
 * @param classBest   終えた周で {@code countedClass} のベストを更新したか
 * @param overallBest 終えた周でクラスなしのベストを更新したか。{@code best} は比べた相手（宣言したクラスかクラスなし）の方
 * @param targetBest  これから走る周の比べる相手（{@code raceClass}）の自己ベスト [ms]。無ければ 0。
 *                    {@link Type#LAP_STARTED}・{@link Type#LAP_COMPLETED} のとき。<b>手元のゴーストがこのタイムで
 *                    なければ捨てる</b>（落ちている間に記録が消された・上書きされた）
 */
public record RaceEventPacket(Type kind, int lights, boolean frozen, int lap, int totalLaps,
                              long millis, long bestMillis, boolean best, int place,
                              int sector, int sectorCount, long delta, boolean hasDelta,
                              long total, String course, String raceClass, String countedClass,
                              boolean classBest, boolean overallBest, long targetBest) implements RacePayload {

    public enum Type {
        /** スタート信号の状態が変わった。 */
        COUNTDOWN,
        /** 計測が始まった。 */
        LAP_STARTED,
        /** チェックポイントを通った。 */
        SPLIT,
        /** 1 周終わった。 */
        LAP_COMPLETED,
        /**
         * ラインは通ったが周回として認められなかった。
         *
         * <p><b>黙って数えないのがいちばん悪い。</b>走っている本人には「1 周したのに
         * カウントが増えない」としか見えず、規定より 1 周多く走らされた理由が分からない。</p>
         */
        LAP_VOID,
        /** 規定周回を走りきった。 */
        FINISHED,
        /** 表示を消す。 */
        CLEARED,
        /**
         * ベストタイムを消した。{@code course} が空なら全コース。
         *
         * <p>タイムアタックのゴーストはベストの周そのものなので、一緒に消してもらう。</p>
         */
        BEST_CLEARED,
        /**
         * タイムアタックのウォームアップが始まった（{@code course} を 1 回目に越えた）。<b>計測は次にスタートラインを
         * 越えたところから</b>。越えた瞬間から測ると助走が無く、ラインの手前の速さで 1 周目が決まってしまう。
         */
        WARM_UP,
        /**
         * 自分に関わる出来事を画面中央の帯で知らせる（{@link Notice}。どれかは {@code place}、名前は {@code course}）。
         * チャットにも同じことが出るが、走っている最中は読まない。
         */
        NOTICE
    }

    /** {@link Type#NOTICE} の中身。<b>並びを変えないこと</b>（番号で送る）。 */
    public enum Notice {
        /** 主催者（名前）がスタート前にレースを中止した。 */
        CANCELLED,
        /** 主催者（名前）が走行中のレースを終えた。 */
        ENDED,
        /** 号砲の時点で運転していなかったのでリタイアになった。 */
        NOT_DRIVING,
        /** 主催者（名前）にエントリーから外された。 */
        KICKED,
        /** エントリーした。 */
        JOINED,
        /** エントリーを取り消した（受付中に自分で抜けた）。 */
        LEFT,
        /** 信号の途中でエントリーがいなくなったので、スタートを取りやめた。 */
        ABORTED,
        /** 車を降りたまま戻らなかったのでリタイアになった。 */
        AWAY_RETIRED,
        /** 自分でリタイアした（走行中に抜けた）。 */
        RETIRED,
        /** 全員がリタイアしたので、リザルトを出さずに終わった。 */
        ALL_RETIRED,
        /** 主催者（名前）が受付中に抜けたので中止になった。 */
        HOST_LEFT,
        /** 主催者（名前）が走行中に抜けた。レースは続く。 */
        HOST_LEFT_RUNNING,
        /** 主催者（名前）が別の次元へ移ったので終わった。 */
        HOST_LEFT_DIMENSION,
        /** 走行中に決まりの外へ出たので失格になった（別の車への乗り換えなど）。 */
        DISQUALIFIED
    }

    private static final Type[] TYPES = Type.values();

    public static RaceEventPacket countdown(int lights, boolean frozen) {
        return new RaceEventPacket(Type.COUNTDOWN, lights, frozen, 0, 0, 0, 0, false, 0,
                0, 0, 0, false, 0, "", "", "", false, false, 0L);
    }

    /** @param sectorCount 区間の総数（チェックポイント数 + 1）。通過数の表示に使う */
    public static RaceEventPacket lapStarted(int lap, int totalLaps, int sectorCount, String course,
                                             String raceClass, long targetBest) {
        return new RaceEventPacket(Type.LAP_STARTED, 0, false, lap, totalLaps, 0, 0, false, 0,
                0, sectorCount, 0, false, 0, course, raceClass, "", false, false, targetBest);
    }

    /**
     * 周回として認めなかった合図。
     *
     * <p>理由は<b>数から分かる</b>ので旗を増やさない。通ったチェックポイントが足りなければ
     * 取りこぼし、足りているならラップが短すぎたということ。</p>
     *
     * @param passed      通ったチェックポイントの数
     * @param sectorCount 区間の総数（チェックポイント数 + 1）
     */
    public static RaceEventPacket lapVoid(int passed, int sectorCount) {
        return new RaceEventPacket(Type.LAP_VOID, 0, false, 0, 0, 0, 0, false, 0,
                passed, sectorCount, 0, false, 0, "", "", "", false, false, 0L);
    }

    /**
     * チェックポイント通過。
     *
     * @param elapsed ラップ開始からの経過 [ms]
     */
    public static RaceEventPacket split(int sector, int sectorCount, long elapsed,
                                        long delta, boolean hasDelta) {
        return new RaceEventPacket(Type.SPLIT, 0, false, 0, 0, elapsed, 0, false, 0,
                sector, sectorCount, delta, hasDelta, 0, "", "", "", false, false, 0L);
    }

    public static RaceEventPacket lapCompleted(int lap, int totalLaps, long millis,
                                               long bestMillis, boolean best,
                                               long delta, boolean hasDelta, String course,
                                               String countedClass, boolean classBest, boolean overallBest,
                                               String nextClass, long targetBest) {
        return new RaceEventPacket(Type.LAP_COMPLETED, 0, false, lap, totalLaps,
                millis, bestMillis, best, 0, 0, 0, delta, hasDelta, 0, course, nextClass, countedClass,
                classBest, overallBest, targetBest);
    }

    public static RaceEventPacket finished(int place, long millis, long bestMillis,
                                           long delta, boolean hasDelta, long total) {
        return new RaceEventPacket(Type.FINISHED, 0, false, 0, 0, millis, bestMillis, false, place,
                0, 0, delta, hasDelta, total, "", "", "", false, false, 0L);
    }

    /**
     * そのコースの全員の記録（クラスなしも全クラスも）を消した。
     *
     * @param dimension 記録を消した次元（コースは次元ごとにある）
     */
    public static RaceEventPacket bestCleared(String dimension, String course) {
        return bestCleared(dimension, course, "");
    }

    /**
     * <b>記録はレースと違って次元に縛られないので、知らせは全員へ送る。</b>ゴーストは次元ごとのフォルダにあるので、
     * 受け取った側は {@code dimension} のフォルダから消す（今いる次元でなくても）。HUD の BEST は、今いる次元の
     * ときだけ消す。
     *
     * @param dimension 記録を消した次元。空ならすべての次元（クラスの記録）
     * @param course    消したコース。空なら全コース
     * @param raceClass 消したクラス。空ならそのコースのクラスなしも全クラスも
     */
    public static RaceEventPacket bestCleared(String dimension, String course, String raceClass) {
        return new RaceEventPacket(Type.BEST_CLEARED, 0, false, 0, 0, 0, 0, false, 0,
                0, 0, 0, false, 0, course, raceClass, dimension, false, false, 0L);
    }

    /** {@link Type#BEST_CLEARED} の、記録を消した次元。空ならすべての次元。 */
    public String clearedDimension() {
        return countedClass;
    }

    /**
     * そのコースの<b>クラスなしの記録だけ</b>を消した（OP が K の画面から）。クラスが空の {@link #bestCleared} は
     * 「そのコースの全部」なので、{@code overallBest} を立てて見分ける。
     */
    public static RaceEventPacket noClassCleared(String dimension, String course) {
        return new RaceEventPacket(Type.BEST_CLEARED, 0, false, 0, 0, 0, 0, false, 0,
                0, 0, 0, false, 0, course, "", dimension, false, true, 0L);
    }

    /** タイムアタックのウォームアップが始まった。 */
    public static RaceEventPacket warmUp(String course, String raceClass) {
        return new RaceEventPacket(Type.WARM_UP, 0, false, 0, 0, 0, 0, false, 0,
                0, 0, 0, false, 0, course, raceClass, "", false, false, 0L);
    }

    /**
     * 画面中央の帯で知らせる。<b>{@link #cleared()} より後に送ること</b>（HUD を消す合図とは別に持つので消えないが、
     * 順番を決めておけば受け取る側で迷わない）。
     *
     * @param who 知らせに出す名前（主催者など）。要らなければ空
     */
    public static RaceEventPacket notice(Notice notice, String who) {
        return new RaceEventPacket(Type.NOTICE, 0, false, 0, 0, 0, 0, false, notice.ordinal(),
                0, 0, 0, false, 0, who, "", "", false, false, 0L);
    }

    /** {@link Type#NOTICE} の中身。知らない番号（新しいサーバー）なら null。 */
    public Notice notice() {
        Notice[] all = Notice.values();
        return place >= 0 && place < all.length ? all[place] : null;
    }

    /** {@link Type#NOTICE} に出す名前。 */
    public String noticeName() {
        return course;
    }

    public static RaceEventPacket cleared() {
        return new RaceEventPacket(Type.CLEARED, 0, false, 0, 0, 0, 0, false, 0,
                0, 0, 0, false, 0, "", "", "", false, false, 0L);
    }

    public RaceEventPacket(RaceBuf buf) {
        this(TYPES[buf.readByte()], buf.readByte(), buf.readBoolean(), buf.readVarInt(),
                buf.readVarInt(), buf.readLong(), buf.readLong(), buf.readBoolean(), buf.readByte(),
                buf.readVarInt(), buf.readVarInt(), buf.readLong(), buf.readBoolean(),
                buf.readLong(), buf.readUtf(), buf.readUtf(), buf.readUtf(), buf.readBoolean(), buf.readBoolean(),
                buf.readLong());
    }

    public void encode(RaceBuf buf) {
        buf.writeByte(kind.ordinal());
        buf.writeByte(lights);
        buf.writeBoolean(frozen);
        buf.writeVarInt(lap);
        buf.writeVarInt(totalLaps);
        buf.writeLong(millis);
        buf.writeLong(bestMillis);
        buf.writeBoolean(best);
        buf.writeByte(place);
        buf.writeVarInt(sector);
        buf.writeVarInt(sectorCount);
        buf.writeLong(delta);
        buf.writeBoolean(hasDelta);
        buf.writeLong(total);
        buf.writeUtf(course);
        buf.writeUtf(raceClass);
        buf.writeUtf(countedClass);
        buf.writeBoolean(classBest);
        buf.writeBoolean(overallBest);
        buf.writeLong(targetBest);
    }

}
