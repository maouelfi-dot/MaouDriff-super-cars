package com.maou.maoudrift.client.effect;

import com.maou.maoudrift.config.ClientConfig;
import com.maou.maoudrift.physics.CarSpec;
import com.maou.maoudrift.physics.Wheel;

/**
 * 未舗装路を走っている車が巻き上げる砂塵。
 *
 * <p><b>{@code CarSmoke} とは出どころが違う。</b>あちらはゴムが熱を持って上がる白煙なので
 * <b>滑らないと出ない</b>。こちらはタイヤが路面の材料そのものを掻き飛ばしているので、
 * <b>滑っていなくても、ただ速く走っているだけで舞う</b>。ラリーの土煙はこちら。</p>
 *
 * <table>
 *   <caption>2 つの効果の違い</caption>
 *   <tr><th></th><th>{@code CarSmoke}</th><th>{@code CarDust}（これ）</th></tr>
 *   <tr><td>出どころ</td><td>摩擦熱</td><td>路面の材料を掻き飛ばす</td></tr>
 *   <tr><td>出る条件</td><td>滑っているとき</td><td>走っているだけで</td></tr>
 *   <tr><td>路面</td><td>どこでも</td><td>未舗装だけ</td></tr>
 *   <tr><td>そのあと</td><td>すぐ消える</td><td>その場に残って昇る</td></tr>
 * </table>
 *
 * <p>掻き飛ばす量は<b>接地面が路面を撫でる速さ</b>で決める
 * （{@link EmitterCar#getRenderScrubSpeed(Wheel)}）。転がって
 * いるだけなら車速そのもので、滑っていればそのぶん上乗せされる——だから<b>全開で流している
 * ほうが、同じ速度で真っ直ぐ走るより濃く舞う</b>。<b>同じ量が砂利の音
 * （{@code CarSound} の {@code GRAVEL}）も決めている</b>ので、見えている土煙と
 * 聞こえている音が食い違わない。これに路面の
 * {@linkplain RoadSurface#dustScale() 舞い上がりやすさ}と接地荷重を掛ける。</p>
 *
 * <p><b>グリップで決めてはいけない。</b>氷はいちばん滑るが固いので何も舞わず、砂はよく滑り
 * よく舞う。滑りやすさと舞いやすさは無関係なので、{@code RoadSurface} に別の数字として
 * 持たせてある（{@code CarSmoke} が摩擦の仕事率をグリップで割り戻しているのとは別の話）。</p>
 *
 * <p><b>濡れていると舞わない。</b>雨のダートは泥であって土煙ではない。
 * {@code Level#isRainingAt} は空が見えるかまで見てくれるので、<b>トンネルや橋の下では
 * 降っていても舞い続ける</b>。{@code CarEntity#getRenderWetness()} を使わないのは、
 * あれが<b>手元で解いている車でしか進まない</b>ため——他人の車が雨の中で土煙を上げてしまう。</p>
 *
 * <p>粒を絞る仕掛けは {@code CarSmoke} と同じ。バニラは 32 ブロックで粒を捨てるので
 * {@code force} で打ち切りを外し、代わりに<b>車のモデルが描かれる範囲</b>で自分で絞る。
 * その判定にカメラが要るのでクライアントのティックに置いてある。</p>
 */
public final class DustEmitter {

    /** これ以下の撫で速さでは舞わない [m/s]。徐行でダートを走っても土煙は立たない。 */
    private static final double MIN_SWEEP = 4.5;
    /** いちばん濃くなる撫で速さ [m/s]。 */
    private static final double FULL_SWEEP = 18.0;
    /** いちばん濃いときに 1 輪から 1 ティックで出す粒の数。 */
    private static final double MAX_PER_WHEEL = 2.0;
    /** 接地荷重の倍率の上限。荷重が乗った輪ほど深く掻くが、際限なくは増やさない。 */
    private static final double MAX_LOAD_FACTOR = 1.5;
    /** サスが伸びきっているとみなす余裕 [m]。ここまで伸びていれば浮いている。 */
    private static final double AIRBORNE_EPSILON = 0.001;

    /** 車速 1 m/s ぶんで後ろへ弾かれる速さ [blocks/tick]。 */
    private static final double KICK_PER_SPEED = 0.010;
    /** 後ろへ弾かれる速さの上限 [blocks/tick]。 */
    private static final double MAX_KICK = 0.30;
    /** 外側（フェンダーの外）へ散る速さ [blocks/tick]。 */
    private static final double SIDE_KICK = 0.04;
    /** 出た瞬間の上向きの速さ [blocks/tick]。 */
    private static final double LIFT_BASE = 0.03;
    /** 濃いほど高く跳ね上げるぶん [blocks/tick]。 */
    private static final double LIFT_PER_INTENSITY = 0.05;
    /** 向きの散らばり [blocks/tick]。 */
    private static final double JITTER = 0.02;
    /** 出る位置の散らばり [m]。 */
    private static final double SPAWN_SPREAD = 0.18;

    private DustEmitter() {
    }

    /**
     * 1 台ぶん、1 ティックの粒を出す。
     *
     * @param xo      前のティックの位置
     * @param raining 車の位置で雨が降っているか（濡れたダートは泥で、土煙は立たない）
     */
    public static void spawn(EmitterCar car, double xo, double yo, double zo, boolean raining, ParticleSink sink) {
        if (raining) {
            // 濡れたダートは泥。土煙は立たない
            return;
        }

        double signedSpeed = car.getRenderSpeed();
        double speed = Math.abs(signedSpeed);
        if (speed <= 0.0) {
            return;
        }
        CarSpec spec = car.getSpec();
        double forwardX = -Math.sin(car.vanillaYaw() * (float) (Math.PI / 180.0));
        double forwardZ = Math.cos(car.vanillaYaw() * (float) (Math.PI / 180.0));
        double rightX = -forwardZ;
        double rightZ = forwardX;
        // 進んでいる向きの逆へ弾き飛ばす。バックなら前へ飛ぶ
        double travel = signedSpeed >= 0.0 ? 1.0 : -1.0;
        double kick = Math.min(MAX_KICK, speed * KICK_PER_SPEED);

        for (Wheel wheel : Wheel.VALUES) {
            // 路面は輪ごとに見る。前輪だけ土に乗ったなら、舞うのは前輪からだけ
            double dustScale = car.getRenderSurface(wheel).dustScale();
            if (dustScale <= 0.0) {
                // 舗装路と氷。掻き飛ばすものが無い
                continue;
            }
            double suspension = car.getRenderSuspensionLength(wheel);
            if (suspension >= spec.suspensionMaxLength() - AIRBORNE_EPSILON) {
                // 浮いている輪は路面に触れていないので何も掻かない
                continue;
            }
            double sweep = car.getRenderScrubSpeed(wheel);
            if (sweep <= MIN_SWEEP) {
                continue;
            }
            double base = Math.min(1.0, (sweep - MIN_SWEEP) / (FULL_SWEEP - MIN_SWEEP));
            double load = Math.min(MAX_LOAD_FACTOR,
                    car.getRenderWheelLoad(wheel) / spec.staticWheelLoad(wheel));
            double intensity = base * dustScale * load;
            if (sink.volumetric()) {
                // 体積の砂塵・雪煙（H メニューの「煙の描き方」が体積のとき）。数と動かし方は TireSmokeVolume が決める
                double forwardOffset = spec.wheelForwardOffset(wheel);
                double rightOffset = spec.wheelRightOffset(wheel);
                double x = car.posX() + forwardX * forwardOffset + rightX * rightOffset;
                double z = car.posZ() + forwardZ * forwardOffset + rightZ * rightOffset;
                double y = car.posY() - suspension - spec.wheelRadius();
                double side = wheel.isLeft() ? -SIDE_KICK : SIDE_KICK;
                sink.emitDust(car.carEntityId() * 4 + wheel.ordinal(), car.getRenderSurface(wheel),
                        x, y, z, car.posX() - xo, car.posY() - yo, car.posZ() - zo,
                        -forwardX * travel * kick + rightX * side, -forwardZ * travel * kick + rightZ * side,
                        intensity);
                continue;
            }
            double rate = intensity * MAX_PER_WHEEL * ClientConfig.dustDensity;
            int count = (int) rate;
            // 端数は確率で 1 つ。切り上げると、ごく薄いときでも必ず 1 つ出てしまう
            if (sink.nextDouble() < rate - count) {
                count++;
            }
            if (count <= 0) {
                continue;
            }

            double forwardOffset = spec.wheelForwardOffset(wheel);
            double rightOffset = spec.wheelRightOffset(wheel);
            double x = car.posX() + forwardX * forwardOffset + rightX * rightOffset;
            double z = car.posZ() + forwardZ * forwardOffset + rightZ * rightOffset;
            // 接地面。サス長とタイヤ半径だけ下
            double y = car.posY() - suspension - spec.wheelRadius();

            double side = wheel.isLeft() ? -SIDE_KICK : SIDE_KICK;
            double lift = LIFT_BASE + LIFT_PER_INTENSITY * intensity;
            for (int i = 0; i < count; i++) {
                double spreadX = (sink.nextDouble() - 0.5) * 2.0 * SPAWN_SPREAD;
                double spreadZ = (sink.nextDouble() - 0.5) * 2.0 * SPAWN_SPREAD;
                double xd = -forwardX * travel * kick + rightX * side + jitter(sink);
                double zd = -forwardZ * travel * kick + rightZ * side + jitter(sink);
                sink.add(sink.dust(), true,
                        x + spreadX, y + 0.05, z + spreadZ,
                        xd, lift, zd);
            }
        }
    }

    private static double jitter(ParticleSink sink) {
        return (sink.nextDouble() - 0.5) * 2.0 * JITTER;
    }
}
