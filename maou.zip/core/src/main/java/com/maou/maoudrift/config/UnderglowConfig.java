package com.maou.maoudrift.config;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Pengaturan lampu kolong (underglow) ala game drift Tokyo. Disimpan di {@code config/maoudrift-underglow.toml}.
 *
 * <p>File dibuat otomatis saat pertama kali game jalan. Warna diatur <b>per mobil</b> lewat baris
 * {@code color_<id mobil> = "#RRGGBB"}. File dibaca ulang otomatis kalau diubah saat game berjalan
 * (dicek tiap beberapa detik), jadi tidak perlu restart.</p>
 *
 * <p>Hanya klien yang memakai ini (murni tampilan), jadi tidak ada yang dikirim ke server.</p>
 */
public final class UnderglowConfig {

    private static final String FILE = "maoudrift-underglow.toml";
    private static final String FALLBACK_HEX = "#B43CFF";

    /** Warna bawaan tiap mobil (id = nama file di vehicles/). */
    private static final Map<String, String> DEFAULTS = new LinkedHashMap<>();

    static {
        DEFAULTS.put("car", "#2FA8FF");
        DEFAULTS.put("krc_supra", "#B43CFF");
        DEFAULTS.put("zacoe_m2", "#FF2D6F");
        DEFAULTS.put("varis_gts", "#22FFA6");
    }

    /** Lampu kolong menyala atau tidak sama sekali. */
    public static volatile boolean enabled = true;
    /** true = hanya terlihat saat gelap (malam, terowongan, garasi). Siang hari mati dan tidak digambar. */
    public static volatile boolean onlyAtNight = true;
    /** false = menyala sendiri saat gelap. true = hanya menyala bila lampu depan (tombol L) hidup. */
    public static volatile boolean requireHeadlights = false;
    /** Kecerahan 0..1.5. 0.6 = natural, tidak menyilaukan. */
    public static volatile double intensity = 0.6;
    /** Seberapa jauh cahaya merembes keluar dari badan mobil [blok/meter]. */
    public static volatile double spread = 0.8;

    private static volatile Map<String, float[]> colors = new HashMap<>();
    private static Path file;
    private static long loadedStamp = Long.MIN_VALUE;
    private static long lastCheck;

    private UnderglowConfig() {
    }

    /** Warna RGB 0..1 untuk mobil dengan id {@code carPath}. Jangan diubah isinya. */
    public static float[] color(String carPath) {
        float[] c = colors.get(carPath);
        return c != null ? c : parseHex(FALLBACK_HEX);
    }

    /** Dipanggil sekali saat klien mulai. */
    public static void load(Path configDir) {
        file = configDir.resolve(FILE);
        try {
            if (!Files.exists(file)) {
                Files.createDirectories(configDir);
                Files.writeString(file, defaultText(), StandardCharsets.UTF_8);
            }
        } catch (IOException ignored) {
            // tidak bisa menulis: pakai bawaan
        }
        reload();
    }

    /** Baca ulang file bila berubah. Murah: hanya menyentuh disk tiap 3 detik. */
    public static void maybeReload() {
        long now = System.currentTimeMillis();
        if (file == null || now - lastCheck < 3000L) {
            return;
        }
        lastCheck = now;
        try {
            long stamp = Files.exists(file) ? Files.getLastModifiedTime(file).toMillis() : Long.MIN_VALUE;
            if (stamp != loadedStamp) {
                reload();
            }
        } catch (IOException ignored) {
            // abaikan
        }
    }

    private static void reload() {
        Map<String, float[]> next = new HashMap<>();
        for (Map.Entry<String, String> e : DEFAULTS.entrySet()) {
            next.put(e.getKey(), parseHex(e.getValue()));
        }
        boolean en = true;
        boolean night = true;
        boolean req = false;
        double inten = 0.6;
        double spr = 0.8;
        try {
            if (file != null && Files.exists(file)) {
                loadedStamp = Files.getLastModifiedTime(file).toMillis();
                Map<String, String> values = TomlLite.read(Files.readString(file, StandardCharsets.UTF_8));
                for (Map.Entry<String, String> e : values.entrySet()) {
                    String key = e.getKey();
                    String raw = e.getValue();
                    switch (key) {
                        case "enabled" -> en = bool(raw, en);
                        case "onlyAtNight" -> night = bool(raw, night);
                        case "requireHeadlights" -> req = bool(raw, req);
                        case "intensity" -> inten = number(raw, inten, 0.0, 1.5);
                        case "spread" -> spr = number(raw, spr, 0.2, 2.0);
                        default -> {
                            if (key.startsWith("color_")) {
                                String hex = TomlLite.parseString(raw);
                                float[] rgb = hex == null ? null : parseHex(hex);
                                if (rgb != null) {
                                    next.put(key.substring("color_".length()), rgb);
                                }
                            }
                        }
                    }
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // file rusak: pakai nilai bawaan
        }
        enabled = en;
        onlyAtNight = night;
        requireHeadlights = req;
        intensity = inten;
        spread = spr;
        colors = next;
    }

    private static boolean bool(String raw, boolean fallback) {
        String t = raw.trim().toLowerCase(Locale.ROOT);
        if (t.equals("true")) {
            return true;
        }
        if (t.equals("false")) {
            return false;
        }
        return fallback;
    }

    private static double number(String raw, double fallback, double min, double max) {
        try {
            double v = Double.parseDouble(raw.trim());
            return Double.isNaN(v) ? fallback : Math.max(min, Math.min(max, v));
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    /** "#RRGGBB" atau "RRGGBB" menjadi rgb 0..1. Null kalau tidak terbaca. */
    private static float[] parseHex(String text) {
        String t = text.trim();
        if (t.startsWith("#")) {
            t = t.substring(1);
        }
        if (t.length() != 6) {
            return null;
        }
        try {
            int v = Integer.parseInt(t, 16);
            return new float[] {(v >> 16 & 0xFF) / 255.0F, (v >> 8 & 0xFF) / 255.0F, (v & 0xFF) / 255.0F};
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private static String defaultText() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Maou Drift - Lampu kolong (underglow) ala game drift Tokyo\n");
        sb.append("# File ini dibaca ulang otomatis saat diubah (tidak perlu restart game).\n\n");
        sb.append("# Nyalakan / matikan lampu kolong\nenabled = true\n\n");
        sb.append("# true = hanya terlihat saat gelap (malam / terowongan). Siang hari mati dan tidak membebani HP\nonlyAtNight = true\n\n");
        sb.append("# false = menyala sendiri saat gelap. true = hanya menyala kalau lampu depan (tombol L) hidup\nrequireHeadlights = false\n\n");
        sb.append("# Kecerahan 0.0 - 1.5. 0.6 = natural, tidak terlalu terang\nintensity = 0.6\n\n");
        sb.append("# Seberapa jauh cahaya merembes keluar dari badan mobil (meter), 0.2 - 2.0\nspread = 0.8\n\n");
        sb.append("# Warna per mobil, format \"#RRGGBB\". Nama setelah color_ = id mobil\n");
        for (Map.Entry<String, String> e : DEFAULTS.entrySet()) {
            sb.append("color_").append(e.getKey()).append(" = \"").append(e.getValue()).append("\"\n");
        }
        return sb.toString();
    }
}
