package com.maou.maoudrift.part;

import com.maou.maoudrift.car.CarId;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * いま読み込まれている部品の一覧。<b>サーバーとクライアントの両方が同じものを持つ。</b>
 *
 * <ul>
 *   <li>サーバー … {@link CarPartLoader} がデータパックから読んで入れる</li>
 *   <li>クライアント … サーバーから {@code CarPartTypesPacket} で配られたものを入れる</li>
 * </ul>
 *
 * <p><b>クライアントが自分でデータパックを読んではいけない。</b>{@code CarTypes} と同じ話で、
 * マルチプレイで何を履けるか決めるのはサーバーであって手元のカーパックではない。
 * 配られたものだけを見る、で揃えておけば、サーバーが知らない部品が換装画面に並ぶことがない。</p>
 *
 * <p><b>一覧に無い id を「装着していない」ことにはしない。</b>装着状態
 * （{@link PartFitment}）は id をそのまま覚えるので、カーパックを外しても
 * 見た目が既定へ落ちるだけで、入れ直せば元に戻る。</p>
 */
public final class CarParts {

    private static Map<CarId, CarPart> parts = Map.of();
    private static List<CarPart> sorted = List.of();

    private CarParts() {
    }

    /** 一覧を入れ替える。データパックの読み込みと、サーバーからの受信で呼ぶ。 */
    public static void replaceAll(Collection<CarPart> loaded) {
        Map<CarId, CarPart> next = new LinkedHashMap<>();
        for (CarPart part : loaded) {
            next.put(part.id(), part);
        }
        List<CarPart> list = new ArrayList<>(next.values());
        list.sort(Comparator.comparingInt(CarPart::order).thenComparing(part -> part.id().toString()));

        parts = Map.copyOf(next);
        sorted = List.copyOf(list);
        generation++;
    }

    /**
     * 一覧が入れ替わった回数。部品の性能（ターボ）を諸元へ載せている側が、
     * データパックの再読み込みで値が変わったことに気づくのに使う。
     */
    private static int generation;

    public static int generation() {
        return generation;
    }

    /** その id の部品。<b>知らない id なら null。</b> */
    @Nullable
    public static CarPart get(CarId id) {
        return parts.get(id);
    }

    /** 並び順に整列した一覧。 */
    public static List<CarPart> all() {
        return sorted;
    }

    /**
     * その車種のその場所に付けられる部品。換装画面が並べる一覧。
     *
     * @param carId 車種。null なら車種で絞らない
     */
    public static List<CarPart> forSlot(PartSlot slot, @Nullable CarId carId) {
        List<CarPart> list = new ArrayList<>();
        for (CarPart part : sorted) {
            if (part.slot() == slot && part.fits(carId)) {
                list.add(part);
            }
        }
        return list;
    }
}
