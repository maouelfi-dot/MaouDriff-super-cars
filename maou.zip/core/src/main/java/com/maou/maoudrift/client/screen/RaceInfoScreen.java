package com.maou.maoudrift.client.screen;

import com.maou.maoudrift.client.ui.Slant;
import com.maou.maoudrift.client.ui.UiButton;
import com.maou.maoudrift.client.ui.UiEditBox;
import com.maou.maoudrift.client.ui.UiFont;
import com.maou.maoudrift.client.ui.UiGraphics;
import com.maou.maoudrift.client.ui.UiKey;
import com.maou.maoudrift.client.ui.UiPressable;
import com.maou.maoudrift.client.ui.UiScreen;
import com.maou.maoudrift.client.ui.UiTooltip;
import com.maou.maoudrift.race.RaceCar;
import com.maou.maoudrift.race.RaceEngine;
import com.maou.maoudrift.race.RaceText;

import com.maou.maoudrift.network.RaceActionPacket;
import com.maou.maoudrift.network.RaceLobbyPacket;
import com.maou.maoudrift.tuning.Regulation;

import java.util.List;
import com.maou.maoudrift.client.race.RaceClient;
import com.maou.maoudrift.client.hud.RaceHud;
import com.maou.maoudrift.client.race.RaceLobby;

/**
 * 参加したレースの画面（参加中に K）。<b>そのレースの情報と参加者だけを見る。</b>
 *
 * <p>コースを選ぶ場所は持たない——1 つのワールドで開かれるレースは 1 つで、
 * 参加した人が知りたいのはそのレースのことだけだから。</p>
 *
 * <p>走りながら開く画面なので、ゲームは止めない。</p>
 */
public final class RaceInfoScreen extends UiScreen {

    private static final int ROW = 20;

    private UiButton leave;
    private UiButton join;
    /** 観戦に切り替える。エントリーせず、レースの HUD だけを見る。 */
    private UiButton spectate;
    private UiButton unspectate;
    /** 終える（受付中は中止）。主催者がいない間の参加者と OP に出す（サーバーの canManage と同じ人）。 */
    private UiButton stop;

    public RaceInfoScreen() {
        super(RaceText.translatable("screen.maoudrift.race_info.title"));
    }

    @Override
    protected void init() {
        int left = (width - panelWidth()) / 2;
        int right = left + panelWidth();
        int y = height - 34;
        for (RaceTabs.Tab tab : RaceTabs.create(left, 6, RaceTabs.Page.RACE)) {
            addRenderableWidget(tab);
        }
        leave = addRenderableWidget(UiButton.builder(RaceText.translatable("screen.maoudrift.race_info.leave"),
                        button -> RaceClient.get().sendToServer(RaceActionPacket.of(RaceActionPacket.Action.LEAVE)))
                .bounds(right - 90, y, 90, 20).build());
        join = addRenderableWidget(UiButton.builder(RaceText.translatable("screen.maoudrift.race_info.join"),
                        button -> RaceClient.get().sendToServer(RaceActionPacket.of(RaceActionPacket.Action.JOIN)))
                .bounds(right - 90, y, 90, 20).build());
        spectate = addRenderableWidget(UiButton.builder(RaceText.translatable("screen.maoudrift.race_info.spectate"),
                        button -> RaceClient.get().sendToServer(RaceActionPacket.of(RaceActionPacket.Action.SPECTATE)))
                .bounds(right - 184, y, 90, 20).build());
        stop = addRenderableWidget(UiButton.builder(RaceText.empty(), button -> {
                    RaceClient.get().sendToServer(RaceActionPacket.of(RaceActionPacket.Action.STOP));
                    onClose();
                }).bounds(right - 278, y, 90, 20).build());
        unspectate = addRenderableWidget(UiButton.builder(RaceText.translatable("screen.maoudrift.race_info.unspectate"),
                        button -> RaceClient.get().sendToServer(RaceActionPacket.of(RaceActionPacket.Action.UNSPECTATE)))
                .bounds(right - 184, y, 90, 20).build());
    }

    private int panelWidth() {
        // 枠（フル HD の幅が上限）いっぱいに広げる
        return UiFrame.width(width) - 24;
    }

    @Override
    public void tick() {
        RaceLobbyPacket lobby = RaceLobby.lobby();
        if (lobby == null) {
            onClose();
            return;
        }
        boolean open = lobby.phase() == RaceLobbyPacket.Phase.OPEN;
        boolean result = lobby.phase() == RaceLobbyPacket.Phase.RESULT;
        // ゴールした人とリザルトの間は抜けられない（抜けるとリザルトから消える。サーバーも断る）
        leave.visible = lobby.joined() && !result && !RaceHud.hasFinished();
        join.visible = !lobby.joined() && open;
        // ゴールした人とリザルトの間は切り替えない（リザルトに残すため）
        spectate.visible = !lobby.spectating() && !result && !(lobby.joined() && RaceHud.hasFinished());
        unspectate.visible = lobby.spectating();
        // 主催者がいなくなった走行中のレースを、残った参加者と OP が画面から畳めるように
        stop.visible = lobby.canManage() && !lobby.isHost() && !result;
        stop.setMessage(RaceText.translatable(lobby.phase() == RaceLobbyPacket.Phase.RUNNING
                ? "screen.maoudrift.race_host.stop" : "screen.maoudrift.race_host.cancel"));
    }

    @Override
    public void renderBackground(UiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // ワールドの中では半透明の暗幕（ぼかし無し）、外では普通の背景（版の画面が描き分ける）
        super.renderBackground(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public void render(UiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        RaceLobbyPacket lobby = RaceLobby.lobby();
        if (lobby == null) {
            return;
        }
        UiFont font = this.font;
        int panel = panelWidth();
        int left = (width - panel) / 2;
        int top = Math.max(26, height / 2 - 120);

        // 見出しの帯
        String tag = lobby.spectating() && lobby.phase() != RaceLobbyPacket.Phase.RESULT ? "WATCHING"
                : switch (lobby.phase()) {
            case OPEN -> lobby.joined() ? "ENTERED" : "ENTRY OPEN";
            case COUNTDOWN, RUNNING -> "LIVE";
            case RESULT -> "RESULT";
            default -> "";
        };
        int tagWidth = font.width(tag) + 14;
        boolean entered = lobby.joined() && lobby.phase() == RaceLobbyPacket.Phase.OPEN;
        Slant.fill(graphics, left, top, tagWidth, 17, entered || lobby.phase() != RaceLobbyPacket.Phase.OPEN
                ? RaceLobby.WHITE : RaceLobby.ACCENT);
        Slant.text(graphics, font, tag, left + 7, top + 5, entered || lobby.phase() != RaceLobbyPacket.Phase.OPEN
                ? RaceLobby.INK : RaceLobby.WHITE);
        Slant.fill(graphics, left + tagWidth, top, panel - tagWidth, 17, RaceLobby.PANEL);
        RaceText host = lobby.bestMillis() > 0
                ? RaceText.translatable("screen.maoudrift.race_info.host_best", lobby.hostName(),
                RaceEngine.format(lobby.bestMillis()))
                : RaceText.translatable("screen.maoudrift.race_info.host", lobby.hostName());
        int hostWidth = Math.min(font.width(host), (panel - tagWidth) / 2);
        Slant.fit(graphics, font, host, left + panel - 8 - hostWidth, top + 5, hostWidth, RaceLobby.GREY);
        Slant.fit(graphics, font, RaceText.translatable("screen.maoudrift.race_info.course",
                lobby.course(), lobby.laps(), lobby.checkpoints()), left + tagWidth + 7, top + 5,
                panel - tagWidth - 7 - hostWidth - 16, RaceLobby.WHITE);

        // 左: 決まりと自分の車の値／右: 参加者
        int columnTop = top + 19;
        int half = (panel - 2) / 2;
        Regulation regulation = RaceLobby.regulation();
        List<RaceLobby.Rule> rules = RaceLobby.rules(regulation);
        RaceLobbyPacket.Entrant self = RaceLobby.self();

        graphics.fill(left, columnTop, left + half, columnTop + 13, RaceLobby.PANEL);
        Slant.text(graphics, font, "REGULATION", left + 7, columnTop + 3, RaceLobby.WHITE);
        RaceText mineHead = RaceText.translatable("screen.maoudrift.race_info.rule_mine");
        Slant.text(graphics, font, mineHead, left + half - 7 - font.width(mineHead), columnTop + 3, RaceLobby.GREY);
        // クラスで開いたレースなら、見出しの横にクラスの名前
        String className = RaceLobby.classNameOf(regulation);
        if (className != null) {
            int classX = left + 7 + font.width("REGULATION") + 8;
            int room = left + half - 7 - font.width(mineHead) - 14 - classX;
            if (room > 12) {
                int shown = Math.min(font.width(className), room);
                Slant.fill(graphics, classX - 4, columnTop + 1, shown + 10, 11, RaceLobby.ACCENT);
                Slant.fit(graphics, font, RaceText.literal(className), classX + 1, columnTop + 3, room,
                        RaceLobby.WHITE);
            }
        }
        int y = columnTop + 14;
        if (rules.isEmpty()) {
            graphics.fill(left, y, left + half, y + ROW - 1, RaceLobby.PANEL_LIGHT);
            Slant.text(graphics, font, RaceText.translatable("race.maoudrift.rule.free"), left + 7, y + 6,
                    RaceLobby.GREY);
            y += ROW;
        }
        for (int i = 0; i < rules.size(); i++) {
            RaceLobby.Rule rule = rules.get(i);
            graphics.fill(left, y, left + half, y + ROW - 1, (i & 1) == 0 ? RaceLobby.PANEL : RaceLobby.PANEL_LIGHT);
            Slant.text(graphics, font, rule.label(), left + 7, y + 6, RaceLobby.WHITE);
            String mine = RaceLobby.myValue(rule.kind());
            boolean bad = self != null && self.violations().stream().anyMatch(v -> sameRule(v.kind(), rule.kind()));
            int mineWidth = font.width(mine);
            int mineX = left + half - 7 - mineWidth;
            if (bad) {
                graphics.fill(mineX - 3, y + 3, left + half - 4, y + ROW - 4, RaceLobby.NG);
            }
            Slant.text(graphics, font, mine, mineX, y + 6, bad ? RaceLobby.WHITE : RaceLobby.OK_DOT);
            Slant.text(graphics, font, rule.rule(), mineX - 10 - font.width(rule.rule()), y + 6, RaceLobby.WHITE);
            y += ROW;
        }
        int leftBottom = y;

        int rightLeft = left + half + 2;
        int rightWidth = panel - half - 2;
        graphics.fill(rightLeft, columnTop, rightLeft + rightWidth, columnTop + 13, RaceLobby.PANEL);
        Slant.text(graphics, font, "ENTRANTS " + lobby.entrants().size(), rightLeft + 7, columnTop + 3, RaceLobby.WHITE);
        y = columnTop + 14;
        for (int i = 0; i < lobby.entrants().size(); i++) {
            RaceLobbyPacket.Entrant entrant = lobby.entrants().get(i);
            graphics.fill(rightLeft, y, rightLeft + rightWidth, y + ROW - 1,
                    lobby.isSelf(i) ? 0x40FFFFFF : (i & 1) == 0 ? RaceLobby.PANEL : RaceLobby.PANEL_LIGHT);
            if (lobby.isSelf(i)) {
                graphics.fill(rightLeft, y, rightLeft + 2, y + ROW - 1, RaceLobby.ACCENT);
            }
            Slant.fit(graphics, font, entrant.name(), rightLeft + 7, y + 6, 80, RaceLobby.WHITE);
            verdictBadge(graphics, font, entrant, rightLeft + rightWidth - 6, y + 4);
            Slant.fit(graphics, font, RaceLobby.carName(entrant.carId()), rightLeft + 92, y + 6, rightWidth - 150,
                    RaceLobby.GREY);
            y += ROW;
        }
        int bottom = Math.max(leftBottom, y) + 6;

        // 自分の判定
        if (self != null) {
            boolean ok = self.verdict() == RaceLobbyPacket.Verdict.OK;
            boolean noCar = self.verdict() == RaceLobbyPacket.Verdict.NO_CAR;
            int color = ok ? RaceLobby.OK : noCar ? 0xFF3A3A3A : RaceLobby.NG;
            int text = RaceLobby.WHITE;
            Slant.fill(graphics, left, bottom, panel, 22, color);
            RaceText title = ok ? RaceText.translatable(lobby.phase() == RaceLobbyPacket.Phase.OPEN
                    ? "screen.maoudrift.race_info.ok_waiting" : "screen.maoudrift.race_info.ok")
                    : noCar ? RaceText.translatable("screen.maoudrift.race_info.no_car")
                    : RaceText.translatable("screen.maoudrift.race_info.violation",
                    RaceLobby.describeAll(self.violations()));
            Slant.text(graphics, font, title, left + 10, bottom + 7, text);
            RaceText sub = RaceText.translatable(ok
                    ? "screen.maoudrift.race_info.ok_sub" : "screen.maoudrift.race_info.violation_sub");
            if (!noCar) {
                Slant.text(graphics, font, sub, left + panel - 10 - font.width(sub), bottom + 7, text);
            }
        }

        RaceText hint = RaceText.translatable("screen.maoudrift.race_info.hint",
                RaceClient.get().openRaceKey());
        graphics.drawString(font, hint, left, height - 28, RaceLobby.GREY, false);
    }

    /** 決まりの行と違反の種類が同じものを指すか。運転補助は 1 行にまとめてある。 */
    private static boolean sameRule(Regulation.Kind violation, Regulation.Kind rule) {
        boolean assist = violation == Regulation.Kind.TRACTION_CONTROL || violation == Regulation.Kind.ABS;
        boolean assistRule = rule == Regulation.Kind.TRACTION_CONTROL || rule == Regulation.Kind.ABS;
        return assist ? assistRule : violation == rule;
    }

    /** 判定の札の幅。左端で揃えたいときに、右端を求めるのに使う。 */
    static int verdictBadgeWidth(UiFont font, RaceLobbyPacket.Entrant entrant) {
        return font.width(verdictLabel(entrant)) + 8;
    }

    private static RaceText verdictLabel(RaceLobbyPacket.Entrant entrant) {
        return switch (entrant.verdict()) {
            case OK -> RaceText.translatable("race.maoudrift.verdict.ok");
            case VIOLATION -> RaceText.translatable("race.maoudrift.verdict.violation");
            case NO_CAR -> RaceText.translatable("race.maoudrift.verdict.no_car");
        };
    }

    /** 判定の札。右端を {@code right} に揃える。 */
    static void verdictBadge(UiGraphics graphics, UiFont font, RaceLobbyPacket.Entrant entrant, int right, int y) {
        RaceText label = verdictLabel(entrant);
        int w = font.width(label) + 8;
        int bg = switch (entrant.verdict()) {
            case OK -> RaceLobby.OK;
            case VIOLATION -> RaceLobby.NG;
            case NO_CAR -> 0xFF3A3A3A;
        };
        graphics.fill(right - w, y, right, y + 11, bg);
        graphics.drawString(font, label, right - w + 4, y + 2,
                RaceLobby.WHITE, false);
    }

    @Override
    public boolean keyPressed(UiKey key) {
        if (key.openRace()) {
            onClose();
            return true;
        }
        if (key.driving()) {
            return true;
        }
        return super.keyPressed(key);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
