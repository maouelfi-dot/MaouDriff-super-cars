package com.maou.maoudrift.network;

import com.maou.maoudrift.car.CarType;
import com.maou.maoudrift.car.CarTypes;
import com.maou.maoudrift.tuning.CarSpecCodec;

import java.util.ArrayList;
import java.util.List;

/**
 * サーバー → クライアント。読み込まれている車種を丸ごと配る。
 *
 * <p>送るのはログイン時とデータパックの再読み込み時（{@code OnDatapackSyncEvent}）。
 * 車種は走行中に増えないので、差分ではなく毎回まるごと送る。</p>
 *
 * <p><b>クライアントが自分でデータパックを読まないのが要点。</b>シングルプレイなら
 * 同じプロセスなので読めてしまうが、マルチプレイで車種を決めるのはサーバーであって
 * 手元のカーパックではない。「配られたものだけを見る」で揃えておけば、
 * サーバーに無い車がクリエイティブタブに並ぶ、ということが起きない。</p>
 *
 * <p>クライアントが車種を知る必要があるのは次の 3 つ。<b>走っている車の諸元そのものは
 * これとは別に、車のスポーンデータと {@link CarSpecPacket} が運ぶ</b>（調整画面でいじった
 * 結果は車種の諸元とは違うものになるため）。</p>
 *
 * <ul>
 *   <li>クリエイティブタブに車種ぶんのアイテムを並べる</li>
 *   <li>アイテムと車の名前を出す</li>
 *   <li>調整画面の「戻す」で、既定値ではなく<b>その車種の値</b>へ戻す</li>
 * </ul>
 */
public record CarTypesPacket(List<CarType> types) implements RacePayload {

    public CarTypesPacket(RaceBuf buf) {
        this(read(buf));
    }

    private static List<CarType> read(RaceBuf buf) {
        int count = buf.readVarInt();
        List<CarType> types = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            var id = buf.readCarId();
            var spec = CarSpecCodec.read(buf);
            int order = buf.readVarInt();
            var defaults = new java.util.EnumMap<com.maou.maoudrift.part.PartSlot, CarType.DefaultPart>(
                    com.maou.maoudrift.part.PartSlot.class);
            int count2 = buf.readVarInt();
            for (int j = 0; j < count2; j++) {
                // 知らない場所でも最後まで読む。途中で止めると後ろがずれる
                var slot = com.maou.maoudrift.part.PartSlot.byName(buf.readUtf());
                var part = new CarType.DefaultPart(buf.readCarId(), buf.readBoolean());
                if (slot != null) {
                    defaults.put(slot, part);
                }
            }
            types.add(new CarType(id, spec, order, defaults));
        }
        return types;
    }

    public void encode(RaceBuf buf) {
        buf.writeVarInt(types.size());
        for (CarType type : types) {
            buf.writeCarId(type.id());
            CarSpecCodec.write(buf, type.spec());
            buf.writeVarInt(type.order());
            // 初期装備。描くのも諸元を組むのもクライアントがするので、同じものを持っていなければならない
            buf.writeVarInt(type.defaultParts().size());
            type.defaultParts().forEach((slot, part) -> {
                buf.writeUtf(slot.getSerializedName());
                buf.writeCarId(part.part());
                buf.writeBoolean(part.removable());
            });
        }
    }

    /** いま読み込まれている車種を全部詰めたパケット。 */
    public static CarTypesPacket current() {
        return new CarTypesPacket(CarTypes.all());
    }

}
