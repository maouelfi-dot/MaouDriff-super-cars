package com.maou.maoudrift.client.model;

import com.maou.maoudrift.car.CarId;
import org.slf4j.Logger;
import java.io.BufferedReader;
import java.io.IOException;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.maou.maoudrift.client.Assets;
import com.maou.maoudrift.client.input.SteeringWheelAxis;
import com.maou.maoudrift.client.Vec3d;

/**
 * Blender から書き出した Wavefront OBJ を読んで描くモデル。
 *
 * <p>GeckoLib（Bedrock の geo.json）は<b>箱しか描けない</b>ので、Blender の任意メッシュは載らない。
 * Blockbench に OBJ を読ませてもメッシュ要素になって Bedrock 形式では保存できないため、
 * 造形をそのまま使うには OBJ を自分で読むしかない。</p>
 *
 * <h2>座標系</h2>
 *
 * <p>読み込み時に <b>X と Z を反転</b>して、そのまま
 * {@link CarObjRenderer#applyRotations 姿勢を掛けたあとのエンティティ空間}
 * （+X が車体右・+Y が上・<b>-Z が車体前方</b>）へ移す。これにより Blender 側は
 * <b>標準の向き（前方 -Y・上 +Z）と標準のエクスポート設定（-Z Forward / Y Up）のまま</b>でよい。</p>
 *
 * <p>この符号は推測ではなく Blender 5.2 で実測して決めた。既定のエクスポート設定は
 * Blender の {@code (x, y, z)} を OBJ の {@code (x, z, -y)} にするので、
 * <b>Blender の慣習的な前方 -Y は OBJ では +Z になる</b>（設定名が「-Z Forward」なので
 * -Z になりそうに見えるが、そうはならない）。ここで 180 度回してやる必要がある。</p>
 *
 * <h2>単位</h2>
 *
 * <p><b>モデルはメートルで作る。</b>エンティティ空間も 1 ブロック = 1m なので拡大率は 1.0 が基準。
 * 諸元に合わせた拡大は {@link CarObjRenderer} 側が掛ける。</p>
 *
 * <h2>UV</h2>
 *
 * <p>OBJ の V 軸は下が 0、Minecraft のテクスチャは上が 0 なので、読み込み時に反転する。
 * Blender 側で気にする必要はない。</p>
 *
 * <h2>半透明（ガラス）</h2>
 *
 * <p><b>テクスチャに半透明の画素を置くだけでは透けない。</b>車体を描いている
 * {@code entityCutoutNoCull} は「α が 0.1 未満なら捨てる、それ以外は不透明」でしか扱わない
 * （シェーダに混色そのものが無い）ので、α 128 の窓は<b>べったり不透明</b>に出る。
 * 透かすには<b>別の {@code RenderType} で、車体を描いた後に描き直す</b>しかない。</p>
 *
 * <p>そこで頂点ごとに不透明度を持たせ、{@link Pass} で 2 回に分けて描く。
 * <b>どちらのパスへ行くかは頂点の α ひとつで決まる</b>——名前を見るのは読み込みのときだけで、
 * 描画中に名前を照合しない。α の決まり方:</p>
 *
 * <ol>
 *   <li>MTL に {@code d}（または {@code Tr}）が書いてあればその値。Blender では
 *       マテリアルの <b>Alpha</b> がそのまま出る</li>
 *   <li>書いていなくて、オブジェクト名が {@value #GLASS_PREFIX} で始まるなら
 *       {@value #GLASS_DEFAULT_ALPHA}。<b>マテリアルを割り当てていないメッシュでも
 *       名前だけで透けさせられる</b>ようにするための逃げ道</li>
 *   <li>どちらでもなければ 1.0（不透明）</li>
 * </ol>
 *
 * <p>{@link #LIGHT_PREFIX} と違い、<b>知らない {@code glass*} を足しても穴は開かない</b>。
 * 車体のパスから外れたぶんは必ず半透明のパスが拾うので、描かれなくなることがない。</p>
 */
public class ObjMesh implements MeshShape {

    protected static final Logger LOGGER = org.slf4j.LoggerFactory.getLogger(ObjMesh.class);

    /** 頂点 1 つあたりの float 数。位置 3・法線 3・UV 2・色 3・不透明度 1。 */
    protected static final int STRIDE = 12;

    /** 頂点の中の不透明度の位置。 */
    protected static final int ALPHA_OFFSET = 11;

    /** {@link #isUvMapped} が「展開されている」と見なす UV の広がり。512px で約 1 画素。 */
    protected static final float UV_MAPPED_EPSILON = 0.002F;

    /**
     * ガラスの名前の頭。{@code glass} / {@code glass_side} / {@code glass.001} が当たる
     * （{@code glasshouse} は当たらない）。
     *
     * <p><b>これは既定値を与えるだけで、透けるかどうかを決めているのは頂点の α。</b>
     * MTL が {@code d} を書いていればそちらが勝つ。</p>
     */
    public static final String GLASS_PREFIX = "glass";

    /** 同じ平面と見なす法線の一致（cos 5 度）。 */
    protected static final double COPLANAR_COS = 0.996;
    /** 同じ平面と見なす面までの距離 [m]。 */
    protected static final double COPLANAR_GAP = 0.002;

    /** マテリアルが透明度を書いていないガラスの不透明度。 */
    protected static final float GLASS_DEFAULT_ALPHA = 0.35F;

    /**
     * これ以上を「不透明」と見なす。
     *
     * <p>Blender は不透明なマテリアルにも {@code d 1.000000} と必ず書くので素通しの比較で
     * 足りるが、他のツールが {@code 0.999999} と書いても拾えるようにしてある。</p>
     */
    protected static final float OPAQUE_THRESHOLD = 0.999F;

    /** どちらの描画パスか。{@code CarObjRenderer#draw} が 2 回に分けて呼ぶ。 */
    public enum Pass {
        /** 不透明な面。{@code entityCutoutNoCull} で先に描く */
        OPAQUE,
        /** 透ける面。{@code entityTranslucent} で車体の後に描く */
        TRANSLUCENT
    }

    /**
     * この名前で始まるオブジェクトは描かない。
     *
     * <p>{@code tools/blender_gauge.py} が置く基準の枠。<b>書き出しから外し忘れて
     * 混ざっても、車と一緒に地面や円柱が描かれることがないように。</b>Blender 側では
     * 「Selected Only」で車体だけを出すのが正しいが、毎回チェックするのは忘れやすい。</p>
     */
    protected static final String GAUGE_PREFIX = "gauge_";

    /** 読み込んだモデルの置き場。リソースの再読み込み（F3+T）で捨てる。 */
    protected static final Map<CarId, ObjMesh> CACHE = new HashMap<>();

    /** 面を持たない、描いても何も起きないモデル。読み込みに失敗したときに返す。 */
    /** 空のメッシュ（読めなかったとき）。作り方が置かれてから作る。 */
    private static ObjMesh empty;

    protected static ObjMesh empty() {
        if (empty == null) {
            empty = create(new float[0], List.of());
        }
        return empty;
    }

    /**
     * 光る部分の名前の頭。この名前で始まるオブジェクトは車体とは別に描く。
     *
     * <p>Blender 側は<b>役割ごとに 1 オブジェクト</b>あればよく、左右に分ける必要はない
     * （ミラーモディファイアがそのまま使える）。光の筋を出す位置は、中心線の左右で
     * 頂点を振り分けてそれぞれの重心から求める。</p>
     */
    public static final String LIGHT_PREFIX = "light_";

    /**
     * ホイールのメッシュに付属しているタイヤのオブジェクト名の頭（大文字小文字を問わない）。
     * タイヤ部品を履いたらこれを隠して、選んだタイヤを描く。
     */
    public static final String TIRE_PREFIX = "tire";

    /**
     * サスペンションのオブジェクト名の頭（大文字小文字を問わない）。
     * シェーダーパックの影には落とさない（ホイールのリムと同じ扱い。地面にアームやバネの模様が出ない）。
     */
    public static final String SUSPENSION_PREFIX = "susp";

    /**
     * 鏡面の名前の頭。{@code mirror_rear}（ルームミラー）/ {@code mirror_left} /
     * {@code mirror_right}。
     *
     * <p><b>左右のドアミラーは別々のオブジェクトにすること。</b>{@link #LIGHT_PREFIX} と違い、
     * ミラーは 1 枚ごとに<b>自分の視点から世界を描き直す</b>ので、ミラーモディファイアで
     * 1 オブジェクトにまとめると左右で同じ景色が映る。</p>
     *
     * <p>位置・向き・大きさは<b>メッシュから読む</b>（{@link MirrorFace}）ので、JSON に
     * 座標を書く必要はない。</p>
     */
    public static final String MIRROR_PREFIX = "mirror_";

    /**
     * ハンドルの名前の頭（大文字小文字を問わない）。{@code steering_wheel} など。
     *
     * <p><b>回る部分（リムとスポーク）だけを分けること。</b>コラムカバーまで入れると平たい板にならず、
     * 軸が取れない（Prado の {@code int_steering} は幅 50cm・奥行き 44cm の塊で弾かれた）。
     * 回す中心と軸は形から読む（{@link SteeringWheelAxis}）ので、JSON に何も書かなくてよい。</p>
     */
    public static final String STEERING_PREFIX = "steering";

    /**
     * 部品の形の名前の頭。<b>この名前で始まるオブジェクトはふだん描かず、その部品を付けたときだけ描く</b>
     * （どの部品で出すかは {@code CarModel#partObjects} と、名前の決まり {@code part_<部品のパス>}）。
     *
     * <p>ウイングやリップのような車体に固定された部品は、車体と一緒に Blender で作れば
     * 位置も大きさも最初から合う。取り付け位置を JSON に書く必要がない。</p>
     *
     * <p><b>純正の形（純正スポイラーなど）も部品として作る。</b>車の諸元側の {@code default_parts} で
     * 初期装備にしておけば、何も付けていないときに出て、別の部品に付け替えると消える。</p>
     */
    public static final String PART_PREFIX = MeshShape.PART_PREFIX;

    /**
     * ナンバーの字の枠（{@code text_<欄>}）。<b>描かない。</b>位置と大きさだけ読み（{@link #textFrames}）、
     * その上に MOD が字を描く。プレートの部品のメッシュにだけ置く。
     */
    public static final String TEXT_PREFIX = "text_";

    /**
     * 面 1 つあたりの float 数。<b>どの面も 4 頂点で持つ</b>——四角形はそのまま、
     * 三角形は 3 番目の頂点を 2 回（縮退四角形）。描くときに形で分岐しなくて済む。
     */
    protected static final int FACE_FLOATS = STRIDE * 4;

    protected static final int[] NO_FACES = new int[0];

    /** 面の頂点が 4 つずつ（{@link #FACE_FLOATS}）並んだもの。 */
    protected final float[] vertices;
    protected final int faceCount;
    /** オブジェクトごとの範囲（面の番号）。 */
    protected final List<Group> groups;
    /**
     * どのパスでどの面を描くか。<b>読み込みのときに振り分けておく</b>。
     *
     * <p>以前は描くたびに全面を回り、面ごとにオブジェクト一覧を線形に探して名前を
     * 照合していた（灯火 1 つ描くのにも車体を丸ごと 1 周）。答えは走行中に変わらないので、
     * 毎フレーム計算し直す理由がない。</p>
     */
    protected final int[] opaqueFaces;
    protected final int[] translucentFaces;
    /** タイヤ（{@link #TIRE_PREFIX}）を除いた面。タイヤを別に描くときのホイール。 */
    protected final int[] opaqueRimFaces;
    protected final int[] translucentRimFaces;
    /** 付属のタイヤ（{@link #TIRE_PREFIX}）の不透明な面だけ。シェーダーパックの影にタイヤだけ落とすときに使う。 */
    protected final int[] opaqueTireFaces;
    /** サスペンション（{@link #SUSPENSION_PREFIX}）を除いた不透明な面。シェーダーパックの影を描くときに使う。 */
    protected final int[] opaqueShadowFaces;
    /** タイヤの面が 1 つでもあるか。 */
    protected final boolean hasTire;
    /** タイヤの面の半径の範囲 {内径, 外径}。タイヤが無ければ null。 */
    protected final double[] tireRadialRange;
    /** タイヤ以外の面のいちばん外の半径（リムの外縁）。 */
    protected final double rimOuterRadius;
    /** 全部の面の半径の範囲 {内径, 外径}。タイヤ部品のメッシュはこちらを使う。 */
    protected final double[] radialRange;
    /** オブジェクト名 → その面。灯火のレンズのように名指しで描くときに使う。 */
    protected final Map<String, int[]> facesByName;
    /** 鏡面。読み込みのときに 1 度だけ measure しておく。 */
    protected final List<MirrorFace> mirrors;
    /** ハンドル（{@link #STEERING_PREFIX}）の {不透明な面, 透ける面}。本体の面からは外してある。 */
    protected final int[][] steeringFaces;
    /**
     * ハンドルを形から測った中心と軸。平たいと言えなければ null（回さずに描く）。
     * 初めて要ったときに測る——JSON でコラムの角度を書いた車では測らない（測れない形なら警告が無駄に出る）。
     */
    @Nullable
    protected SteeringWheelAxis.Result steeringAxis;
    protected boolean steeringMeasured;
    /** コラムの角度（{@code steering.column}）ごとの中心と軸。同じメッシュを角度の違う車種で使うことがある。 */
    protected final Map<Double, SteeringWheelAxis.Result> steeringByColumn = new HashMap<>();
    /**
     * 部品の形（{@link #PART_PREFIX}）の名前 → {不透明な面, 透ける面}。
     * 本体の面（{@link #opaqueFaces} など）からは外してある。
     */
    protected final Map<String, int[][]> optionalFaces;

    /**
     * 遠くの車に使う、頂点を間引いた版（{@link #lod}）。添字が段階で、0（元のまま）は使わない。
     * 初めて要るときに作る。
     */
    // 長さは定数で書くこと。LOD_CELLS（static）を見ると、クラスの読み込み中に作られる empty() から
    // まだ用意されていない表を読むことになって、クラスの初期化ごと落ちる（実際に落ちた）
    protected final ObjMesh[] lods = new ObjMesh[LOD_LEVELS];
    /** {@link #groupSideCenters} の答え。メッシュから決まるので 1 度だけ測る。 */
    protected final Map<String, List<Vec3d>> sideCenters = new HashMap<>();
    /** {@link #isUvMapped} の答え。同上。 */
    protected final Map<String, Boolean> uvMapped = new HashMap<>();

    /**
     * OBJ の {@code o} / {@code g} ひと区切り。<b>同じオブジェクトの中でもマテリアルが変われば区切る。</b>
     *
     * <p>面の意味は 2 つの軸で決まる。</p>
     * <ul>
     *   <li><b>役目</b>（{@link #role()}）… ライト・ガラス・ミラー・タイヤのどれか、またはふつうの面。
     *       <b>マテリアル名が役目の名前ならそれが優先</b>で、そうでなければオブジェクト名の役目を引き継ぐ。
     *       面ごとにマテリアルを割り当てれば、1 つのオブジェクトの一部だけをライトにできる</li>
     *   <li><b>持ち主</b>（{@link #owner()}）… {@link #PART_PREFIX} で始まるオブジェクトの中の面は、
     *       その部品を付けているときだけ出る。役目とは別の軸なので、部品の中のライトも作れる
     *       （ウイングに付いたハイマウントのブレーキランプ）</li>
     * </ul>
     *
     * @param material その面のマテリアル名。usemtl が無ければ null
     */
    protected record Group(String name, @Nullable String material, int from, int to) {

        /** この区切りの面の役目の名前。マテリアル名が役目の名前ならそれ、そうでなければオブジェクト名。 */
        String role() {
            String fromMaterial = roleName(material);
            return fromMaterial != null ? fromMaterial : withoutCopySuffix(name);
        }

        /** 持ち主の部品の形の名前。部品の形（{@link #PART_PREFIX}）の中の面でなければ null。 */
        @Nullable
        String owner() {
            return name.startsWith(PART_PREFIX) ? name : null;
        }
    }

    /** 部品の中の面を名前で引くときの区切り。{@code light_tail@part_rear_wing-gt_wing}。 */
    protected static final String OWNED = "@";

    /**
     * 役目を持つ名前か（ライト・ガラス・ミラー・タイヤ）。
     *
     * <p>{@link #PART_PREFIX} は役目ではない（出し入れの軸）ので入れない。</p>
     */
    protected static boolean isRoleName(String name) {
        return name.startsWith(LIGHT_PREFIX) || name.startsWith(MIRROR_PREFIX)
                || isGlassName(name) || isTireName(name);
    }

    /** マテリアル名が役目の名前なら、その役目（複製の印を外したもの）。そうでなければ null。 */
    @Nullable
    protected static String roleName(@Nullable String material) {
        if (material == null) {
            return null;
        }
        String name = withoutCopySuffix(material);
        return isRoleName(name) ? name : null;
    }

    /**
     * Blender が複製のときに付ける印（{@code .001}）を外す。<b>マテリアルを複製すると付きやすい</b>ので、
     * {@code light_tail.001} もテールランプとして読む。
     */
    static String withoutCopySuffix(String name) {
        int dot = name.lastIndexOf('.');
        if (dot <= 0 || dot == name.length() - 1) {
            return name;
        }
        for (int i = dot + 1; i < name.length(); i++) {
            if (!Character.isDigit(name.charAt(i))) {
                return name;
            }
        }
        return name.substring(0, dot);
    }

    /**
     * 間引くときの箱の大きさ [m]。段階 1 は中距離、2 は遠距離（距離は {@code CarObjRenderer} が決める）。
     *
     * <p>S15 の車体なら 5cm で 7 割・12cm で 4 割、ホイールなら 5cm で 5 割・12cm で 2 割の面が残る。
     * 24 ブロック先の 5cm、64 ブロック先の 12cm は、どちらも 1080p の画面で 2 画素ほど。</p>
     */
    protected static final double[] LOD_CELLS = {0.0, 0.05, 0.12};
    /** {@link #LOD_CELLS} の長さ。コンパイル時の定数なので、クラスの初期化の順番に左右されない。 */
    protected static final int LOD_LEVELS = 3;

    /** メッシュの作り方。版が GPU に積む子（{@code ObjModel}）を作るものに差し替える。 */
    public interface Factory {
        ObjMesh create(float[] vertices, List<Group> groups);
    }

    private static Factory factory = ObjMesh::new;

    public static void setFactory(Factory made) {
        factory = made;
    }

    protected static ObjMesh create(float[] vertices, List<Group> groups) {
        return factory.create(vertices, groups);
    }

    protected ObjMesh(float[] vertices, List<Group> groups) {
        this.vertices = vertices;
        this.faceCount = vertices.length / FACE_FLOATS;
        this.groups = groups;

        // 名前で引く表は<b>役目の名前</b>で作る（マテリアルが役目の名前ならそれ、無ければオブジェクト名）。
        // 部品の中の面は「役目@部品の形」で入れる。部品を付けているときだけ使う
        Map<String, List<Integer>> byName = new java.util.LinkedHashMap<>();
        for (Group group : groups) {
            String key = group.owner() == null ? group.role() : group.role() + OWNED + group.owner();
            List<Integer> list = byName.computeIfAbsent(key, name -> new ArrayList<>());
            for (int face = group.from(); face < group.to(); face++) {
                list.add(face);
            }
            warnConflictingRoles(group);
        }
        this.facesByName = new java.util.LinkedHashMap<>();
        byName.forEach((name, list) -> facesByName.put(name, toArray(list)));

        // 鏡を先に測る。反射面はどちらのパスからも外すので、振り分けより前に要る
        boolean[] excluded = new boolean[faceCount];
        List<MirrorFace> found = new ArrayList<>();
        for (String name : facesByName.keySet()) {
            if (!name.startsWith(MIRROR_PREFIX)) {
                continue;
            }
            if (name.contains(OWNED)) {
                // 部品の中の鏡は映さない（部品と一緒に出し入れする仕組みが無い）。ふつうの面として描く
                LOGGER.warn("部品の形の中の鏡は映りません（ふつうの面として描きます）: {}", name);
                continue;
            }
            MirrorFace face = measureMirror(name);
            if (face == null) {
                // 反射面が見つからなくても描画は続く（ぜんぶ車体として描かれる）。
                // 黙って映らないと原因を探すことになるので、理由をログに残す
                LOGGER.warn("{} から鏡にできる平面が見つからない（面が無いか、大きさが 0）", name);
                continue;
            }
            found.add(face);
            // 鏡の<b>反射面だけ</b>を外す。筐体（ガワ）は車体として描かれる
            for (int index : face.faces()) {
                excluded[index] = true;
            }
        }
        this.mirrors = List.copyOf(found);

        // 灯火は車体とは別に描く。呼ぶ側（CarLights）が名指しで必ず描くので穴は開かない
        for (Group group : groups) {
            if (group.role().startsWith(LIGHT_PREFIX)) {
                for (int face = group.from(); face < group.to(); face++) {
                    excluded[face] = true;
                }
            }
        }

        // ナンバーの字の枠は描かない（枠の上に字を描くので、板が見えると字の下に色の付いた四角が出る）
        for (Group group : groups) {
            if (group.role().startsWith(TEXT_PREFIX)) {
                for (int face = group.from(); face < group.to(); face++) {
                    excluded[face] = true;
                }
            }
        }

        // ハンドルも本体から外す（renderSteeringWheel が回して描く）。本体は GPU に置いたまま
        // 動かさないので、回るものは別に持つしかない。軸が取れなくても外す——間引いた版（lod）だけ
        // 軸が取れずに本体へ残ると、回るハンドルと止まったハンドルが二重に描かれる
        List<Integer> steeringOpaque = new ArrayList<>();
        List<Integer> steeringClear = new ArrayList<>();
        for (Group group : groups) {
            if (group.owner() != null || !isSteeringName(group.role())) {
                continue;
            }
            for (int face = group.from(); face < group.to(); face++) {
                if (excluded[face]) {
                    continue;
                }
                excluded[face] = true;
                boolean transparent = vertices[face * FACE_FLOATS + ALPHA_OFFSET] < OPAQUE_THRESHOLD;
                (transparent ? steeringClear : steeringOpaque).add(face);
            }
        }
        this.steeringFaces = new int[][]{toArray(steeringOpaque), toArray(steeringClear)};

        // 部品の形も本体から外し、名前ごとに持つ（renderOptional が描く）。
        // 本体を車ごとに違う形にしないため（GPU に置いたメッシュを使い回せなくなる）
        Map<String, List<Integer>[]> optional = new HashMap<>();
        for (Group group : groups) {
            if (group.owner() == null) {
                continue;
            }
            // ライトだけの部品でも名前は持つ（換装画面に並べるため）。ライトの面は上で外してあるので入らない
            @SuppressWarnings("unchecked")
            List<Integer>[] lists = optional.computeIfAbsent(group.owner(),
                    name -> new List[]{new ArrayList<Integer>(), new ArrayList<Integer>()});
            for (int face = group.from(); face < group.to(); face++) {
                if (excluded[face]) {
                    continue;
                }
                excluded[face] = true;
                boolean transparent = vertices[face * FACE_FLOATS + ALPHA_OFFSET] < OPAQUE_THRESHOLD;
                lists[transparent ? 1 : 0].add(face);
            }
        }
        this.optionalFaces = new HashMap<>();
        optional.forEach((name, lists) -> optionalFaces.put(name, new int[][]{toArray(lists[0]), toArray(lists[1])}));

        // 残りは<b>頂点の不透明度</b>で振り分ける。透ける面は車体のパスから外れ、半透明のパスが拾う
        List<Integer> opaque = new ArrayList<>();
        List<Integer> translucent = new ArrayList<>();
        for (int face = 0; face < faceCount; face++) {
            if (excluded[face]) {
                continue;
            }
            boolean transparent = vertices[face * FACE_FLOATS + ALPHA_OFFSET] < OPAQUE_THRESHOLD;
            (transparent ? translucent : opaque).add(face);
        }
        this.opaqueFaces = toArray(opaque);
        this.translucentFaces = toArray(translucent);

        // タイヤ（名前が tire で始まるオブジェクト）を見分ける。ホイールのメッシュにタイヤが
        // 付属しているとき、タイヤ部品を履いたらこれを隠して選んだタイヤを描く
        boolean[] tire = new boolean[faceCount];
        boolean anyTire = false;
        for (Group group : groups) {
            if (isTireName(group.role())) {
                for (int face = group.from(); face < group.to(); face++) {
                    tire[face] = true;
                    anyTire = true;
                }
            }
        }
        this.hasTire = anyTire;
        this.opaqueRimFaces = without(opaqueFaces, tire);
        this.translucentRimFaces = without(translucentFaces, tire);
        this.opaqueTireFaces = java.util.Arrays.stream(opaqueFaces).filter(face -> tire[face]).toArray();
        boolean[] suspension = new boolean[faceCount];
        for (Group group : groups) {
            if (group.role().toLowerCase(java.util.Locale.ROOT).startsWith(SUSPENSION_PREFIX)) {
                for (int face = group.from(); face < group.to(); face++) {
                    suspension[face] = true;
                }
            }
        }
        this.opaqueShadowFaces = without(opaqueFaces, suspension);
        double[] tireRange = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
        double[] allRange = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY};
        double rimOuter = 0.0;
        for (int face = 0; face < faceCount; face++) {
            for (int corner = 0; corner < 4; corner++) {
                int offset = face * FACE_FLOATS + corner * STRIDE;
                double r = Math.hypot(vertices[offset + 1], vertices[offset + 2]);
                allRange[0] = Math.min(allRange[0], r);
                allRange[1] = Math.max(allRange[1], r);
                if (tire[face]) {
                    tireRange[0] = Math.min(tireRange[0], r);
                    tireRange[1] = Math.max(tireRange[1], r);
                } else {
                    rimOuter = Math.max(rimOuter, r);
                }
            }
        }
        this.tireRadialRange = anyTire ? tireRange : null;
        this.rimOuterRadius = rimOuter;
        this.radialRange = faceCount > 0 ? allRange : new double[]{0.0, 0.0};
    }

    /**
     * オブジェクト名とマテリアル名で違う役目が付いた区切り。意図しない指定のことが多いのでログに残す
     * （マテリアルが優先される）。
     */
    protected static void warnConflictingRoles(Group group) {
        String fromName = withoutCopySuffix(group.name());
        String fromMaterial = roleName(group.material());
        if (fromMaterial != null && isRoleName(fromName) && !fromMaterial.equals(fromName)) {
            LOGGER.info("オブジェクト {} の役目（{}）より、マテリアル {} の役目（{}）を優先します",
                    group.name(), fromName, group.material(), fromMaterial);
        }
    }

    /**
     * その役目の面を持つ名前（{@link #hasGroup} などに渡すもの）。<b>いつも出ている面に、見せている部品の中の
     * 面を足す。</b>ウイングに付いたブレーキランプは、ウイングを付けているときだけ光る。
     *
     * @param shown 見せている部品の形の名前（{@code CarModel#bodyParts}）
     */
    public List<String> roleNames(String role, java.util.Set<String> shown) {
        List<String> names = new ArrayList<>(1);
        if (facesByName.containsKey(role)) {
            names.add(role);
        }
        for (String owner : shown) {
            String key = role + OWNED + owner;
            if (facesByName.containsKey(key)) {
                names.add(key);
            }
        }
        return names;
    }

    /** このモデルが持っている、部品の形の名前（{@link #PART_PREFIX}）。 */
    @Override
    public java.util.Set<String> optionalNames() {
        return optionalFaces.keySet();
    }

    /** 出し入れする形に、そのパスの面が 1 つでもあるか。半透明のパスを呼ぶかの判断に使う。 */
    public boolean hasOptional(Pass pass) {
        int index = pass == Pass.TRANSLUCENT ? 1 : 0;
        return optionalFaces.values().stream().anyMatch(faces -> faces[index].length > 0);
    }

    /** ハンドルのオブジェクト名か。Blender で付けがちな大文字（{@code Steering}）も拾う。 */
    protected static boolean isSteeringName(String name) {
        return name.toLowerCase(java.util.Locale.ROOT).startsWith(STEERING_PREFIX);
    }

    /** ハンドルの面から回す中心と軸を読む。平たいと言えなければ理由をログに残して null。 */
    @Nullable
    protected SteeringWheelAxis.Result measureSteering() {
        SteeringWheelAxis.Result result = SteeringWheelAxis.measure(steeringPositions());
        if (result == null) {
            // 黙って回らないと原因を探すことになる。止めたまま描くので穴は開かない
            LOGGER.warn("ハンドル（{}*）が平たい板の形をしていないので回しません。"
                    + "コラムカバーなど回らない部分は別のオブジェクトにするか、"
                    + "vehicles の JSON の steering.column にコラムの角度を書いてください", STEERING_PREFIX);
        }
        return result;
    }

    /** ハンドルの面の頂点の座標 {x, y, z, ...}。 */
    protected float[] steeringPositions() {
        int count = steeringFaces[0].length + steeringFaces[1].length;
        float[] positions = new float[count * 4 * 3];
        int n = 0;
        for (int[] faces : steeringFaces) {
            for (int face : faces) {
                for (int corner = 0; corner < 4; corner++) {
                    int offset = face * FACE_FLOATS + corner * STRIDE;
                    positions[n++] = vertices[offset];
                    positions[n++] = vertices[offset + 1];
                    positions[n++] = vertices[offset + 2];
                }
            }
        }
        return positions;
    }

    /** ハンドルのそのパスの面が 1 つでもあるか。 */
    public boolean hasSteeringWheel(Pass pass) {
        return steeringFaces[pass == Pass.TRANSLUCENT ? 1 : 0].length > 0;
    }

    /**
     * ハンドルを回す中心と軸（メッシュの座標）。ハンドルが無ければ null。
     *
     * @param column コラムの角度 [度]（{@link CarModel#steeringColumn}）。NaN なら形から読み、
     *               平たいと言えなければ null
     */
    @Nullable
    public SteeringWheelAxis.Result steeringAxis(double column) {
        if (steeringFaces[0].length + steeringFaces[1].length == 0) {
            return null;
        }
        if (!Double.isNaN(column)) {
            return steeringByColumn.computeIfAbsent(column, c -> SteeringWheelAxis.around(steeringPositions(), c));
        }
        if (!steeringMeasured) {
            steeringAxis = measureSteering();
            steeringMeasured = true;
        }
        return steeringAxis;
    }

    /**
     * ハンドルを回す中心と軸に、中心のずらし（{@code steering.center}）を掛けたもの。描く・手を置くのはこちら。
     *
     * @param up 中心を面に沿って上へずらす量 [m]（モデルの座標）
     */
    @Nullable
    public SteeringWheelAxis.Result steeringAxis(double column, double up) {
        SteeringWheelAxis.Result axis = steeringAxis(column);
        return axis == null ? null : axis.raised(up);
    }

    /**
     * ハンドルのコラムの角度 [度]。水平から、運転者へ向かって上がる向きが正（傾ける前）。
     * {@code steering.column} と同じ向き。軸が取れていなければ NaN。
     */
    @Override
    public double steeringColumnAngle(double column) {
        SteeringWheelAxis.Result axis = steeringAxis(column);
        return axis == null ? Double.NaN : Math.toDegrees(Math.asin(axis.axis()[1]));
    }

    /** タイヤのオブジェクト名か。Blender の既定の大文字（{@code Tire}）も拾う。 */
    protected static boolean isTireName(String name) {
        return name.toLowerCase(java.util.Locale.ROOT).startsWith(TIRE_PREFIX);
    }

    protected static int[] without(int[] faces, boolean[] excluded) {
        return java.util.Arrays.stream(faces).filter(face -> !excluded[face]).toArray();
    }

    /** タイヤのオブジェクトが付属しているか。 */
    public boolean hasTire() {
        return hasTire;
    }

    /** 付属のタイヤの半径の範囲 {内径, 外径}。付属していなければ null。 */
    @org.jetbrains.annotations.Nullable
    public double[] tireRadialRange() {
        return tireRadialRange == null ? null : tireRadialRange.clone();
    }

    /** タイヤ以外（リム）のいちばん外の半径。 */
    public double rimOuterRadius() {
        return rimOuterRadius;
    }

    /** 全部の面の半径の範囲 {内径, 外径}。 */
    public double[] radialRange() {
        return radialRange.clone();
    }

    /**
     * メッシュ全体を囲む箱 {minX, minY, minZ, maxX, maxY, maxZ}（メッシュの座標のまま）。
     * 面が無ければすべて 0。アイテムのアイコンで車を枠へ収めるのに使う。
     */
    @Override
    public double[] bounds() {
        if (bounds == null) {
            double[] box = {Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY,
                    Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY};
            for (int offset = 0; offset < faceCount * FACE_FLOATS; offset += STRIDE) {
                for (int axis = 0; axis < 3; axis++) {
                    box[axis] = Math.min(box[axis], vertices[offset + axis]);
                    box[axis + 3] = Math.max(box[axis + 3], vertices[offset + axis]);
                }
            }
            bounds = faceCount > 0 ? box : new double[6];
        }
        return bounds.clone();
    }

    /** {@link #bounds} の答え。メッシュから決まるので 1 度だけ測る。 */
    protected double[] bounds;

    /**
     * ナンバーの字の枠 1 つ。<b>プレートの表に重ねた長方形</b>（エンティティ空間。表は -Z）。
     *
     * <p>左右（X）と上下（Y）の範囲だけを持つ。枠は表の面に沿って置くものなので、傾いた枠は
     * 囲む箱として読む（字は表の向きのまま描く）。</p>
     *
     * @param minX 左右の範囲（エンティティ空間の X。<b>正面から見て右が -X</b>）
     * @param z    枠の面の位置（いちばん前、いちばん小さい Z）
     */
    public record TextFrame(double minX, double minY, double maxX, double maxY, double z) {
        public double width() {
            return maxX - minX;
        }

        public double height() {
            return maxY - minY;
        }
    }

    /** 欄の名前 → 字の枠。{@code text_} の板が無ければ空。 */
    public Map<String, TextFrame> textFrames() {
        if (textFrames == null) {
            Map<String, TextFrame> frames = new java.util.LinkedHashMap<>();
            for (String name : facesByName.keySet()) {
                if (!name.startsWith(TEXT_PREFIX) || name.contains(OWNED)) {
                    continue;
                }
                double[] box = {Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY,
                        Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY};
                forEachVertex(name, offset -> {
                    box[0] = Math.min(box[0], vertices[offset]);
                    box[1] = Math.min(box[1], vertices[offset + 1]);
                    box[2] = Math.min(box[2], vertices[offset + 2]);
                    box[3] = Math.max(box[3], vertices[offset]);
                    box[4] = Math.max(box[4], vertices[offset + 1]);
                });
                if (box[3] - box[0] <= 1.0e-5 || box[4] - box[1] <= 1.0e-5) {
                    LOGGER.warn("ナンバーの字の枠 {} に大きさがありません（この欄には字を描きません）", name);
                    continue;
                }
                frames.put(name.substring(TEXT_PREFIX.length()), new TextFrame(box[0], box[1], box[3], box[4], box[2]));
            }
            textFrames = java.util.Collections.unmodifiableMap(frames);
        }
        return textFrames;
    }

    @Nullable
    protected Map<String, TextFrame> textFrames;

    /**
     * 前後方向（Z）へ飛ばした光線が、メッシュの表面に最初に当たる点。<b>ナンバーを自動で置く</b>のに使う。
     *
     * @param front true なら前（-Z）の外から後ろへ、false なら後ろ（+Z）の外から前へ飛ばす
     * @return {z, 法線 x, 法線 y, 法線 z}（法線は外向き）。当たらなければ null
     */
    @Nullable
    @Override
    public double[] surfaceAlongZ(double x, double y, boolean front) {
        double bestZ = front ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY;
        double[] best = null;
        for (int face = 0; face < faceCount; face++) {
            int base = face * FACE_FLOATS;
            // 四角形は 0-1-2 と 0-2-3 の三角形 2 つ（縮退四角形なら 2 つ目は大きさ 0 で当たらない）
            for (int half = 0; half < 2; half++) {
                int a = base;
                int b = base + (half == 0 ? 1 : 2) * STRIDE;
                int c = base + (half == 0 ? 2 : 3) * STRIDE;
                double[] hit = hitAlongZ(x, y, a, b, c);
                if (hit == null) {
                    continue;
                }
                if (front ? hit[0] < bestZ : hit[0] > bestZ) {
                    bestZ = hit[0];
                    best = hit;
                }
            }
        }
        if (best == null) {
            return null;
        }
        // 外向きにそろえる（面の巻き方向はモデルしだいなので、飛ばした側を向くほうを取る）
        double sign = (front ? best[3] > 0.0 : best[3] < 0.0) ? -1.0 : 1.0;
        return new double[]{best[0], best[1] * sign, best[2] * sign, best[3] * sign};
    }

    /** 三角形 a-b-c と、点 (x, y) を通る Z 方向の直線の交点。{z, 法線}。当たらなければ null。 */
    @Nullable
    protected double[] hitAlongZ(double x, double y, int a, int b, int c) {
        double ax = vertices[a], ay = vertices[a + 1], az = vertices[a + 2];
        double bx = vertices[b], by = vertices[b + 1], bz = vertices[b + 2];
        double cx = vertices[c], cy = vertices[c + 1], cz = vertices[c + 2];
        // XY 面に写した三角形の中に (x, y) があるか（重心座標）
        double det = (by - cy) * (ax - cx) + (cx - bx) * (ay - cy);
        if (Math.abs(det) < 1.0e-12) {
            return null;
        }
        double u = ((by - cy) * (x - cx) + (cx - bx) * (y - cy)) / det;
        double v = ((cy - ay) * (x - cx) + (ax - cx) * (y - cy)) / det;
        double w = 1.0 - u - v;
        if (u < 0.0 || v < 0.0 || w < 0.0) {
            return null;
        }
        double z = u * az + v * bz + w * cz;
        // 法線（辺の外積）
        double ux = bx - ax, uy = by - ay, uz = bz - az;
        double vx = cx - ax, vy = cy - ay, vz = cz - az;
        double nx = uy * vz - uz * vy;
        double ny = uz * vx - ux * vz;
        double nz = ux * vy - uy * vx;
        double length = Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (length < 1.0e-12) {
            return null;
        }
        return new double[]{z, nx / length, ny / length, nz / length};
    }

    /** タイヤ以外に透ける面があるか。 */
    public boolean hasTranslucentRim() {
        return translucentRimFaces.length > 0;
    }

    /**
     * タイヤのメッシュを、半径 {@code fromInner}〜{@code fromOuter} の帯が {@code toInner}〜{@code toOuter} へ
     * 収まるよう<b>半径方向に伸び縮みさせた</b>複製。車軸方向（X）は {@code xScale} 倍。
     *
     * <p>一様な拡大では内径と外径の比が変わらないので、リムの大きさが違うホイールにタイヤを合わせられない。
     * 半径を内径から外径へ線形に移せば、<b>リムが大きければサイドウォールが薄く、小さければ厚く</b>なる
     * （実車のインチアップと同じ）。</p>
     *
     * <p>法線は変形の逆転置で直す（半径方向・円周方向・車軸方向で伸び方が違うため）。</p>
     */
    public ObjMesh fitRadially(double fromInner, double fromOuter, double toInner, double toOuter, double xScale) {
        float[] out = vertices.clone();
        double band = Math.max(1e-6, fromOuter - fromInner);
        double radialScale = (toOuter - toInner) / band;
        for (int offset = 0; offset < out.length; offset += STRIDE) {
            double y = out[offset + 1];
            double z = out[offset + 2];
            double r = Math.hypot(y, z);
            double target = toInner + (r - fromInner) * radialScale;
            double tangential = r > 1e-6 ? target / r : 1.0;
            out[offset] = (float) (out[offset] * xScale);
            out[offset + 1] = (float) (y * tangential);
            out[offset + 2] = (float) (z * tangential);

            // 法線を（車軸, 半径, 円周）に分けて、それぞれの伸びの逆数を掛ける
            double nx = out[offset + 3];
            double ny = out[offset + 4];
            double nz = out[offset + 5];
            double cy = r > 1e-6 ? y / r : 0.0;
            double cz = r > 1e-6 ? z / r : 1.0;
            double nRadial = ny * cy + nz * cz;
            double nTangential = -ny * cz + nz * cy;
            double ax = nx / xScale;
            double ar = nRadial / Math.max(1e-6, radialScale);
            double at = nTangential / Math.max(1e-6, tangential);
            double ry = ar * cy - at * cz;
            double rz = ar * cz + at * cy;
            double length = Math.sqrt(ax * ax + ry * ry + rz * rz);
            if (length > 1e-9) {
                out[offset + 3] = (float) (ax / length);
                out[offset + 4] = (float) (ry / length);
                out[offset + 5] = (float) (rz / length);
            }
        }
        return create(out, groups);
    }

    /** 合わせ直したタイヤ。リソースの再読み込みで捨てる。 */
    protected static final Map<FitKey, ObjMesh> FITTED = new HashMap<>();

    protected record FitKey(CarId location, double fromInner, double fromOuter,
                          double toInner, double toOuter, double xScale) {
    }

    /**
     * タイヤのメッシュを読み、{@link #fitRadially} で合わせ直したもの。同じ寸法なら使い回す。
     *
     * <p>車軸方向は外径の比で一様に拡大する。タイヤを作った大きさに依らず、
     * 外径に対する太さの比が保たれる。</p>
     *
     * @param fromInner メッシュのタイヤの内径。null なら測った値
     * @param fromOuter メッシュのタイヤの外径。null なら測った値
     */
    public static ObjMesh fittedTire(CarId location,
                                      @org.jetbrains.annotations.Nullable Double fromInner,
                                      @org.jetbrains.annotations.Nullable Double fromOuter,
                                      double toInner, double toOuter) {
        ObjMesh source = get(location);
        double inner = fromInner != null ? fromInner : source.radialRange[0];
        double outer = fromOuter != null ? fromOuter : source.radialRange[1];
        double xScale = outer > 1e-6 ? toOuter / outer : 1.0;
        FitKey key = new FitKey(location, inner, outer, toInner, toOuter, xScale);
        return FITTED.computeIfAbsent(key, k -> source.fitRadially(inner, outer, toInner, toOuter, xScale));
    }

    protected static int[] toArray(List<Integer> list) {
        return list.stream().mapToInt(Integer::intValue).toArray();
    }

    /**
     * 鏡面 1 枚の幾何。<b>メッシュだけから決まる</b>ので、Blender で板を 1 枚置いて
     * {@code mirror_rear} と名前を付ければそれで済む。
     *
     * @param center 面の中心（メッシュ空間）
     * @param normal 面の向き。運転者のほうを向いている想定
     * @param right  面の中で右へ伸びる軸（車体の右向きに揃えてある）
     * @param up     面の中で上へ伸びる軸
     * @param width  {@code right} 方向の幅 [m]
     * @param height {@code up} 方向の高さ [m]
     * @param faces 反射面をなす面の番号。<b>ガワは含まない</b>
     */
    public record MirrorFace(String name, Vec3d center, Vec3d normal, Vec3d right, Vec3d up,
                             double width, double height, int[] faces) {

        /** 横縦比。描き先の大きさと射影のアスペクトに使う。 */
        public double aspect() {
            return height < 1.0e-6 ? 1.0 : width / height;
        }
    }

    /** 鏡面の一覧。持っていなければ空。 */
    public List<MirrorFace> meshMirrors() {
        return mirrors;
    }

    /**
     * 鏡面を測る。
     *
     * <p><b>オブジェクト全体の平均法線を使ってはいけない。</b>ミラーは<b>筐体ごと 1 つの箱</b>で
     * 作られるのが自然で、そうすると向かい合う面の法線が打ち消し合う（実測で
     * {@code mirror_rear} は合計がちょうど 0、ドアミラーも長さ 0.28 まで潰れた）。</p>
     *
     * <p>そこで<b>面ごとに見て、いちばん広い平面</b>を反射面とする。残りの面は<b>車体として
     * 普通に描かれる</b>ので、筐体が消えることはない。</p>
     *
     * <p><b>板がどちらを向いていても構わない。</b>映す向きは {@link MirrorRenderer} が車体基準で
     * 決めるので、ここで要るのは「どの平面に貼るか」だけ。法線は<b>後ろ向きに揃えておく</b>
     * ——面内の軸（右と上）をその法線から作るので、裏返っていると映像が左右逆になる。</p>
     *
     * <p>面内の軸は<b>車体の上向きから作る</b>——鏡は水平に置かれるものなので、上を基準にすれば
     * 「映像の上」が鏡の上に一致する。</p>
     */
    protected MirrorFace measureMirror(String name) {
        int[] group = facesByName.getOrDefault(name, NO_FACES);

        int[] best = null;
        Vec3d bestNormal = null;
        double bestArea = 0.0;
        for (int candidate : group) {
            Vec3d raw = faceNormal(candidate);
            double area = raw.length();
            if (area < 1.0e-9) {
                continue;
            }
            // 面の向きは問わない。ただし軸を作るために後ろ（+Z）向きへ揃える
            Vec3d normal = raw.scale(1.0 / area);
            if (normal.z < 0.0) {
                normal = normal.scale(-1.0);
            }
            double offset = normal.dot(faceCenter(candidate));

            List<Integer> plane = new ArrayList<>();
            double total = 0.0;
            for (int other : group) {
                Vec3d otherRaw = faceNormal(other);
                double otherArea = otherRaw.length();
                if (otherArea < 1.0e-9
                        || Math.abs(otherRaw.scale(1.0 / otherArea).dot(normal)) < COPLANAR_COS
                        || Math.abs(normal.dot(faceCenter(other)) - offset) > COPLANAR_GAP) {
                    continue;
                }
                plane.add(other);
                total += otherArea;
            }
            if (total > bestArea) {
                bestArea = total;
                bestNormal = normal;
                best = toArray(plane);
            }
        }
        if (best == null) {
            return null;
        }

        Vec3d up = Math.abs(bestNormal.y) > 0.99 ? new Vec3d(0.0, 0.0, -1.0) : new Vec3d(0.0, 1.0, 0.0);
        Vec3d right = up.cross(bestNormal);
        if (right.lengthSqr() < 1.0e-9) {
            return null;
        }
        right = right.normalize();
        up = bestNormal.cross(right).normalize();

        // 反射面の頂点だけで広がりを測る（筐体を混ぜると鏡が大きすぎることになる）
        double minRight = Double.MAX_VALUE;
        double maxRight = -Double.MAX_VALUE;
        double minUp = Double.MAX_VALUE;
        double maxUp = -Double.MAX_VALUE;
        for (int face : best) {
            int base = face * FACE_FLOATS;
            for (int corner = 0; corner < 4; corner++) {
                int offset = base + corner * STRIDE;
                Vec3d v = new Vec3d(vertices[offset], vertices[offset + 1], vertices[offset + 2]);
                minRight = Math.min(minRight, v.dot(right));
                maxRight = Math.max(maxRight, v.dot(right));
                minUp = Math.min(minUp, v.dot(up));
                maxUp = Math.max(maxUp, v.dot(up));
            }
        }
        double width = maxRight - minRight;
        double height = maxUp - minUp;
        if (width < 1.0e-4 || height < 1.0e-4) {
            return null;
        }

        // 中心は広がりの中央。面に載せるため、法線方向だけは実際の平面の位置に合わせる
        double onPlane = bestNormal.dot(faceCenter(best[0]));
        Vec3d center = right.scale((minRight + maxRight) * 0.5)
                .add(up.scale((minUp + maxUp) * 0.5))
                .add(bestNormal.scale(onPlane));
        return new MirrorFace(name, center, bestNormal, right, up, width, height, best);
    }

    /**
     * その面の法線。<b>長さが面積の 2 倍</b>になるので、広さの比較にそのまま使える。
     *
     * <p>2 本の対角線の外積を使う。四角形ならこれがそのまま面積の 2 倍で、
     * 縮退四角形（a, b, c, c）でも {@code (c−a)×(c−b) = (b−a)×(c−a)} と三角形の式に一致する。</p>
     */
    protected Vec3d faceNormal(int face) {
        Vec3d a = corner(face, 0);
        Vec3d b = corner(face, 1);
        Vec3d c = corner(face, 2);
        Vec3d d = corner(face, 3);
        return c.subtract(a).cross(d.subtract(b));
    }

    /**
     * その面の中心（4 頂点の平均）。
     *
     * <p>三角形は 3 番目の頂点が 2 回数えられて重心からずれるが、使い道は「面が載っている
     * 平面の位置」だけなので、平面上の点でさえあればよい。</p>
     */
    protected Vec3d faceCenter(int face) {
        int base = face * FACE_FLOATS;
        double x = 0.0;
        double y = 0.0;
        double z = 0.0;
        for (int corner = 0; corner < 4; corner++) {
            int offset = base + corner * STRIDE;
            x += vertices[offset];
            y += vertices[offset + 1];
            z += vertices[offset + 2];
        }
        return new Vec3d(x / 4.0, y / 4.0, z / 4.0);
    }

    protected Vec3d corner(int face, int corner) {
        int offset = face * FACE_FLOATS + corner * STRIDE;
        return new Vec3d(vertices[offset], vertices[offset + 1], vertices[offset + 2]);
    }

    /** 透ける面を持っているか。false なら半透明のパスは呼ばなくてよい。 */
    public boolean hasTranslucent() {
        return translucentFaces.length > 0;
    }

    /** その名前のオブジェクトを持っているか。 */
    public boolean hasGroup(String name) {
        return facesByName.containsKey(name);
    }

    /**
     * そのオブジェクトの頂点を中心線の左右に振り分けた重心。ライトの位置に使う。
     *
     * <p>左右に分かれていれば 2 つ、中央に 1 つだけなら 1 つ返る。ミラーで作られた
     * 1 オブジェクトからそのまま左右のライトが取れる。</p>
     *
     * <p>毎フレーム呼ばれるが、答えはメッシュだけから決まるので最初の 1 回だけ測る。</p>
     */
    public List<Vec3d> sideCentersOf(String name) {
        return sideCenters.computeIfAbsent(name, this::measureSideCenters);
    }

    protected List<Vec3d> measureSideCenters(String name) {
        double[] sum = new double[6];
        int[] count = new int[2];
        forEachVertex(name, offset -> {
            float x = vertices[offset];
            int side = x < 0.0 ? 0 : 1;
            sum[side * 3] += x;
            sum[side * 3 + 1] += vertices[offset + 1];
            sum[side * 3 + 2] += vertices[offset + 2];
            count[side]++;
        });
        List<Vec3d> centers = new ArrayList<>(2);
        for (int side = 0; side < 2; side++) {
            if (count[side] > 0) {
                centers.add(new Vec3d(sum[side * 3] / count[side],
                        sum[side * 3 + 1] / count[side], sum[side * 3 + 2] / count[side]));
            }
        }
        return List.copyOf(centers);
    }

    /** {@link #upperEdgesOf} cache. */
    protected final Map<String, List<List<Vec3d>>> upperEdges = new HashMap<>();

    /**
     * Garis tepi ATAS tiap lampu (kiri/kanan terpisah), diambil dari bentuk lampu aslinya: tiap kolom lebar
     * dipilih titik tertinggi, lalu dihaluskan. Dipakai lampu alis supaya mengikuti kontur lampu depan.
     * Tiap garis berurutan dari sisi dalam (dekat tengah mobil) ke sisi luar.
     */
    public List<List<Vec3d>> upperEdgesOf(String name) {
        return upperEdges.computeIfAbsent(name, this::measureUpperEdges);
    }

    protected List<List<Vec3d>> measureUpperEdges(String name) {
        final int bins = 10;
        List<List<Vec3d>> result = new ArrayList<>(2);
        for (int side = 0; side < 2; side++) {
            final int sd = side;
            double[] mn = {Double.MAX_VALUE};
            double[] mx = {-Double.MAX_VALUE};
            forEachVertex(name, offset -> {
                if ((vertices[offset] < 0.0 ? 0 : 1) == sd) {
                    mn[0] = Math.min(mn[0], Math.abs(vertices[offset]));
                    mx[0] = Math.max(mx[0], Math.abs(vertices[offset]));
                }
            });
            if (mx[0] - mn[0] < 0.02) {
                continue;
            }
            double[][] best = new double[bins][];
            double w = (mx[0] - mn[0]) / bins;
            forEachVertex(name, offset -> {
                if ((vertices[offset] < 0.0 ? 0 : 1) != sd) {
                    return;
                }
                int b = (int) Math.min(bins - 1, (Math.abs(vertices[offset]) - mn[0]) / w);
                if (best[b] == null || vertices[offset + 1] > best[b][1]) {
                    best[b] = new double[] {vertices[offset], vertices[offset + 1], vertices[offset + 2]};
                }
            });
            List<Vec3d> pts = new ArrayList<>(bins);
            for (int i = 0; i < bins; i++) {
                if (best[i] == null) {
                    continue;
                }
                double y = best[i][1];
                double x = best[i][0];
                double z = best[i][2];
                int n = 1;
                for (int d = -1; d <= 1; d += 2) {
                    int j = i + d;
                    if (j >= 0 && j < bins && best[j] != null) {
                        y += best[j][1];
                        z += best[j][2];
                        n++;
                    }
                }
                pts.add(new Vec3d(x, y / n, z / n));
            }
            // dalam -> luar
            pts.sort((a, b) -> Double.compare(Math.abs(a.x), Math.abs(b.x)));
            if (pts.size() >= 2) {
                result.add(List.copyOf(pts));
            }
        }
        return List.copyOf(result);
    }

    /** そのオブジェクトの平均法線。ライトの照射方向に使う。面が無ければ前方（-Z）。 */
    public Vec3d normalOf(String name) {
        double[] sum = new double[3];
        forEachVertex(name, offset -> {
            sum[0] += vertices[offset + 3];
            sum[1] += vertices[offset + 4];
            sum[2] += vertices[offset + 5];
        });
        Vec3d normal = new Vec3d(sum[0], sum[1], sum[2]);
        return normal.lengthSqr() < 1.0e-6 ? new Vec3d(0.0, 0.0, -1.0) : normal.normalize();
    }

    /**
     * そのオブジェクトが UV 展開されているか。
     *
     * <p><b>灯火の色をどちらが決めるかの判定に使う。</b>レンズの UV が 1 点に潰れていれば、
     * テクスチャの 1 画素を全面に写しているだけ——つまりテクスチャは色を持っていないので、
     * 色は{@link CarLights}が掛ける。展開してあるならテクスチャに描かれた色が正で、
     * コード側は明暗（点灯・消灯）だけを扱う。</p>
     *
     * <p>広がりが完全に 0 かで判定すると、丸め誤差ぶんだけばらけた UV を「展開されている」と
     * 読み違える。{@value #UV_MAPPED_EPSILON} は 512px のテクスチャで約 1 画素にあたる。</p>
     */
    public boolean isUvMapped(String name) {
        // 灯火を描くたびに呼ばれる。メッシュだけから決まるので最初の 1 回だけ測る
        return uvMapped.computeIfAbsent(name, this::measureUvMapped);
    }

    protected boolean measureUvMapped(String name) {
        float[] range = {Float.MAX_VALUE, -Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE};
        forEachVertex(name, offset -> {
            range[0] = Math.min(range[0], vertices[offset + 6]);
            range[1] = Math.max(range[1], vertices[offset + 6]);
            range[2] = Math.min(range[2], vertices[offset + 7]);
            range[3] = Math.max(range[3], vertices[offset + 7]);
        });
        return range[1] - range[0] > UV_MAPPED_EPSILON || range[3] - range[2] > UV_MAPPED_EPSILON;
    }

    protected interface VertexSink {
        /** @param offset その頂点の先頭の添字（{@link #vertices} の中） */
        void accept(int offset);
    }

    /** その名前のオブジェクトの頂点を 1 つずつ渡す。三角形の 3 番目の頂点は 2 回来る。 */
    protected void forEachVertex(String name, VertexSink sink) {
        for (int face : facesByName.getOrDefault(name, NO_FACES)) {
            for (int corner = 0; corner < 4; corner++) {
                sink.accept(face * FACE_FLOATS + corner * STRIDE);
            }
        }
    }

    /**
     * モデルを取り出す。まだ読んでいなければ読む。
     *
     * <p>読み込みに失敗しても例外は投げず、空のモデルを返してログに残す。
     * モデルが 1 つ壊れているだけでゲームが落ちるより、車が消えて見える方がましなため。</p>
     */
    public static ObjMesh get(CarId location) {
        return CACHE.computeIfAbsent(location, ObjMesh::load);
    }

    /** 読み込んだメッシュ（間引いた版と、タイヤに合わせた版も）を 1 つずつ渡す。GPU を返すのに使う。 */
    public static void forEachLoaded(java.util.function.Consumer<ObjMesh> action) {
        java.util.List<ObjMesh> all = new java.util.ArrayList<>(CACHE.values());
        all.addAll(FITTED.values());
        for (ObjMesh mesh : all) {
            action.accept(mesh);
            for (ObjMesh lod : mesh.lods) {
                if (lod != null) {
                    action.accept(lod);
                }
            }
        }
    }

    /** リソースの再読み込みで呼ぶ。次に描くときに読み直される（F3+T で Blender の書き出しを反映できる）。 */
    public static void clearCache() {
        // GPU に置いた頂点は GC では消えないので、版の ObjModel が先に返す（forEachLoaded）
        FITTED.clear();
        CACHE.clear();
    }

    /**
     * 頂点を間引いた版。<b>遠くの車を軽く描くため</b>（シェーダーパック使用中は特に効く）。
     *
     * <p>空間を {@link #LOD_CELLS} の大きさの箱に区切り、同じ箱に入った頂点をその平均の位置へ寄せる
     * （頂点クラスタリング）。それで 3 点より少なくつぶれた面（点や線になった面）は捨てる。
     * 細部（ホイールのスポーク、車体の小さな凹凸）から消えていく。</p>
     *
     * <p>結果は普通の {@code ObjMesh} なので、面の振り分け（不透明・ガラス・灯火・タイヤ）も
     * 読み込みと同じ道で決まる。UV と法線は元の頂点のまま。</p>
     *
     * @param level 0 なら自分自身。1 以上は間引いた版（大きいほど粗い）
     */
    public ObjMesh lod(int level) {
        if (level <= 0 || faceCount == 0) {
            return this;
        }
        int index = Math.min(level, LOD_CELLS.length - 1);
        ObjMesh lod = lods[index];
        if (lod == null) {
            lod = simplify(LOD_CELLS[index]);
            lods[index] = lod;
        }
        return lod;
    }

    protected ObjMesh simplify(double cell) {
        // 箱ごとの平均の位置
        Map<Long, double[]> sums = new HashMap<>();
        for (int face = 0; face < faceCount; face++) {
            for (int corner = 0; corner < 4; corner++) {
                int offset = face * FACE_FLOATS + corner * STRIDE;
                double[] sum = sums.computeIfAbsent(cellKey(offset, cell), key -> new double[4]);
                sum[0] += vertices[offset];
                sum[1] += vertices[offset + 1];
                sum[2] += vertices[offset + 2];
                sum[3]++;
            }
        }

        // 残る面を、順番を保ったまま詰める。kept[i] = 面 i より前に残った面の数（グループの範囲の数え直しに使う）
        int[] kept = new int[faceCount + 1];
        float[] out = new float[vertices.length];
        int outFaces = 0;
        long[] cells = new long[4];
        for (int face = 0; face < faceCount; face++) {
            kept[face] = outFaces;
            int distinct = 0;
            for (int corner = 0; corner < 4; corner++) {
                long key = cellKey(face * FACE_FLOATS + corner * STRIDE, cell);
                boolean seen = false;
                for (int i = 0; i < distinct; i++) {
                    seen |= cells[i] == key;
                }
                if (!seen) {
                    cells[distinct++] = key;
                }
            }
            if (distinct < 3) {
                continue;
            }
            int from = face * FACE_FLOATS;
            int to = outFaces * FACE_FLOATS;
            System.arraycopy(vertices, from, out, to, FACE_FLOATS);
            for (int corner = 0; corner < 4; corner++) {
                double[] sum = sums.get(cellKey(from + corner * STRIDE, cell));
                int offset = to + corner * STRIDE;
                out[offset] = (float) (sum[0] / sum[3]);
                out[offset + 1] = (float) (sum[1] / sum[3]);
                out[offset + 2] = (float) (sum[2] / sum[3]);
            }
            outFaces++;
        }
        kept[faceCount] = outFaces;

        List<Group> simplified = new ArrayList<>(groups.size());
        for (Group group : groups) {
            simplified.add(new Group(group.name(), group.material(), kept[Math.min(group.from(), faceCount)],
                    kept[Math.min(group.to(), faceCount)]));
        }
        return create(java.util.Arrays.copyOf(out, outFaces * FACE_FLOATS), simplified);
    }

    /** 頂点がどの箱に入るか。座標を箱の番号に直して 1 つの long に詰める。 */
    protected long cellKey(int offset, double cell) {
        long x = (long) Math.floor(vertices[offset] / cell) & 0x1FFFFF;
        long y = (long) Math.floor(vertices[offset + 1] / cell) & 0x1FFFFF;
        long z = (long) Math.floor(vertices[offset + 2] / cell) & 0x1FFFFF;
        return x | (y << 21) | (z << 42);
    }

    @Override
    public boolean isEmpty() {
        return faceCount == 0;
    }

    /**
     * ガラスの名前か。
     *
     * <p>{@code glass} そのものと、区切り（{@code _} / {@code .}）が続くものだけを拾う。
     * Blender は同じ名前が重なると {@code glass.001} を作るので、そこも当てておく。</p>
     */
    protected static boolean isGlassName(String name) {
        if (name == null || !name.startsWith(GLASS_PREFIX)) {
            return false;
        }
        String rest = name.substring(GLASS_PREFIX.length());
        return rest.isEmpty() || rest.charAt(0) == '_' || rest.charAt(0) == '.';
    }

    /**
     * その面の不透明度。
     *
     * <p>MTL が {@code d} を書いていればそれが正。書いていないガラスにだけ既定値を当てる
     * （マテリアルを割り当てていないメッシュでも名前だけで透けるように）。</p>
     */
    protected static float faceAlpha(float materialAlpha, String groupName, @Nullable String materialName) {
        if (materialAlpha < OPAQUE_THRESHOLD) {
            return materialAlpha;
        }
        // マテリアル名がガラスならそれだけで透ける。オブジェクト名がガラスでも、
        // マテリアルが別の役目（ライトなど）を指していればそちらが優先
        String fromMaterial = roleName(materialName);
        boolean glass = fromMaterial != null ? isGlassName(fromMaterial) : isGlassName(withoutCopySuffix(groupName));
        return glass ? GLASS_DEFAULT_ALPHA : 1.0F;
    }

    // ------------------------------------------------------------------
    // 読み込み
    // ------------------------------------------------------------------

    protected static ObjMesh load(CarId location) {
        Optional<Assets.Asset> resource = Assets.get().getResource(location);
        if (resource.isEmpty()) {
            LOGGER.error("OBJ モデルが見つかりません: {}", location);
            return empty();
        }
        try (BufferedReader reader = resource.get().openAsReader()) {
            ObjMesh model = parse(reader, location);
            LOGGER.info("OBJ モデルを読み込みました: {}（{} 面・{} 頂点）", location, model.faceCount,
                    model.faceCount * 4);
            return model;
        } catch (IOException | RuntimeException e) {
            LOGGER.error("OBJ モデルの読み込みに失敗しました: {}", location, e);
            return empty();
        }
    }

    protected static ObjMesh parse(BufferedReader reader, CarId location)
            throws IOException {
        // OBJ のインデックスは 1 始まりでファイル全体に通し番号。オブジェクトが分かれていても連番になる
        List<float[]> positions = new ArrayList<>();
        List<float[]> normals = new ArrayList<>();
        List<float[]> uvs = new ArrayList<>();
        Map<String, float[]> materials = new HashMap<>();

        List<Float> out = new ArrayList<>();
        // 拡散色 3 ＋ 不透明度 1。マテリアルが無ければ白の不透明
        float[] color = {1.0F, 1.0F, 1.0F, 1.0F};

        // tools/blender_gauge.py が置く基準の枠。書き出しから外し忘れても描かないよう、
        // 名前で捨てる。頂点は読み飛ばさないこと——OBJ のインデックスはファイル全体の
        // 通し番号なので、飛ばすと以降の面がずれる。捨てるのは面だけ
        boolean skipping = false;

        List<Group> groups = new ArrayList<>();
        String groupName = null;
        String materialName = null;
        int groupStart = 0;

        String line;
        while ((line = reader.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty() || line.charAt(0) == '#') {
                continue;
            }
            String[] token = line.split("\\s+");
            switch (token[0]) {
                case "v" -> // Blender 標準の向きから、エンティティ空間へ。X と Z を反転する
                        positions.add(new float[]{
                                -parseFloat(token[1]), parseFloat(token[2]), -parseFloat(token[3])});
                case "vn" -> normals.add(new float[]{
                        -parseFloat(token[1]), parseFloat(token[2]), -parseFloat(token[3])});
                // OBJ の V は下が 0、Minecraft は上が 0
                case "vt" -> uvs.add(new float[]{parseFloat(token[1]), 1.0F - parseFloat(token[2])});
                case "mtllib" -> materials.putAll(loadMaterials(location, rest(line, token)));
                case "usemtl" -> {
                    // Blender は空のマテリアルスロットを「usemtl 」（名前なし）と書く。行を trim した後なので
                    // substring(7) だと範囲外で落ち、モデルごと読めなくなる
                    String next = rest(line, token);
                    // 同じオブジェクトの中でもマテリアルが変われば区切る。マテリアル名が役目を持てるので
                    if (groupName != null && out.size() > groupStart && !next.equals(materialName)) {
                        groups.add(new Group(groupName, materialName, groupStart / FACE_FLOATS,
                                out.size() / FACE_FLOATS));
                        groupStart = out.size();
                    }
                    materialName = next;
                    color = materials.getOrDefault(next, new float[]{1.0F, 1.0F, 1.0F, 1.0F});
                }
                case "o", "g" -> {
                    // 直前のオブジェクトをここで閉じる。面は名前の後ろに並ぶので、
                    // 区切りが来た時点までが 1 つ
                    if (groupName != null && out.size() > groupStart) {
                        groups.add(new Group(groupName, materialName, groupStart / FACE_FLOATS,
                                out.size() / FACE_FLOATS));
                    }
                    groupName = token.length > 1 ? token[1] : "";
                    materialName = null;
                    groupStart = out.size();
                    // マテリアルは前のオブジェクトから引き継がない。Blender はマテリアルを持つ
                    // オブジェクトには必ず usemtl を書くので、書かれていないのは「無し」の意味。
                    // 引き継ぐと、マテリアルの無いガラスが直前のバネの赤に染まる
                    color = new float[]{1.0F, 1.0F, 1.0F, 1.0F};
                    skipping = groupName.startsWith(GAUGE_PREFIX);
                }
                case "f" -> {
                    if (!skipping) {
                        // 不透明度は「マテリアルの d、無ければガラスの既定値」。
                        // 名前を見るのはここだけで、描画中は頂点の α しか見ない
                        appendFace(out, token, positions, normals, uvs, color,
                                faceAlpha(color[3], groupName == null ? "" : groupName, materialName));
                    }
                }
                default -> {
                    // s / その他は読み飛ばす
                }
            }
        }

        if (groupName != null && out.size() > groupStart) {
            groups.add(new Group(groupName, materialName, groupStart / FACE_FLOATS, out.size() / FACE_FLOATS));
        }

        float[] vertices = new float[out.size()];
        for (int i = 0; i < vertices.length; i++) {
            vertices[i] = out.get(i);
        }
        return create(vertices, groups);
    }

    /**
     * 面を積む。<b>四角形は四角形のまま、それ以外は三角形に割って</b>縮退四角形で積む。
     *
     * <p>割り方は {@link PolygonTriangulator}（耳切り法）に任せる。<b>凹んだ n-gon も
     * 正しく割れる</b>ので、Blender 側で「三角形化」して書き出す必要はない——むしろ
     * <b>三角形化しないほうが軽い</b>（下記）。</p>
     *
     * <p>以前は最初の頂点からの扇状分割だったが、これは凸多角形でしか正しくない。実際に
     * 書き出された車体は 52 個の n-gon のうち 44 個が凹んでいて、面がはみ出していた。</p>
     *
     * <h2>四角形をそのまま積む</h2>
     *
     * <p>書き出された車体はほとんどが四角形（s15 で 2772 面中 2502）で、以前はこれを 2 つの
     * 三角形に割り、それぞれ縮退四角形で流していた——<b>四角形 1 枚に 8 頂点、半分は潰れた頂点</b>。
     * QUADS は GPU 側で 2 つの三角形に割られるので、そのまま 4 頂点で渡せば同じものが描ける
     * （頂点が約 44% 減る。影 MOD の影パスがあればそちらでも減る）。</p>
     *
     * <p><b>ただし割る対角線を揃えること。</b>QUADS は頂点 0-2 の対角線で割られる
     * （添字 0,1,2 / 2,3,0）。一方耳切り法は巻き方向しだいで 1-3 を選ぶことがあり、
     * ねじれた四角形ではどちらで割るかで形も陰影も変わる。そこで耳切り法の選んだ対角線の
     * 端から積み始め、<b>今まで描いていたのとまったく同じ 2 つの三角形</b>にする。
     * 凹んだ四角形も、耳切り法は必ず内側を通る対角線を選ぶので同じ扱いで正しく描ける。</p>
     */
    protected static void appendFace(List<Float> out, String[] token, List<float[]> positions,
                                   List<float[]> normals, List<float[]> uvs, float[] color,
                                   float alpha) {
        int corners = token.length - 1;
        if (corners < 3) {
            return;
        }

        List<float[]> polygon = new ArrayList<>(corners);
        for (int i = 0; i < corners; i++) {
            polygon.add(pick(positions, token[i + 1].split("/", -1)[0]));
        }
        List<int[]> triangles = PolygonTriangulator.triangulate(polygon);

        if (corners == 4 && triangles.size() == 2) {
            int start = diagonalStart(triangles.get(0), triangles.get(1));
            if (start >= 0) {
                // 元の巻き方向のまま、対角線の端から回す。GPU の割る対角線 0-2 が
                // 耳切り法の選んだ対角線（start と start+2）に一致する
                for (int i = 0; i < 4; i++) {
                    appendVertex(out, token[(start + i) % 4 + 1], positions, normals, uvs, color, alpha);
                }
                return;
            }
        }

        for (int[] triangle : triangles) {
            appendVertex(out, token[triangle[0] + 1], positions, normals, uvs, color, alpha);
            appendVertex(out, token[triangle[1] + 1], positions, normals, uvs, color, alpha);
            appendVertex(out, token[triangle[2] + 1], positions, normals, uvs, color, alpha);
            // 3 番目の頂点を 2 回。四角形の 1 辺が潰れた形になる
            appendVertex(out, token[triangle[2] + 1], positions, normals, uvs, color, alpha);
        }
    }

    /**
     * 四角形を割った 2 つの三角形が共有する対角線の、片方の端（0..3）。
     *
     * <p>2 つが「向かい合う 2 頂点を共有し、合わせて 4 頂点を覆う」形になっていなければ -1
     * （割り方が崩れた四角形。呼ぶ側は三角形のまま積む）。</p>
     */
    protected static int diagonalStart(int[] first, int[] second) {
        int shared = 0;
        int mask = 0;
        int end = -1;
        for (int a : first) {
            mask |= 1 << a;
            for (int b : second) {
                if (a == b) {
                    shared++;
                    end = a;
                }
            }
        }
        for (int b : second) {
            mask |= 1 << b;
        }
        if (shared != 2 || mask != 0b1111) {
            return -1;
        }
        // 共有する 2 頂点が隣り合っていれば対角線ではない（辺を共有しているだけ）
        int other = -1;
        for (int a : first) {
            for (int b : second) {
                if (a == b && a != end) {
                    other = a;
                }
            }
        }
        return (end + 2) % 4 == other ? end : -1;
    }

    /** {@code 位置/UV/法線} の組を 1 頂点ぶん積む。UV も法線も省略されうる。 */
    protected static void appendVertex(List<Float> out, String token, List<float[]> positions,
                                     List<float[]> normals, List<float[]> uvs, float[] color,
                                     float alpha) {
        String[] index = token.split("/", -1);

        float[] position = pick(positions, index[0]);
        out.add(position[0]);
        out.add(position[1]);
        out.add(position[2]);

        float[] normal = index.length > 2 ? pick(normals, index[2]) : null;
        // 法線が無ければ上向きにしておく。真っ黒になるより平坦に見える方がまし
        out.add(normal == null ? 0.0F : normal[0]);
        out.add(normal == null ? 1.0F : normal[1]);
        out.add(normal == null ? 0.0F : normal[2]);

        float[] uv = index.length > 1 ? pick(uvs, index[1]) : null;
        out.add(uv == null ? 0.0F : uv[0]);
        out.add(uv == null ? 0.0F : uv[1]);

        out.add(color[0]);
        out.add(color[1]);
        out.add(color[2]);
        out.add(alpha);
    }

    /**
     * インデックスを引く。
     *
     * <p>OBJ のインデックスは 1 始まりで、<b>負の値は末尾からの相対</b>（-1 が直前の頂点）。
     * Blender は正の絶対値しか書かないが、他のツールを通した OBJ で出てくる。</p>
     */
    protected static float[] pick(List<float[]> list, String token) {
        if (token.isEmpty()) {
            return null;
        }
        int index = Integer.parseInt(token);
        return list.get(index > 0 ? index - 1 : list.size() + index);
    }

    /**
     * MTL を読んで、マテリアル名 → 拡散色の表を作る。
     *
     * <p>UV テクスチャができるまでのつなぎとして、<b>拡散色（Kd）を頂点カラーとして掛ける</b>。
     * テクスチャに色が入ったら Blender 側でマテリアルのベースカラーを白にすること
     * （Blender の既定は 0.8 のグレーなので、そのままだとテクスチャが暗くなる）。</p>
     *
     * <p>MTL が無くても構わない。その場合は全体が白（テクスチャそのまま）になる。</p>
     *
     * <p>あわせて<b>不透明度（{@code d}、または裏返しの {@code Tr}）</b>も読む。Blender では
     * マテリアルの <b>Alpha</b> がそのまま {@code d} として書き出されるので、ガラスの濃さは
     * Blender 側で決められる（コードもテクスチャも触らずに済む）。</p>
     */
    protected static Map<String, float[]> loadMaterials(CarId objLocation, String fileName) {
        String directory = objLocation.getPath().substring(0, objLocation.getPath().lastIndexOf('/') + 1);
        CarId location = CarId.of(objLocation.getNamespace(), directory + fileName);

        Optional<Assets.Asset> resource = Assets.get().getResource(location);
        if (resource.isEmpty()) {
            LOGGER.warn("MTL が見つかりません（色は白になります）: {}", location);
            return Map.of();
        }

        Map<String, float[]> materials = new HashMap<>();
        try (BufferedReader reader = resource.get().openAsReader()) {
            String name = null;
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                String[] token = line.split("\\s+");
                if (token[0].equals("newmtl") && token.length > 1) {
                    name = line.substring(7).trim();
                } else if (token[0].equals("Kd") && token.length > 3 && name != null) {
                    float[] existing = materials.get(name);
                    materials.put(name, new float[]{
                            parseFloat(token[1]), parseFloat(token[2]), parseFloat(token[3]),
                            existing == null ? 1.0F : existing[3]});
                } else if (token[0].equals("d") && token.length > 1 && name != null) {
                    // Kd と d はどちらが先に来るか決まっていないので、揃うまで互いの値を残す
                    setAlpha(materials, name, parseFloat(token[1]));
                } else if (token[0].equals("Tr") && token.length > 1 && name != null) {
                    // Tr は透明度（d の裏返し）。両方書く MTL もあるが、意味が同じなので上書きでよい
                    setAlpha(materials, name, 1.0F - parseFloat(token[1]));
                }
            }
        } catch (IOException | RuntimeException e) {
            LOGGER.warn("MTL の読み込みに失敗しました: {}", location, e);
        }
        return materials;
    }

    /** そのマテリアルの不透明度だけを差し替える。まだ Kd を読んでいなければ白で作る。 */
    protected static void setAlpha(Map<String, float[]> materials, String name, float alpha) {
        float[] existing = materials.get(name);
        materials.put(name, existing == null
                ? new float[]{1.0F, 1.0F, 1.0F, alpha}
                : new float[]{existing[0], existing[1], existing[2], alpha});
    }

    protected static float parseFloat(String token) {
        return Float.parseFloat(token);
    }

    /** 行の先頭のキーワードより後ろ（名前に空白を含んでよい）。何も無ければ空文字。 */
    protected static String rest(String line, String[] token) {
        return token.length > 1 ? line.substring(token[0].length()).trim() : "";
    }
}
