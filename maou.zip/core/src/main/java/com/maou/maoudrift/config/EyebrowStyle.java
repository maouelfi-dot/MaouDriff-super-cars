package com.maou.maoudrift.config;

/**
 * Gaya lampu alis (eyebrow). Dihitung murah dari waktu saja (tanpa shader).
 * Disimpan ke config dengan nama, jadi urutan boleh berubah.
 */
public enum EyebrowStyle {

    /** Warna tetap. */
    SOLID,
    /** Berdenyut pelan (napas). */
    PULSE,
    /** Warna berputar pelan melewati pelangi (abaikan warna pilihan). */
    RAINBOW;

    /** Kunci terjemahan. */
    public String translationKey() {
        return "screen.maoudrift.eyebrow.style." + name().toLowerCase(java.util.Locale.ROOT);
    }
}
