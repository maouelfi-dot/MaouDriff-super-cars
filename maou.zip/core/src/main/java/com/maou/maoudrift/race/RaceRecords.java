package com.maou.maoudrift.race;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * コースの定義とベストタイムの保管庫。
 *
 * <p><b>Minecraft には触らない。</b>ワールドと一緒に保存するのは版ごとの {@code RaceData}（{@code SavedData} の殻）で、
 * 中身の読み書きは {@link #save}・{@link #load} が {@link RaceTag} を通して行う。書き換えたら {@link #setDirty}
 * が殻へ知らせる（殻が {@link #onChange} で受け口を渡す）。</p>
 *
 * <p>ベストは<b>タイムだけでなく内訳も持つ</b>。走行中に「自己ベストに対して今どれだけ
 * 速いか」を出すには、ベスト走行が各チェックポイントを何秒で通ったかが要る。あわせて
 * 区間ごとのベスト（別々の周に出したものでよい）も持つので、その合計が理論ベストになる。</p>
 *
 * <p>ベストは<b>「プレイヤー × コース × クラス」ごとに 1 本</b>。クラスの名前が空（{@link #NO_CLASS}）のものが
 * <b>クラスなし</b>。<b>1 つの周は 1 か所にだけ入る</b>——宣言したクラス（条件を満たしたとき）か、クラスなし。
 * 以前は全部の周を「総合」にも入れていたので、同じ周が 2 か所にあり、片方を消したときにもう片方をどうするかが
 * 決められなかった。</p>
 */
public final class RaceRecords {

    private static final long[] NONE = new long[0];

    /** クラスなしの記録のクラス名。宣言していない周（と、宣言したクラスの条件を満たさなかった周）が入る。 */
    public static final String NO_CLASS = "";

    // 名前順。線が重なったときにどちらが選ばれるかを再現可能にしておく
    private final Map<String, Course> courses = new java.util.TreeMap<>();
    /** プレイヤーごと・コースごと・クラスごとのベスト。 */
    private final Map<UUID, Map<String, Map<String, Best>>> bestLaps = new HashMap<>();

    /**
     * 1 人ぶん・1 コース・1 クラスぶんのベスト。
     *
     * <p><b>名前を一緒に持つ</b>のは、ランキングをオフラインのプレイヤーぶんも出すため。
     * UUID からの逆引きはプロフィールキャッシュ次第で外れることがある。</p>
     */
    public static final class Best {
        private String name = "";
        private long millis;
        /** ベストラップでの各チェックポイント通過時刻。ラップ開始からの相対 [ms]。 */
        private long[] splits = NONE;
        /** 区間ごとのベスト [ms]。別々の周のものが混ざってよい。合計が理論ベスト。 */
        private long[] sectors = NONE;
    }

    public Optional<Course> course(String name) {
        return Optional.ofNullable(courses.get(name));
    }

    /**
     * 1 つの次元に作れるコースの数。<b>作るときに断る</b>（{@code RaceCommands}）。上限が無いと、ロビーの
     * パケットに載る一覧が溢れ、後ろのコースが K の画面から黙って消えた。
     */
    public static final int MAX_COURSES = 256;

    public Course createCourse(String name) {
        Course course = new Course(name);
        courses.put(name, course);
        setDirty();
        return course;
    }

    public boolean removeCourse(String name) {
        boolean removed = courses.remove(name) != null;
        if (removed) {
            setDirty();
        }
        return removed;
    }

    public java.util.Collection<Course> courses() {
        return courses.values();
    }

    /** 1 周を取り込んだ結果。ベストを更新したか（クラスなし・クラス。入るのはどちらか 1 か所だけ）。 */
    public record LapRecord(boolean noClass, boolean inClass) {
    }

    /**
     * 1 周ぶんの記録を取り込む。{@code raceClass} が null でなければそのクラスに、null ならクラスなしに入れる（1 か所だけ）。
     *
     * @param raceClass 宣言して走ったクラスの名前。宣言していなければ null
     * @param splits    各チェックポイントの通過時刻。ラップ開始からの相対 [ms]
     */
    public LapRecord recordLap(UUID player, String playerName, String course, String raceClass,
                               long millis, long[] splits) {
        boolean declared = raceClass != null && !raceClass.isEmpty();
        boolean improved = recordInto(player, playerName, course, declared ? raceClass : NO_CLASS, millis, splits);
        return new LapRecord(!declared && improved, declared && improved);
    }

    /**
     * 1 本ぶんへ取り込む。
     *
     * <p>ラップタイムが自己ベストを更新したときだけ true を返すが、<b>区間ベストは
     * 更新できていれば毎回取り込む</b>。理論ベストは「別々の周に出した最速区間の合計」なので、
     * ベストラップでなかった周にも更新の機会がある。</p>
     */
    private boolean recordInto(UUID player, String playerName, String course, String raceClass,
                               long millis, long[] splits) {
        Best best = bestLaps.computeIfAbsent(player, key -> new HashMap<>())
                .computeIfAbsent(course, key -> new HashMap<>())
                .computeIfAbsent(raceClass, key -> new Best());
        best.name = playerName;
        setDirty();

        long[] sectors = toSectors(millis, splits);
        if (best.sectors.length != sectors.length) {
            // チェックポイントの数が変わった。前の区間ベストは比べようがないので捨てる
            best.sectors = sectors;
        } else {
            for (int i = 0; i < sectors.length; i++) {
                if (best.sectors[i] <= 0L || sectors[i] < best.sectors[i]) {
                    best.sectors[i] = sectors[i];
                }
            }
        }

        if (best.millis > 0L && best.millis <= millis) {
            return false;
        }
        best.millis = millis;
        best.splits = splits.clone();
        return true;
    }

    /** 通過時刻の並びを区間タイムへ直す。区間はチェックポイントの数 + 1 本。 */
    private static long[] toSectors(long millis, long[] splits) {
        long[] sectors = new long[splits.length + 1];
        long previous = 0L;
        for (int i = 0; i < splits.length; i++) {
            sectors[i] = splits[i] - previous;
            previous = splits[i];
        }
        sectors[splits.length] = millis - previous;
        return sectors;
    }

    /**
     * そのコースの全員のベストを消す。消した人数。
     *
     * <p><b>コースを引き直したら過去のタイムは比較できなくなる。</b>そのときに使う。</p>
     */
    public int clearCourseBests(String course) {
        int removed = 0;
        for (Map<String, Map<String, Best>> byCourse : bestLaps.values()) {
            if (byCourse.remove(course) != null) {
                removed++;
            }
        }
        if (removed > 0) {
            setDirty();
        }
        return removed;
    }

    /**
     * 1 人の 1 つの記録を消す（OP が K の画面から）。消したか。
     *
     * <p>消すのはその 1 つだけ（{@code raceClass} が空ならクラスなしの記録）。1 つの周は 1 か所にしか入らないので、
     * ほかの記録には触らなくてよい。</p>
     */
    public boolean removeBest(UUID player, String course, String raceClass) {
        Map<String, Map<String, Best>> byCourse = bestLaps.get(player);
        Map<String, Best> byClass = byCourse == null ? null : byCourse.get(course);
        if (byClass == null) {
            return false;
        }
        boolean removed = byClass.remove(raceClass == null ? NO_CLASS : raceClass) != null;
        if (byClass.isEmpty()) {
            byCourse.remove(course);
        }
        if (removed) {
            setDirty();
        }
        return removed;
    }

    /** そのクラスの記録の件数（全員・全コース）。クラスを変える前の確認に出す。 */
    public int countClassBests(String raceClass) {
        int count = 0;
        for (Map<String, Map<String, Best>> byCourse : bestLaps.values()) {
            for (Map<String, Best> byClass : byCourse.values()) {
                Best best = byClass.get(raceClass);
                if (best != null && best.millis > 0L) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * そのクラスの記録を全員・全コースぶん消す。消した件数。
     *
     * <p><b>クラスの中身が変わったら、前の決まりで出したタイムとは比べられない。</b>上書きと削除のときに使う。
     * クラスなしの記録は消さない（決まりに関係なく出したタイムだから）。</p>
     */
    public int clearClassBests(String raceClass) {
        if (raceClass == null || raceClass.isEmpty()) {
            return 0;
        }
        int removed = 0;
        for (Map<String, Map<String, Best>> byCourse : bestLaps.values()) {
            for (Map<String, Best> byClass : byCourse.values()) {
                Best best = byClass.remove(raceClass);
                if (best != null && best.millis > 0L) {
                    removed++;
                }
            }
        }
        if (removed > 0) {
            setDirty();
        }
        return removed;
    }

    /** クラスなしのベストラップ [ms]。無ければ 0。 */
    public long bestLap(UUID player, String course) {
        return bestLap(player, course, NO_CLASS);
    }

    /** そのクラスのベストラップ [ms]。無ければ 0。{@code raceClass} が空ならクラスなし。 */
    public long bestLap(UUID player, String course, String raceClass) {
        Best best = best(player, course, raceClass);
        return best == null ? 0L : best.millis;
    }

    /**
     * ベストラップでの各チェックポイント通過時刻 [ms]。無ければ null。
     *
     * <p>走行中のデルタ表示の比較相手。<b>チェックポイントの数が変わっていたら使えない</b>ので、
     * 呼ぶ側は長さを確かめること。</p>
     */
    public long[] bestSplits(UUID player, String course, String raceClass) {
        Best best = best(player, course, raceClass);
        return best == null || best.millis <= 0L ? null : best.splits;
    }

    /** その人のそのコース・そのクラス（空ならクラスなし）の記録。無ければ null。 */
    public Entry entry(UUID player, String course, String raceClass) {
        Best best = best(player, course, raceClass);
        return best == null || best.millis <= 0L ? null : new Entry(player, best.name, best.millis);
    }

    private Best best(UUID player, String course, String raceClass) {
        Map<String, Map<String, Best>> byCourse = bestLaps.get(player);
        Map<String, Best> byClass = byCourse == null ? null : byCourse.get(course);
        return byClass == null ? null : byClass.get(raceClass == null ? NO_CLASS : raceClass);
    }

    /** そのコースに記録のあるクラスの名前（クラスなしは含めない）。 */
    public java.util.Set<String> recordedClasses(String course) {
        java.util.Set<String> out = new java.util.TreeSet<>();
        for (Map<String, Map<String, Best>> byCourse : bestLaps.values()) {
            Map<String, Best> byClass = byCourse.get(course);
            if (byClass != null) {
                for (Map.Entry<String, Best> entry : byClass.entrySet()) {
                    if (!entry.getKey().isEmpty() && entry.getValue().millis > 0L) {
                        out.add(entry.getKey());
                    }
                }
            }
        }
        return out;
    }

    /** ランキングの 1 行。名前は記録した時点のもの。 */
    public record Entry(UUID player, String name, long millis) {
    }

    /**
     * そのコース・そのクラスの速い順（{@code limit} が 0 以下なら全員）。
     *
     * <p>オフラインの人も含めて出す。名前を一緒に保存しているので、プロフィールキャッシュに
     * 頼らずに表示できる（内訳を持つ前に取った古い記録だけ名前が空になる）。</p>
     */
    public List<Entry> leaderboard(String course, String raceClass, int limit) {
        List<Entry> entries = new ArrayList<>();
        for (Map.Entry<UUID, Map<String, Map<String, Best>>> row : bestLaps.entrySet()) {
            Map<String, Best> byClass = row.getValue().get(course);
            Best best = byClass == null ? null : byClass.get(raceClass == null ? NO_CLASS : raceClass);
            if (best != null && best.millis > 0L) {
                entries.add(new Entry(row.getKey(), best.name, best.millis));
            }
        }
        entries.sort(java.util.Comparator.comparingLong(Entry::millis));
        return limit > 0 && entries.size() > limit ? new ArrayList<>(entries.subList(0, limit)) : entries;
    }

    /** 書き換えたときに呼ぶもの（版の殻が {@code setDirty} を渡す）。 */
    private Runnable onChange = () -> { };

    /** 書き換えの知らせ先を差し替える。殻が作った直後に 1 回だけ呼ぶ。 */
    public void onChange(Runnable listener) {
        this.onChange = listener == null ? () -> { } : listener;
    }

    /** 保存し直してもらう。コースの線を引き直したときなど、外から中身を変えたときにも呼ぶ。 */
    public void setDirty() {
        onChange.run();
    }

    /** {@code tag} へ書き込む。キー名は 1.20.1 の頃から変えていない（古いワールドの記録が読める）。 */
    public void save(RaceTag tag) {
        List<RaceTag> courseList = new ArrayList<>();
        for (Course course : courses.values()) {
            RaceTag entry = tag.child();
            course.save(entry);
            courseList.add(entry);
        }
        tag.putList("Courses", courseList);

        List<RaceTag> bestList = new ArrayList<>();
        for (Map.Entry<UUID, Map<String, Map<String, Best>>> entry : bestLaps.entrySet()) {
            for (Map.Entry<String, Map<String, Best>> byCourse : entry.getValue().entrySet()) {
                for (Map.Entry<String, Best> best : byCourse.getValue().entrySet()) {
                    RaceTag row = tag.child();
                    row.putUUID("Player", entry.getKey());
                    row.putString("Course", byCourse.getKey());
                    row.putString("Class", best.getKey());
                    row.putString("PlayerName", best.getValue().name);
                    row.putLong("Millis", best.getValue().millis);
                    row.putLongArray("Splits", best.getValue().splits);
                    row.putLongArray("Sectors", best.getValue().sectors);
                    bestList.add(row);
                }
            }
        }
        tag.putList("Best", bestList);
    }

    public static RaceRecords load(RaceTag tag) {
        RaceRecords data = new RaceRecords();
        for (RaceTag entry : tag.getList("Courses")) {
            Course course = Course.load(entry);
            data.courses.put(course.name(), course);
        }
        for (RaceTag row : tag.getList("Best")) {
            UUID player = row.getUUID("Player");
            if (player == null) {
                continue;
            }
            // 内訳を持つ前に保存された記録も読める。タイムだけあって内訳が無い状態になり、
            // 次にそのコースを 1 周すれば内訳が入る。クラスを持つ前の記録（"Class" が無い）はクラスなしになる
            Best best = new Best();
            best.name = row.getString("PlayerName");
            best.millis = row.getLong("Millis");
            best.splits = row.getLongArray("Splits");
            best.sectors = row.getLongArray("Sectors");
            data.bestLaps.computeIfAbsent(player, key -> new HashMap<>())
                    .computeIfAbsent(row.getString("Course"), key -> new HashMap<>())
                    .put(row.getString("Class"), best);
        }
        return data;
    }
}
