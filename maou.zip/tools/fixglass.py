"""fixglass.py in.obj out.obj
Kaca: tiap komponen kaca yang tersambung (vertex dipakai bersama) dijadikan SATU kesatuan.
 - kaca samping yang sebagian besar sudah di pintu & berada di satu sisi (|x|>=0.6) -> semua ke pintu itu (m_doorglass)
 - selain itu (kaca depan, belakang, atap, kaca kecil/quarter, strip kap) -> glass_main, satu material."""
import sys, numpy as np
sys.path.insert(0,'/home/claude/src/tools'); sys.path.insert(0,'/home/claude/work')
from objlib import Obj
from comp import comps
o=Obj(sys.argv[1]); V=o.V
mats={f[1] for f in o.faces}
main_mat=next(m for m in ('m_glass_main','m_glass') if m in mats)
sel=[f for f in o.faces if 'glass' in f[1] and f[0] in ('glass_main','body','part_door_l','part_door_r','part_hood')]
n_door=n_main=0
for c in comps(o,sel):
    p=V[[x[0] for f in c for x in f[2]]]
    one_side=(p[:,0].min()>=0.6) or (p[:,0].max()<=-0.6)
    side=1 if p[:,0].mean()>0 else -1
    dn='part_door_l' if side>0 else 'part_door_r'
    in_door=sum(1 for f in c if f[0]==dn)/len(c)
    if one_side and in_door>=0.4 and len(c)>=8:
        for f in c: f[0]=dn; f[1]='m_doorglass'
        n_door+=len(c)
    else:
        for f in c:
            if f[0] in ('part_door_l','part_door_r','body','part_hood') or f[1]=='m_doorglass':
                f[0]='glass_main'; f[1]=main_mat
        n_main+=len(c)
print('kaca->pintu',n_door,' kaca->glass_main',n_main)
o.write(sys.argv[2])
