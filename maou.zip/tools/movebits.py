import numpy as np
from PIL import Image, ImageDraw
R='core/src/main/resources/assets/maoudrift/models/entity/'
def run(car,depth=0.12):
    p=R+car+'.obj'; L=open(p).read().rstrip('\n').split('\n')
    V=[];g=None;mat=None;F=[]
    for i,l in enumerate(L):
        t=l.split()
        if not t: continue
        if t[0]=='v': V.append([float(x) for x in t[1:4]])
        elif t[0] in('g','o'): g=t[1]
        elif t[0]=='usemtl': mat=t[1]
        elif t[0]=='f': F.append((i,g,mat,[int(x.split('/')[0])-1 for x in t[1:]]))
    V=np.array(V); moved={}
    for door,sd in (('part_door_l',1),('part_door_r',-1)):
        df=[f for f in F if f[1]==door]
        D=V[[k for f in df for k in f[3]]]; ax=np.abs(D[:,0]); xmax=ax.max()
        z0=D[:,2].min()-.1;y1=D[:,1].max()+.1;S=1000/(D[:,2].max()-D[:,2].min()+.2)
        W=1000;H=int((y1-D[:,1].min()+.1)*S)
        m=Image.new('L',(W,H),0);d=ImageDraw.Draw(m)
        P=lambda q:((q[2]-z0)*S,(y1-q[1])*S)
        for f in df: d.polygon([P(V[k]) for k in f[3][:3]],fill=255)
        M=np.array(m)>0
        for f in F:
            if f[1]!='body': continue
            cc=V[f[3]].mean(0)
            if cc[0]*sd<=0 or abs(cc[0])<xmax-depth or abs(cc[0])>xmax+0.05: continue
            px,py=P(cc)
            if 0<=px<W and 0<=py<H and M[int(py),int(px)]: moved[f[0]]=(door,f[2])
    keep=[l for i,l in enumerate(L) if i not in moved]
    add=[]
    for door in ('part_door_l','part_door_r'):
        cur=None
        for i,(d_,mt) in sorted(moved.items()):
            if d_!=door: continue
            if mt!=cur: add+=['g '+door,'usemtl '+mt]; cur=mt
            add.append(L[i])
    open(p,'w').write('\n'.join(keep+add)+'\n'); print(car,'moved',len(moved))
import sys
for c in ['supra','krc_supra','zacoe_m2','varis_gts']: run(c)
