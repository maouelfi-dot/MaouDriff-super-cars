"""fixups.py - rapikan kap & kaca pintu: python3 fixups.py <supra|krc> in.obj out.obj"""
import sys, numpy as np
mode, src, dst = sys.argv[1:4]
V=[]; head=[]; faces=[]; g=m=None
for ln in open(src):
    if ln.startswith("v "): V.append(tuple(map(float, ln.split()[1:4]))); head.append(ln)
    elif ln.startswith(("vt ", "vn ", "mtllib")): head.append(ln)
    elif ln.startswith("o "): g = ln.split()[1]
    elif ln.startswith("usemtl "): m = ln.split()[1]
    elif ln.startswith("f "): faces.append([g, m, ln.split()[1:]])
V = np.array(V)
def ctr(f): return V[[int(t.split("/")[0]) - 1 for t in f[2]]].mean(0)
moved = {}
for f in faces:
    c = ctr(f)
    if mode == "supra" and f[0] == "part_hood":
        if f[1] == "m_VF11994Grille3AMaterial1": f[0] = None; moved["biru(dibuang)"] = moved.get("biru(dibuang)", 0) + 1
        elif f[1] == "m_glass": f[0] = "glass_main"; moved["kaca->kaca"] = moved.get("kaca->kaca", 0) + 1
        elif c[1] > 1.12 or c[2] < 0.55: f[0] = "body"; moved["liar->body"] = moved.get("liar->body", 0) + 1
    if mode == "krc" and f[0] == "glass_main":
        if abs(c[0]) > 0.55 and -0.9 <= c[2] <= 0.78 and c[1] > 0.9:
            f[0] = "part_door_l" if c[0] > 0 else "part_door_r"; f[1] = "m_doorglass"; moved["kaca->pintu"] = moved.get("kaca->pintu", 0) + 1
print(moved)
order = []
for f in faces:
    if f[0] and f[0] not in order: order.append(f[0])
out = "".join(head)
for gname in order:
    out += "o %s\n" % gname; cur = None
    for f in faces:
        if f[0] != gname: continue
        if f[1] != cur: out += "usemtl %s\n" % f[1]; cur = f[1]
        out += "f %s\n" % " ".join(f[2])
open(dst, "w").write(out)
