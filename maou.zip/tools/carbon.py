import numpy as np, glob, json, re
from PIL import Image
R='v8/core/src/main/resources/assets/maoudrift/'
def weave(s=256):
    y,x=np.mgrid[0:s,0:s]; c=6
    cx=(x//c);cy=(y//c); sw=(cx+cy)%2
    fx=(x%c)/c; fy=(y%c)/c
    f=np.where(sw==0,np.sin(np.pi*fy),np.sin(np.pi*fx))   # fibre shading
    tw=((x+y)//2)%2*0.15
    v=20+28*f+10*tw
    img=np.stack([v,v,v*1.06],-1).clip(0,255).astype(np.uint8)
    return Image.fromarray(img,'RGB')
def run(car,rect):
    x0,y0,s=rect
    wv=weave(s)
    for f in glob.glob(R+'textures/entity/%s*.png'%car):
        n=f.split('/')[-1]
        if n.endswith('_s.png') or n.startswith('wheel'): continue
        im=Image.open(f).convert('RGBA'); im.paste(wv.convert('RGBA'),(x0,y0)); im.save(f)
    p=R+'models/entity/%s.obj'%car; L=open(p).read().rstrip('\n').split('\n')
    V=[];g=None;nvt=0
    for l in L:
        t=l.split()
        if t and t[0]=='v': V.append([float(a) for a in t[1:4]])
        elif t and t[0]=='vt': nvt+=1
    V=np.array(V); hv=set(); g=None
    for l in L:
        t=l.split()
        if not t: continue
        if t[0] in('g','o'): g=t[1]
        elif t[0]=='f' and g=='part_hood': hv.update(int(x.split('/')[0])-1 for x in t[1:])
    H=V[sorted(hv)]; xa,xb=H[:,0].min(),H[:,0].max(); za,zb=H[:,2].min(),H[:,2].max()
    W_,H_=Image.open(glob.glob(R+'textures/entity/%s.png'%car)[0]).size
    new=[];g=None;out=[]
    for l in L:
        t=l.split()
        if t and t[0] in('g','o'): g=t[1]
        if t and t[0]=='f' and g=='part_hood':
            toks=[]
            for tk in t[1:]:
                a=tk.split('/'); v=V[int(a[0])-1]
                px=x0+4+(v[0]-xa)/(xb-xa)*(s-8); py=y0+4+(v[2]-za)/(zb-za)*(s-8)
                new.append('vt %.6f %.6f'%(px/W_,1-py/H_)); a[1]=str(nvt+len(new)); toks.append('/'.join(a))
            l='f '+' '.join(toks)
        out.append(l)
    open(p,'w').write('\n'.join(out+new)+'\n'); print(car,'hood verts',len(hv),'new vt',len(new))
run('krc_supra',(976,0,256)); run('zacoe_m2',(968,0,256))
# default paint krc -> green first
p=R+'vehicles/krc_supra.json'; d=json.load(open(p))
d['paints'].sort(key=lambda q:q['id']!='green'); d['body']['texture']='maoudrift:textures/entity/krc_supra_green.png'
json.dump(d,open(p,'w'),indent=2)
