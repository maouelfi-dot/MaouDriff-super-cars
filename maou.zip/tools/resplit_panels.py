"""resplit.py - samakan potongan pintu/kap mobil lama dengan potongan ASLI model (komponen mesh utuh), bukan kotak.
Pakai: python3 resplit.py in.obj out.obj"""
import sys, numpy as np
src, dst = sys.argv[1], sys.argv[2]
CREASE = len(sys.argv) > 3 and sys.argv[3] == "crease"
V=[]; lines=[]; faces=[]; grp=None; mat=None
for ln in open(src):
    if ln.startswith("v "): V.append(tuple(map(float, ln.split()[1:4]))); lines.append(("v", ln))
    elif ln.startswith(("vt ", "vn ")): lines.append(("x", ln))
    elif ln.startswith("o "): grp = ln.split()[1]
    elif ln.startswith("usemtl "): mat = ln.split()[1]
    elif ln.startswith("f "):
        faces.append((grp, mat, ln.split()[1:]))
    elif ln.startswith(("mtllib", "#", "s ")): lines.append(("h", ln))
V = np.array(V)
key = {}; pid = np.empty(len(V), int)
for i, p in enumerate(np.round(V, 4)): pid[i] = key.setdefault(tuple(p), len(key))
par = list(range(len(key)))
def find(a):
    while par[a] != a: par[a] = par[par[a]]; a = par[a]
    return a
PANEL = ("part_door_l", "part_door_r", "part_hood")
cand = [i for i, (g, m, t) in enumerate(faces) if (g == "body" or g in PANEL) and m != "m_doorglass"]
fv = {i: [int(t.split("/")[0]) - 1 for t in faces[i][2]] for i in cand}
nodes = {}
def node(v, vn):
    k = (pid[v], vn) if CREASE else (pid[v], 0)
    return nodes.setdefault(k, len(nodes))
fn = {i: [int(t.split("/")[2]) - 1 if t.count("/") >= 2 else 0 for t in faces[i][2]] for i in cand}
fnode = {i: [node(v, n) for v, n in zip(fv[i], fn[i])] for i in cand}
par = list(range(len(nodes)))
for i in cand:
    a = fnode[i][0]
    for v in fnode[i][1:]:
        ra, rb = find(a), find(v)
        if ra != rb: par[ra] = rb
comp = {}
for i in cand: comp.setdefault(find(fnode[i][0]), []).append(i)
new = {}; stats = {}
for i in cand: new[i] = faces[i][0]
for r, fl in comp.items():
    cnt = {k: 0 for k in ("body",) + PANEL}
    for i in fl: cnt[faces[i][0]] += 1
    best = max(cnt, key=lambda k: cnt[k])
    # panel menang bila >= 50% muka komponen dulunya ada di panel itu
    for k in PANEL:
        if cnt[k] * 2 >= len(fl): best = k
    for i in fl: new[i] = best
for k in ("body",) + PANEL:
    o = sum(1 for i in cand if faces[i][0] == k); n = sum(1 for i in cand if new[i] == k); stats[k] = (o, n)
print({k: "lama %d -> baru %d" % v for k, v in stats.items()})
# tulis: header, lalu tiap grup
out = [l for t, l in lines]
order = []
for g, m, t in faces:
    if g not in order: order.append(g)
for g in PANEL:
    if g not in order: order.append(g)
buckets = {g: [] for g in order}
for i, (g, m, t) in enumerate(faces):
    buckets[new.get(i, g)].append((m, t))
body = []
for g in order:
    if not buckets[g]: continue
    body.append("o %s\n" % g); cur = None
    for m, t in buckets[g]:
        if m != cur: body.append("usemtl %s\n" % m); cur = m
        body.append("f %s\n" % " ".join(t))
open(dst, "w").write("".join(out) + "".join(body))
