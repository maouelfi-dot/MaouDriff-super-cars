import numpy as np
class Obj:
    def __init__(s, fn):
        s.V=[]; s.T=[]; s.N=[]; s.other=[]; s.faces=[]; g=m=None
        for ln in open(fn):
            if ln.startswith("v "): s.V.append(tuple(map(float, ln.split()[1:4])))
            elif ln.startswith("vt "): s.T.append(tuple(map(float, ln.split()[1:3])))
            elif ln.startswith("vn "): s.N.append(ln.split()[1:4])
            elif ln.startswith("o "): g = ln.split()[1]
            elif ln.startswith("usemtl "): m = ln.split()[1]
            elif ln.startswith("f "):
                c = [[int(x) - 1 if x else -1 for x in t.split("/")] for t in ln.split()[1:]]
                s.faces.append([g, m, c])
            elif ln.startswith("mtllib"): s.other.append(ln)
        s.V = np.array(s.V); s.T = [list(t) for t in s.T]
        s.order = []
        for f in s.faces:
            if f[0] not in s.order: s.order.append(f[0])
    def vidx(s, f): return [c[0] for c in f[2]]
    def write(s, fn):
        out = []
        out += s.other
        out += ["v %.5f %.5f %.5f\n" % tuple(v) for v in s.V]
        out += ["vt %.6f %.6f\n" % tuple(t) for t in s.T]
        out += ["vn %s %s %s\n" % tuple(n) for n in s.N]
        order = [g for g in s.order if any(f[0] == g for f in s.faces)]
        for g in s.order + [x for x in {f[0] for f in s.faces} if x not in s.order]:
            fs = [f for f in s.faces if f[0] == g]
            if not fs: continue
            out.append("o %s\n" % g); cur = None
            for f in fs:
                if f[1] != cur: out.append("usemtl %s\n" % f[1]); cur = f[1]
                out.append("f " + " ".join("/".join("" if x < 0 else str(x + 1) for x in c) for c in f[2]) + "\n")
        open(fn, "w").write("".join(out))
