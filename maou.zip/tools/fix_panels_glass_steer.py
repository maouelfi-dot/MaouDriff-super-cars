"""fix_all.py in.obj out.obj
1) hapus sisa stir LAMA yang masih menempel di badan (kaku) -> hanya stir grup steering_wheel yang tampil & berputar
2) kaca samping di glass_main yang berada di area pintu dipindah ke pintu (ikut membuka)"""
import sys, numpy as np
from objlib import Obj
o = Obj(sys.argv[1]); V = o.V
def ctr(f): return V[[c[0] for c in f[2]]].mean(0)
# --- 1) stir lama
st = [f for f in o.faces if f[0] == "steering_wheel"]
sv = V[sorted({c[0] for f in st for c in f[2]})]
mean = sv.mean(0); w, E = np.linalg.eigh(np.cov((sv - mean).T)); n = E[:, 0]
c0 = (sv.min(0) + sv.max(0)) / 2; R = 0.5 * max(np.ptp(sv @ E[:, 1]), np.ptp(sv @ E[:, 2])) + 0.015
half = 0.5 * np.ptp(sv @ n) + 0.01
dead = []
for f in o.faces:
    if f[0] != "body": continue
    d = ctr(f) - c0; ax = d @ n; rad = np.linalg.norm(d - ax * n)
    if abs(ax) <= half and rad <= R: dead.append(f)
ds = {id(f) for f in dead}; o.faces = [f for f in o.faces if id(f) not in ds]
print("stir lama dihapus:", len(dead), "muka")
# --- 2) kaca samping -> pintu
moved = 0
for side, name in ((1, "part_door_l"), (-1, "part_door_r")):
    dv = [f for f in o.faces if f[0] == name and "glass" not in f[1]]
    if not dv: continue
    p = V[[c[0] for f in dv for c in f[2]]]; lo, hi = p.min(0), p.max(0)
    for f in o.faces:
        if f[0] != "glass_main": continue
        c = ctr(f)
        vv = V[[x[0] for x in f[2]]]
        if c[0] * side > 0.45 and (vv[:, 2] >= lo[2] - 0.08).all() and (vv[:, 2] <= hi[2] + 0.08).all() and (vv[:, 0] * side > 0.3).all() and c[1] >= lo[1] + 0.2:
            f[0] = name; f[1] = "m_doorglass" if any(x[1] == "m_doorglass" for x in o.faces) else f[1]; moved += 1
print("kaca dipindah ke pintu:", moved)
# --- 3) serpihan runcing di pintu/kap (segitiga sangat panjang & tipis) -> kembali ke badan
cut = 0
for f in o.faces:
    if f[0] in ("part_door_l", "part_door_r", "part_hood") and "glass" not in f[1] and len(f[2]) == 3:
        p = V[[x[0] for x in f[2]]]
        e = [np.linalg.norm(p[i] - p[(i + 1) % 3]) for i in range(3)]
        area = np.linalg.norm(np.cross(p[1] - p[0], p[2] - p[0])) / 2
        longest = max(e)
        if longest > 0.4 and area > 0 and (longest * longest / (2 * area)) > 14:
            f[0] = "body"; cut += 1
print("serpihan runcing dikembalikan ke badan:", cut)
# --- 4) pencilan: muka pintu/kap yang menjulur jauh keluar tubuh utama panel -> kembali ke badan / kaca
out = 0
for name in ("part_door_l", "part_door_r", "part_hood"):
    fs = [f for f in o.faces if f[0] == name]
    if len(fs) < 50: continue
    pts = V[[x[0] for f in fs for x in f[2]]]
    lo = np.percentile(pts, 3, axis=0) - 0.15; hi = np.percentile(pts, 97, axis=0) + 0.15
    for f in fs:
        vv = V[[x[0] for x in f[2]]]
        if (vv < lo).any() or (vv > hi).any():
            f[0] = "glass_main" if "glass" in f[1] else "body"; out += 1
print("pencilan keluar dari panel:", out)
o.write(sys.argv[2])
