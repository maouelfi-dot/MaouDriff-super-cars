import numpy as np, sys
R='core/src/main/resources/assets/maoudrift/models/entity/'
def run(car,rmax=0.235,dmax=0.1):
    p=R+car+'.obj'; L=open(p).read().split('\n')
    V=[]; grp=None; faces=[]  # (lineidx, group, vids)
    for i,l in enumerate(L):
        t=l.split()
        if not t: continue
        if t[0]=='v': V.append([float(x) for x in t[1:4]])
        elif t[0] in('g','o'): grp=t[1] if len(t)>1 else ''
        elif t[0]=='f': faces.append((i,grp,[int(x.split('/')[0])-1 for x in t[1:]]))
    V=np.array(V)
    st=[f for f in faces if f[1]=='steering_wheel']
    P=np.array([V[f[2][:3]] for f in st]); mu=P.mean((0,1)); c=P.mean(1)
    X=c-c.mean(0); w,v=np.linalg.eigh(X.T@X); n=v[:,0]
    drop=set()
    for i,g,ids in faces:
        if g=='steering_wheel' or g.startswith('glass'): continue
        cc=V[ids].mean(0); d=np.dot(cc-mu,n)
        if abs(d)<dmax and np.linalg.norm(cc-mu-d*n)<rmax: drop.add(i)
    open(p,'w').write('\n'.join(l for i,l in enumerate(L) if i not in drop))
    print(car,'dropped',len(drop),'of',len(faces))
for c in ['supra','krc_supra','zacoe_m2','varis_gts']: run(c)
