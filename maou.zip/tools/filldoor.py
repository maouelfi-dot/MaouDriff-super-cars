"""filldoor.py in.obj out.obj [tint]
Isi seluruh bentuk pintu: kulit luar pintu yang masih tertinggal di 'body' (di tepi atas/bawah/belakang, atau celah di dalam) dipindah ke pintu.
Cara: raster muka pintu (sisi luar) di bidang (z,y) -> closing + isi lubang -> peta tinggi x -> muka body yang menghadap luar & ada di dalam topeng & x sebanding -> pintu."""
import sys, numpy as np
from scipy import ndimage as ndi
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
o=Obj(sys.argv[1]); V=o.V; tint=len(sys.argv)>3
RES=0.01
def fn(f):
    q=V[[c[0] for c in f[2]]]
    n=np.cross(q[1]-q[0],q[2]-q[0]); l=np.linalg.norm(n); return (n/l if l>0 else n), q
tot=0
for dn,s in (('part_door_l',1),('part_door_r',-1)):
    df=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    P=V[[c[0] for f in df for c in f[2]]]
    xo=np.percentile(np.abs(P[:,0]),90)
    z0,y0=P[:,2].min()-0.1,P[:,1].min()-0.1; nz=int((P[:,2].max()+0.1-z0)/RES)+1; ny=int((P[:,1].max()+0.1-y0)/RES)+1
    cov=np.zeros((nz,ny),bool); hm=np.full((nz,ny),-1.0)
    def put(pts):
        for p in pts:
            i=int((p[2]-z0)/RES); j=int((p[1]-y0)/RES)
            if 0<=i<nz and 0<=j<ny:
                cov[i,j]=True; hm[i,j]=max(hm[i,j],abs(p[0]))
    for f in df:
        n,q=fn(f)
        if n[0]*s<0.4 or np.abs(q[:,0]).mean()<xo-0.15: continue
        # sampel titik di muka (titik sudut + titik tengah + titik tengah sisi)
        m=q.mean(0); pts=list(q)+[m]+[(q[i]+q[(i+1)%len(q)])/2 for i in range(len(q))]+[(q[i]+m)/2 for i in range(len(q))]
        put(pts)
    mask=ndi.binary_closing(cov,structure=np.ones((3,3)),iterations=5)
    mask=ndi.binary_fill_holes(mask)
    mask=ndi.binary_opening(mask,structure=np.ones((3,3)),iterations=2)|cov
    dm=ndi.binary_dilation(mask,iterations=2)
    idx=ndi.distance_transform_edt(hm<0,return_distances=False,return_indices=True)
    H=hm[idx[0],idx[1]]
    mv=0
    for f in o.faces:
        if f[0]!='body' or 'glass' in f[1]: continue
        n,q=fn(f)
        if n[0]*s<0.3: continue
        cen=q.mean(0); i=int((cen[2]-z0)/RES); j=int((cen[1]-y0)/RES)
        if not(0<=i<nz and 0<=j<ny) or not mask[i,j]: continue
        ok=True
        for p in q:
            a=int((p[2]-z0)/RES); b=int((p[1]-y0)/RES)
            if not(0<=a<nz and 0<=b<ny) or not dm[a,b]: ok=False;break
        if not ok: continue
        if abs(cen[0])<H[i,j]-0.05: continue
        f[0]='mark' if tint else dn; mv+=1
    tot+=mv
print('muka kulit pintu yang dikembalikan ke pintu:',tot)
if tint and 'mark' not in o.order: o.order.append('mark')
o.write(sys.argv[2])
