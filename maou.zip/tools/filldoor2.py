"""filldoor2.py in out [tint] - isi kulit pintu pakai cangkang cembung (convex hull) dari kulit pintu yang ada."""
import sys, numpy as np, cv2
from scipy import ndimage as ndi
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
o=Obj(sys.argv[1]); V=o.V; tint=len(sys.argv)>3; RES=0.01; tot=0
def fn(f):
    q=V[[c[0] for c in f[2]]]; n=np.cross(q[1]-q[0],q[2]-q[0]); l=np.linalg.norm(n); return (n/l if l>0 else n),q
for dn,s in (('part_door_l',1),('part_door_r',-1)):
    df=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    P=V[[c[0] for f in df for c in f[2]]]; xo=np.percentile(np.abs(P[:,0]),90)
    z0,y0=P[:,2].min()-0.1,P[:,1].min()-0.1; nz=int((P[:,2].max()+0.1-z0)/RES)+1; ny=int((P[:,1].max()+0.1-y0)/RES)+1
    hm=np.full((nz,ny),-1.0); pts=[]
    for f in df:
        n,q=fn(f)
        if n[0]*s<0.4 or np.abs(q[:,0]).mean()<xo-0.15: continue
        for p in list(q)+[q.mean(0)]:
            a=int((p[2]-z0)/RES); b=int((p[1]-y0)/RES)
            if 0<=a<nz and 0<=b<ny: hm[a,b]=max(hm[a,b],abs(p[0])); pts.append([b,a])
    hull=cv2.convexHull(np.array(pts,np.int32)); mk=np.zeros((nz,ny),np.uint8); cv2.fillConvexPoly(mk,hull,1); mask=mk.astype(bool)
    # potong bagian atas: kulit pintu berhenti di garis pinggang (ambil y maks dari kulit yg ada di tengah pintu)
    idx=ndi.distance_transform_edt(hm<0,return_distances=False,return_indices=True); H=hm[idx[0],idx[1]]
    dm=ndi.binary_dilation(mask,iterations=1); mv=0
    for f in o.faces:
        if f[0]!='body' or 'glass' in f[1]: continue
        n,q=fn(f)
        if n[0]*s<0.3: continue
        c=q.mean(0); i=int((c[2]-z0)/RES); j=int((c[1]-y0)/RES)
        if not(0<=i<nz and 0<=j<ny) or not mask[i,j]: continue
        ok=all(0<=int((p[2]-z0)/RES)<nz and 0<=int((p[1]-y0)/RES)<ny and dm[int((p[2]-z0)/RES),int((p[1]-y0)/RES)] for p in q)
        if not ok or abs(c[0])<H[i,j]-0.05: continue
        f[0]='mark' if tint else dn; mv+=1
    tot+=mv
print('dipindah',tot)
if tint and 'mark' not in o.order: o.order.append('mark')
o.write(sys.argv[2])
