#!/usr/bin/env python3
"""make_carpack.py - bungkus hasil konverter (forza_fbx_to_maou.py) menjadi carpack .zip

Pakai:
  python3 tools/make_carpack.py <folder_hasil_konverter> <id_mobil> "<Nama Mobil>" <namespace> out.zip [engine] [mass]

Contoh:
  python3 tools/make_carpack.py /tmp/out_krc krc_supra "Toyota Supra KRC" krcpack krc_supra.zip supra2jz 1480
Taruh zip hasilnya di  config/maoudrift/carpacks/  lalu jalankan game (atau F3+T). Tidak perlu mengubah mod utama.
"""
import json, os, sys, zipfile, glob

src, cid, title, ns, out = sys.argv[1:6]
engine = sys.argv[6] if len(sys.argv) > 6 else "supra2jz"
mass = float(sys.argv[7]) if len(sys.argv) > 7 else 1500.0
meta = json.load(open(os.path.join(src, cid + ".json")))
A = "assets/%s/" % ns; D = "data/%s/" % ns
files = {}
def add(path, name): files[name] = open(path, "rb").read()
add(os.path.join(src, cid + ".obj"), A + "models/entity/%s.obj" % cid)
add(os.path.join(src, cid + ".mtl"), A + "models/entity/%s.mtl" % cid)
w = open(os.path.join(src, cid + "_wheel.obj")).read().replace("mtllib %s_wheel.mtl" % cid, "mtllib wheel_%s.mtl" % cid)
files[A + "models/entity/wheel_%s.obj" % cid] = w.encode()
add(os.path.join(src, cid + "_wheel.mtl"), A + "models/entity/wheel_%s.mtl" % cid)
mc = b'{"texture":{"blur":true}}'
for f in sorted(glob.glob(os.path.join(src, cid + "*.png"))):
    b = os.path.basename(f)
    if b.startswith(cid + "_wheel"):
        name = "wheel_%s%s" % (cid, b[len(cid + "_wheel"):])
    else:
        name = b
    files[A + "textures/entity/" + name] = open(f, "rb").read()
    if not name.endswith("_s.png"): files[A + "textures/entity/" + name + ".mcmeta"] = mc
paints = meta.get("paints", [])
names = {"white": "White", "black": "Black", "graphite": "Graphite", "silver": "Silver", "red": "Red", "blue": "Blue",
         "orange": "Orange", "yellow": "Yellow", "green": "Green"}
veh = {"shadowRadius": 1.4, "seat": [-0.41, -0.68, 0.52], "designRideHeight": round(meta["wheel_radius"] + 0.182, 4),
       "body": {"model": "%s:models/entity/%s.obj" % (ns, cid), "texture": "%s:textures/entity/%s.png" % (ns, cid)},
       "sounds": {"engine": {"type": engine, "pitch": 1.0, "load": 1.0}, "turbo": {"pitch": 1.0}, "blowoff": {"pitch": 1.0}, "shift": {"pitch": 1.0}},
       "paints": [{"id": p[0], "name": names.get(p[0], p[0]), "texture": "%s:textures/entity/%s_%s.png" % (ns, cid, p[0]), "swatch": p[1]} for p in paints]}
files[A + "vehicles/%s.json" % cid] = json.dumps(veh, indent=2).encode()
files[A + "car_parts/wheel_%s.json" % cid] = json.dumps({"wheel": {"model": "%s:models/entity/wheel_%s.obj" % (ns, cid), "texture": "%s:textures/entity/wheel_%s.png" % (ns, cid)}}, indent=2).encode()
files[D + "cars/%s.json" % cid] = json.dumps({"order": 20, "values": {"mass": mass, "wheel_base": meta["wheel_base"], "front_track_width": meta["track"], "rear_track_width": meta["track"], "wheel_radius": meta["wheel_radius"]},
    "default_parts": {"wheel": {"part": "%s:wheel_%s" % (ns, cid), "removable": True}}}, indent=2).encode()
lang = {"item.%s.%s" % (ns, cid): title, "car.%s.%s" % (ns, cid): title, "entity.%s.%s" % (ns, cid): title, "part.%s.wheel_%s" % (ns, cid): title + " Wheel"}
files[A + "lang/en_us.json"] = json.dumps(lang, indent=2).encode()
files["pack.mcmeta"] = json.dumps({"pack": {"pack_format": 34, "supported_formats": {"min_inclusive": 34, "max_inclusive": 99}, "description": "Maou Drift carpack: " + title}}, indent=2).encode()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for n, b in files.items(): z.writestr(n, b)
print("OK ->", out, "(%d file)" % len(files))
