"""fix_steer.py in.obj out.obj - satukan SEMUA bagian setir (lingkar bawah, jari, tengah) ke grup steering_wheel.
Bagian yang menempel (satu komponen mesh) atau berada di dalam kotak setir dan kecil dipindahkan dari body."""
import sys, collections, numpy as np
from objlib import Obj
def run(src, dst, verbose=True):
    o = Obj(src); V = o.V; key = {}
    pid = np.array([key.setdefault(tuple(p), len(key)) for p in np.round(V, 4)])
    st = [f for f in o.faces if f[0] == "steering_wheel"]
    sv = V[[c[0] for f in st for c in f[2]]]; mn, mx = sv.min(0), sv.max(0); c0 = (mn + mx) / 2; ext = mx - mn
    if verbose: print("setir lama:", len(st), "muka; bbox", mn.round(2), mx.round(2))
    cand = [f for f in o.faces if f[0] == "body"]
    par = {}
    def find(a):
        while par.setdefault(a, a) != a: par[a] = par[par[a]]; a = par[a]
        return a
    for f in cand:
        v = [pid[c[0]] for c in f[2]]
        for a in v[1:]:
            ra, rb = find(v[0]), find(a)
            if ra != rb: par[ra] = rb
    comp = collections.defaultdict(list)
    for f in cand: comp[find(pid[f[2][0][0]])].append(f)
    # kotak setir diperlebar sedikit; poros setir = sumbu terpendek
    lo, hi = mn - 0.04, mx + 0.04
    moved = 0
    for r, fl in comp.items():
        p = V[[c[0] for f in fl for c in f[2]]]; a, b = p.min(0), p.max(0)
        inside = (a >= lo - 1e-6).all() and (b <= hi + 1e-6).all()
        if inside and len(fl) < 3000:
            for f in fl: f[0] = "steering_wheel"
            moved += len(fl)
    if verbose: print("dipindah dari body:", moved)
    o.write(dst); return moved
if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
