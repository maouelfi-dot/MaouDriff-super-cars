"""fixspike.py in.obj out.obj - buang serpihan runcing yang menjulur keluar dari tepi bawah/belakang/depan pintu (di bawah garis spion)."""
import sys, numpy as np
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
o=Obj(sys.argv[1]); V=o.V; tot=0
for dn in ('part_door_l','part_door_r'):
    fs=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    P=V[[c[0] for f in fs for c in f[2]]]
    lo,hi=np.percentile(P,1,axis=0),np.percentile(P,99,axis=0)
    drop=set()
    for f in fs:
        q=V[[c[0] for c in f[2]]]; cen=q.mean(0)
        if cen[1]>1.0: continue
        out=((q[:,2]<lo[2]-0.03)|(q[:,2]>hi[2]+0.03)|(q[:,1]<lo[1]-0.03)).any()
        if out: drop.add(id(f))
    tot+=len(drop); o.faces=[f for f in o.faces if id(f) not in drop]
print('serpihan dibuang:',tot)
o.write(sys.argv[2])
