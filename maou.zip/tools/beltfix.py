import numpy as np
R='core/src/main/resources/assets/maoudrift/models/entity/'
def run(car,nb=28):
    p=R+car+'.obj'; L=open(p).read().rstrip('\n').split('\n')
    V=[];VT=[];nvn=0;g=None;mat=None;faces=[]
    for l in L:
        t=l.split()
        if not t: continue
        if t[0]=='v': V.append([float(x) for x in t[1:4]])
        elif t[0]=='vt': VT.append([float(x) for x in t[1:3]])
        elif t[0]=='vn': nvn+=1
        elif t[0] in('g','o'): g=t[1]
        elif t[0]=='usemtl': mat=t[1]
        elif t[0]=='f': faces.append((g,mat,[tuple(int(y) if y else 0 for y in (x.split('/')+['','',''])[:3]) for x in t[1:]]))
    V=np.array(V); VT=np.array(VT)
    add=[]; VL=[]; TL=[]; nv=len(V); nvt=len(VT); out=[]; newvn=nvn
    for door in ['part_door_l','part_door_r']:
        gl=[f for f in faces if f[0]==door and f[1]=='m_doorglass']
        pn=[f for f in faces if f[0]==door and f[1]!='m_doorglass']
        if not gl or not pn: continue
        gv=sorted({i[0]-1 for f in gl for i in f[2]})
        G=V[gv]; z0,z1=G[:,2].min(),G[:,2].max(); w=(z1-z0)/nb
        sd=1 if G[:,0].mean()>0 else -1
        def edges(fs):
            E=[]
            for f in fs:
                ids=f[2]
                for k in range(len(ids)):
                    a_=ids[k];b_=ids[(k+1)%len(ids)]
                    E.append((a_,b_))
            return E
        EG=edges(gl); EP=edges(pn)
        def cross(E,zc,sel):
            best=None
            for a_,b_ in E:
                pa=V[a_[0]-1];pb=V[b_[0]-1]
                if (pa[2]-zc)*(pb[2]-zc)>0 or abs(pa[2]-pb[2])<1e-7: continue
                t=(zc-pa[2])/(pb[2]-pa[2]); y=pa[1]+t*(pb[1]-pa[1]); x=pa[0]+t*(pb[0]-pa[0])
                if a_[1] and b_[1]:
                    ua=VT[a_[1]-1];ub=VT[b_[1]-1];uv=ua+t*(ub-ua)
                else: uv=None
                if not sel(y): continue
                if best is None or sel.better(y,best[0]): best=(y,x,uv)
            return best
        class Min:
            def __init__(s,lo=-9,hi=9): s.lo=lo;s.hi=hi
            def __call__(s,y): return s.lo<=y<=s.hi
            def better(s,y,b): return y<b
        class Max(Min):
            def better(s,y,b): return y>b
        pts=[]
        for b in range(1,nb):
            zc=z0+b*w
            g_=cross(EG,zc,Min())
            if g_ is None: continue
            p_=cross(EP,zc,Max(g_[0]-0.3,g_[0]+0.004))
            if p_ is None or p_[2] is None: continue
            if g_[0]-p_[0]<0.004: continue
            pts.append((zc,g_,p_))
        if len(pts)<2: continue
        newvn+=2; vnout=newvn-1; vnin=newvn
        add.append('vn %d 0 0'%sd); add.append('vn %d 0 0'%-sd)
        mt=[f[1] for f in pn][0]
        # material of panel face nearest: use most common
        from collections import Counter
        mt=Counter(f[1] for f in pn).most_common(1)[0][0]
        add.append('g '+door); add.append('usemtl '+mt)
        cnt=0
        for (za,ga,pa),(zb,gb,pb) in zip(pts,pts[1:]):
            vs=[(pa[1],pa[0],za),(pb[1],pb[0],zb),(gb[1]*0.5+pb[1]*0.5,gb[0],zb),(ga[1]*0.5+pa[1]*0.5,ga[0],za)]
            i0=nv+len(VL)
            VL.extend('v %.6f %.6f %.6f'%v_ for v_ in vs)
            t0=nvt+len(TL)+1;t1=t0+1
            TL.append('vt %.6f %.6f'%tuple(pa[2]));TL.append('vt %.6f %.6f'%tuple(pb[2]))
            ord_=[0,1,2,3] if sd>0 else [3,2,1,0]
            uvi=[t0,t1,t1,t0]
            add.append('f '+' '.join('%d/%d/%d'%(i0+1+k,uvi[k],vnout) for k in ord_))
            add.append('f '+' '.join('%d/%d/%d'%(i0+1+k,uvi[k],vnin) for k in ord_[::-1]))
            cnt+=1
        print(car,door,'strip quads',cnt)
    open(p,'w').write('\n'.join(L)+'\n'+'\n'.join(VL+TL+add)+'\n')
for c in ['supra','krc_supra','zacoe_m2','varis_gts']: run(c)
