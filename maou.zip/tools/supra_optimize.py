"""Optimasi Supra: buang poligon sebidang (bentuk tidak berubah) + sedikit collapse; UV, material, nama objek dipertahankan."""
import bpy, bmesh, math, sys
SRC, DST = sys.argv[1], sys.argv[2]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.wm.obj_import(filepath=SRC, forward_axis='NEGATIVE_Z', up_axis='Y')
before = after = 0
RATIO = {"body": 0.82, "part_hood": 0.8}
for o in list(bpy.context.scene.objects):
    if o.type != 'MESH': continue
    before += sum(len(p.vertices) - 2 for p in o.data.polygons)
    m = o.modifiers.new("pl", 'DECIMATE'); m.decimate_type = 'DISSOLVE'; m.angle_limit = math.radians(2.2); m.use_dissolve_boundaries = False
    r = RATIO.get(o.name.split(".")[0], 1.0)
    if r < 1.0:
        c = o.modifiers.new("col", 'DECIMATE'); c.decimate_type = 'COLLAPSE'; c.ratio = r
    bpy.context.view_layer.update(); dg = bpy.context.evaluated_depsgraph_get()
    me2 = bpy.data.meshes.new_from_object(o.evaluated_get(dg)); o.modifiers.clear(); o.data = me2
    bm = bmesh.new(); bm.from_mesh(me2)
    for f in bm.faces: f.smooth = True
    for e in bm.edges: e.smooth = not (len(e.link_faces) == 2 and e.calc_face_angle(0) > math.radians(42))
    bm.to_mesh(me2); bm.free()
    after += sum(len(p.vertices) - 2 for p in me2.polygons)
print("TRI", before, "->", after)
bpy.ops.wm.obj_export(filepath=DST, forward_axis='NEGATIVE_Z', up_axis='Y', export_normals=True, export_uv=True, export_materials=True, export_triangulated_mesh=False, export_object_groups=False, export_material_groups=False)
