"""fix_uv_stretch.py in.obj out.obj - perbaiki segitiga stiker/livery yang UV-nya 'ketarik' (melompat ke sisi tile seberang)"""
import sys, itertools, collections, numpy as np
from objlib import Obj
def run(src, dst):
    o = Obj(src); V = o.V; key = {}
    pid = np.array([key.setdefault(tuple(p), len(key)) for p in np.round(V, 4)])
    T = o.T; F = o.faces
    def dens(f):
        vi = o.vidx(f); ti = [c[1] for c in f[2]]
        p = V[vi]; t = np.array([T[i] for i in ti])
        e3 = max(np.linalg.norm(p[i] - p[(i + 1) % 3]) for i in range(3)); eu = max(np.linalg.norm(t[i] - t[(i + 1) % 3]) for i in range(3))
        return eu / max(e3, 1e-5)
    tri = [k for k, f in enumerate(F) if len(f[2]) == 3]
    D = {k: dens(F[k]) for k in tri}
    byv = collections.defaultdict(list)
    for k in tri:
        for v in o.vidx(F[k]): byv[pid[v]].append(k)
    bad = []
    for k in tri:
        nb = {j for v in o.vidx(F[k]) for j in byv[pid[v]] if j != k}
        if len(nb) < 3: continue
        med = np.median([D[j] for j in nb])
        if med > 0 and D[k] > 6 * med: bad.append(k)
    badset = set(bad); fixed = 0
    for k in bad:
        f = F[k]; cand = []
        for c in f[2]:
            cs = {c[1]}
            for j in byv[pid[c[0]]]:
                if j in badset: continue
                for cc in F[j][2]:
                    if pid[cc[0]] == pid[c[0]]: cs.add(cc[1])
            cand.append(list(cs)[:14])
        best = None
        for combo in itertools.product(*cand):
            t = np.array([T[i] for i in combo]); ext = max(np.linalg.norm(t[i] - t[(i + 1) % 3]) for i in range(3))
            if best is None or ext < best[0]: best = (ext, combo)
        for c, ti in zip(f[2], best[1]): c[1] = ti
        fixed += 1
    o.write(dst); return len(F), fixed
if __name__ == "__main__":
    print(run(sys.argv[1], sys.argv[2]))
