"""
forza_fbx_to_maou.py - ubah mobil FBX (rip game, banyak material/tekstur) jadi aset Maou Drift:
badan halus + kaca + lampu + pintu/kap mesin terpisah, SATU atlas tekstur asli (hasil bake per material),
peta labPBR (_s) dari roughness/metallic asli, dan velg terpisah.

    python forza_fbx_to_maou.py <kunci> <folder_keluaran>        # kunci: varis | zacoe | vgts
Butuh:  pip install bpy pillow numpy   (Python 3.11)
Kilap HANYA lewat peta _s (labPBR) -> terlihat mengkilap hanya saat shader PBR aktif. Tidak ada kilap palsu di tekstur warna.
"""
import sys, os, json, math, time
import numpy as np, bpy, bmesh
from PIL import Image
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import maou_car_export as mce
T0 = time.time()
def log(*a): print("[%4.0fs]" % (time.time() - T0), *a, flush=True)

CARS = {
 "varis": dict(fbx="/tmp/cars/varis/source/fm/FINAL_MODEL_Varis.fbx", id="varis_m4", title="Varis M4 Widebody", real_wb=2.812,
               tri_budget=40000, wheel_budget=4400, atlas=2048, paints=True,
               front_hint=(["bumperf", "hood", "headlight", "splitter"], ["bumperr", "spoiler", "diffuser", "roof"])),
 "zacoe": dict(fbx="/tmp/cars/zacoe/source/fm/FINAL_MODEL_ZAC1.fbx", id="zacoe_m2", title="BMW M2 G87 Zacoe", real_wb=2.747,
               tri_budget=38000, wheel_budget=4400, atlas=2048, paints=True,
               front_hint=(["hood0a"], ["wing3a"])),
 "krc": dict(fbx="/home/claude/supra/source/m/FINAL_MODEL_KRC.fbx", id="krc_supra", title="Toyota Supra JZA80 KRC Widebody", real_wb=2.550,
              tri_budget=30000, wheel_budget=3200, atlas=2048, paints=True,
              front_hint=(["hood5a"], ["wing5b"])),
 "vgts": dict(fbx="/tmp/cars/vgts/source/fm/FINAL_MODEL_VGTS.fbx", id="varis_gts", title="Varis M4 GTS", real_wb=2.812,
              tri_budget=42000, wheel_budget=4400, atlas=2048, paints=False, front_hint=([], [])),
}
_a = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else sys.argv[1:]
key, OUT = _a[0], _a[1]
cfg = CARS[key]; ID = cfg["id"]; os.makedirs(OUT, exist_ok=True)
GAME = 1.2
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=cfg["fbx"])
sc = bpy.context.scene
meshes = [o for o in sc.objects if o.type == 'MESH' and len(o.data.polygons) > 0]

def ancestors(o):
    r = []
    while o.parent: o = o.parent; r.append(o.name)
    return r
def is_wheel(o):
    return any(a.startswith("3DWheel") or a == "Armature" for a in ancestors(o))
def mats(o): return [(s.material.name if s.material else "") for s in o.material_slots]
def wpts(o): return np.array([(o.matrix_world @ v.co)[:] for v in o.data.vertices])
SKIP = ("engine", "underlight", "lattice", "calliper", "camera", "licenseplate")
def skipped(o):
    n = o.name.lower(); m = " ".join(mats(o)).lower()
    return any(k in n for k in SKIP) or ("calliper" in m) or ("engine" in m and "interior" not in n)
wheels = [o for o in meshes if is_wheel(o) and not skipped(o)]
body = [o for o in meshes if not is_wheel(o) and not skipped(o) and not any(k in o.name.lower() for k in ("tireblur",))]
log("wheelmesh", len(wheels), "body", len(body))
allp = np.concatenate([wpts(o) for o in body + wheels]); mn, mx = allp.min(0), allp.max(0)
ext = mx - mn; la = int(np.argmax(ext[:2])); sa = 1 - la; ua = 2
# pusat tiap sudut roda
mid = (mn + mx) / 2
corners = {}
for o in wheels:
    c = wpts(o).mean(0); k = (int(c[sa] > mid[sa]), int(c[la] > mid[la]))
    corners.setdefault(k, []).append(o)
log("corners", {k: len(v) for k, v in corners.items()})
assert len(corners) == 4, "roda tidak terdeteksi 4 sudut"
cc = {k: np.concatenate([wpts(o) for o in v]) for k, v in corners.items()}
cen = {k: (p.min(0) + p.max(0)) / 2 for k, p in cc.items()}
# arah depan: dari nama induk roda "Front", atau penanda nama objek
front_len_sign = None
fr = [cen[k][la] for k, v in corners.items() if any("Front" in a for o in v for a in ancestors(o))]
rr = [cen[k][la] for k, v in corners.items() if any("Rear" in a for o in v for a in ancestors(o))]
if fr and rr: front_len_sign = float(np.sign(np.mean(fr) - np.mean(rr)))
else:
    fh, rh = cfg["front_hint"]
    fp = [wpts(o).mean(0)[la] for o in body if any(h in o.name.lower() for h in fh)]
    rp = [wpts(o).mean(0)[la] for o in body if any(h in o.name.lower() for h in rh)]
    front_len_sign = float(np.sign(np.mean(fp) - np.mean(rp)))
axle_mid = np.mean([c[la] for c in cen.values()])
_f = [c[la] for c in cen.values() if (c[la] - axle_mid) * front_len_sign > 0]; _r = [c[la] for c in cen.values() if (c[la] - axle_mid) * front_len_sign <= 0]
wb_world = abs(np.mean(_f) - np.mean(_r))
S = cfg["real_wb"] * GAME / wb_world
log("front_sign", front_len_sign, "world wb", wb_world, "S", S)
M = np.zeros((4, 4)); M[3, 3] = 1
M[0, sa] = S; M[1, la] = -S * front_len_sign; M[2, ua] = S
M[0, 3] = -mid[sa] * S; M[1, 3] = axle_mid * S * front_len_sign; M[2, 3] = -mn[ua] * S
if np.linalg.det(M[:3, :3]) < 0: M[0, sa] *= -1; M[0, 3] *= -1      # kiri = +X (tangan kanan)
from mathutils import Matrix
Mcar = Matrix(M.tolist())

# ------------------------------------------------------------------ setir: pisahkan komponen lepas di sekitar posisi setir
STEER_C = np.array([0.41, -0.105, 0.90])   # pusat setir di ruang mobil (depan -Y, atas Z), dari mobil Supra lain
def split_steering(objs):
    res = []
    for o in objs:
        if "interior" not in o.name.lower():
            res.append(o); continue
        T = np.array(Mcar @ o.matrix_world)
        me0 = o.data; nv = len(me0.vertices)
        co = np.empty(nv * 3, np.float64); me0.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
        cc_ = co @ T[:3, :3].T + T[:3, 3]
        bm = bmesh.new(); bm.from_mesh(me0); bm.faces.ensure_lookup_table()
        seen = set(); sel = set()
        for f0 in bm.faces:
            if f0.index in seen: continue
            comp = []; st = [f0]; seen.add(f0.index)
            while st:
                f = st.pop(); comp.append(f)
                for v in f.verts:
                    for g in v.link_faces:
                        if g.index not in seen: seen.add(g.index); st.append(g)
            vi = sorted({v.index for f in comp for v in f.verts}); pts = cc_[vi]
            mn_, mx_ = pts.min(0), pts.max(0); c_ = (mn_ + mx_) / 2; e_ = mx_ - mn_
            d = c_ - STEER_C
            if abs(d[0]) < 0.12 and abs(d[1]) < 0.13 and abs(d[2]) < 0.13 and e_.max() <= 0.55:
                ring = e_[0] >= 0.28 and e_[2] >= 0.28
                near = np.hypot(d[0], d[2]) < 0.23 and abs(d[1]) < 0.12
                if ring or near:
                    sel.update(f.index for f in comp)
                    log("setir: komponen", len(comp), "poligon", mn_.round(2), mx_.round(2))
        if not sel:
            bm.free(); res.append(o); continue
        bm2 = bm.copy(); bm2.faces.ensure_lookup_table()
        bmesh.ops.delete(bm2, geom=[f for f in bm2.faces if f.index not in sel], context='FACES')
        bmesh.ops.delete(bm, geom=[bm.faces[i] for i in sel], context='FACES')
        mr = bpy.data.meshes.new(o.name + "_rest"); mst = bpy.data.meshes.new(o.name + "_steer")
        for m_ in me0.materials: mr.materials.append(m_); mst.materials.append(m_)
        bm.to_mesh(mr); bm2.to_mesh(mst); bm.free(); bm2.free()
        o.data = mr
        so = bpy.data.objects.new("STEER_" + o.name, mst); so.matrix_world = o.matrix_world; sc.collection.objects.link(so)
        res += [o, so]
        log("setir dipisah:", len(sel), "poligon dari interior")
    return res
body = split_steering(body)

# ------------------------------------------------------------------ reduksi poligon (planar dulu, lalu collapse)
dg = bpy.context.evaluated_depsgraph_get()
def ntri(me): return sum(len(p.vertices) - 2 for p in me.polygons)
def reduce_obj(src, ratio_fn=None):
    """Salin objek ke ruang mobil lalu hilangkan poligon sebidang (tanpa mengubah bentuk)."""
    me = src.data.copy(); me.transform(Mcar @ src.matrix_world)
    ob = bpy.data.objects.new(src.name, me); sc.collection.objects.link(ob)
    m = ob.modifiers.new("pl", 'DECIMATE'); m.decimate_type = 'DISSOLVE'; m.angle_limit = math.radians(2.5); m.use_dissolve_boundaries = False
    bpy.context.view_layer.update(); dgx = bpy.context.evaluated_depsgraph_get()
    return ob, bpy.data.meshes.new_from_object(ob.evaluated_get(dgx))
WEIGHT = [("interior", .30), ("chassis", .22), ("coloured", .35), ("base", .5), ("tint", .5), ("carbon", .8)]
def weight(n):
    n = n.lower()
    for k, w in WEIGHT:
        if k in n: return w
    return 1.0
items = []
for o in body:
    ob, me2 = reduce_obj(o)
    bpy.data.objects.remove(ob)
    items.append([o, me2, ntri(me2), weight(o.name)])
tot0 = sum(i[2] for i in items); log("setelah planar:", tot0, "tri dari", sum(ntri(o.data) for o in body))
lo, hi = 0.02, 1.0
for _ in range(30):
    f = (lo + hi) / 2
    est = sum(it[2] if it[2] < 350 else it[2] * min(1, it[3] * f * 1.0) for it in items)
    if est > cfg["tri_budget"]: hi = f
    else: lo = f
f = lo; log("faktor reduksi", round(f, 3))
new = []
for o, me2, n, w in items:
    r = 0.45 if "steer" in o.name.lower() else (1.0 if n < 350 else min(1.0, max(0.05, w * f)))
    ob = bpy.data.objects.new(o.name + "_r", me2); sc.collection.objects.link(ob)
    if r < 0.97:
        m = ob.modifiers.new("col", 'DECIMATE'); m.decimate_type = 'COLLAPSE'; m.ratio = r; m.use_collapse_triangulate = False
        bpy.context.view_layer.update(); dgx = bpy.context.evaluated_depsgraph_get()
        me3 = bpy.data.meshes.new_from_object(ob.evaluated_get(dgx)); ob.modifiers.clear(); ob.data = me3
    ob.material_slots  # pastikan slot
    new.append((o, ob))
log("mesh body dikurangi")

# ------------------------------------------------------------------ peran per poligon + halus
def role_arrays(src, ob):
    me = ob.data; n = len(me.polygons)
    cen_ = np.empty(n * 3, np.float32); me.polygons.foreach_get("center", cen_); cen_ = cen_.reshape(-1, 3)
    nor = np.empty(n * 3, np.float32); me.polygons.foreach_get("normal", nor); nor = nor.reshape(-1, 3)
    mi = np.empty(n, np.int32); me.polygons.foreach_get("material_index", mi)
    ms = [(s.material.name if s.material else "").lower() for s in ob.material_slots]
    on = src.name.lower(); role = np.zeros(n, np.int32)
    if "steer" in on: return np.full(n, 4, np.int32)
    if "hood5a" in on: return np.full(n, 5, np.int32)          # kap mesin = objek asli, tepi mulus
    if "interior" in on or "seatbelt" in on: return np.full(n, 8, np.int32)   # dalam: dipotong pakai kotak (tidak terlihat)
    for i in range(n):
        m = ms[mi[i]] if mi[i] < len(ms) else ""
        if "red_glass" in m or "lightglass_red" in m: role[i] = 3
        elif "orange_glass" in m or "lightglass_clear" in m: role[i] = 2 if cen_[i, 1] < 0 else 3
        elif any(k in m for k in ("window_material", "glass_window", "glass_slight", "glass_front", "glass_rear")) and "surr" not in m and "mirror" not in m: role[i] = 1
        elif ("light" in on and "geo" in on) or "headlight" in on or "taillight" in on or "light_geo" in on:
            if cen_[i, 1] < -0.9 and nor[i, 1] < -0.25: role[i] = 2
            elif cen_[i, 1] > 0.9 and nor[i, 1] > 0.25: role[i] = 3
    # pintu: ambil potongan (komponen terpisah) asli yang berada di area pintu -> tepi mulus seperti pintu asli
    if all(k not in on for k in ("window", "light", "wing", "grille", "badge", "plate")):
        bm_ = bmesh.new(); bm_.from_mesh(me); bm_.faces.ensure_lookup_table()
        co_ = np.empty(len(me.vertices) * 3, np.float64); me.vertices.foreach_get("co", co_); co_ = co_.reshape(-1, 3)
        seen_ = set()
        for f0 in bm_.faces:
            if f0.index in seen_: continue
            st_ = [f0]; seen_.add(f0.index); fl_ = []
            while st_:
                f_ = st_.pop(); fl_.append(f_.index)
                for v_ in f_.verts:
                    for g_ in v_.link_faces:
                        if g_.index not in seen_: seen_.add(g_.index); st_.append(g_)
            vi_ = sorted({v.index for fi in fl_ for v in bm_.faces[fi].verts}); pp = co_[vi_]
            mn_, mx_ = pp.min(0), pp.max(0); c_ = (mn_ + mx_) / 2
            if abs(c_[0]) < 0.95 and -2.45 <= c_[1] <= -1.0 and 0.68 <= c_[2] <= 1.1 and (mx_[1] - mn_[1]) <= 1.8 and (mx_[2] - mn_[2]) <= 0.45:
                for fi in fl_:
                    if role[fi] == 0: role[fi] = 5      # sisipan karbon / pin kap ikut kap mesin
            elif 0.80 <= abs(c_[0]) <= 1.25 and -0.62 <= c_[1] <= 0.62 and 0.25 <= c_[2] <= 1.5 and (mx_[1] - mn_[1]) <= 1.75:
                for fi in fl_:
                    if role[fi] == 0: role[fi] = 6
        bm_.free()
    return role
for src, ob in new:
    me = ob.data
    uvs = list(me.uv_layers)
    if uvs:
        uvs[0].name = "orig_uv"
        for u in uvs[1:]: me.uv_layers.remove(u)
    role = role_arrays(src, ob)
    at = me.attributes.new("role", 'INT', 'FACE'); at.data.foreach_set("value", role)
    bm = bmesh.new(); bm.from_mesh(me)
    for fc in bm.faces: fc.smooth = True
    for e in bm.edges: e.smooth = not (len(e.link_faces) == 2 and e.calc_face_angle(0) > math.radians(42))
    bm.to_mesh(me); bm.free()
bpy.ops.object.select_all(action='DESELECT')
for _, ob in new: ob.select_set(True)
bpy.context.view_layer.objects.active = new[0][1]
bpy.ops.object.join()
car = bpy.context.view_layer.objects.active; me = car.data
log("joined", len(me.polygons), "poligon,", len(car.material_slots), "material")

# ------------------------------------------------------------------ bake per material (UV asli) -> atlas
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = 1; sc.cycles.use_denoising = False
def find_img(sock, d=0):
    if d > 6: return None
    for l in sock.links:
        n = l.from_node
        if n.type == 'TEX_IMAGE' and n.image: return n.image
        for i in n.inputs:
            if i.is_linked:
                r = find_img(i, d + 1)
                if r: return r
    return None
def mat_img(m):
    pb = next((n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None) if m.node_tree else None
    return find_img(pb.inputs['Base Color']) if pb else None
def size_for(m):
    n = m.name.lower(); img = mat_img(m)
    if img is None: return 16
    s = min(img.size[0], img.size[1]) if img.size[0] else 256
    if "paint" in n or "livery" in n: cap = 1024
    elif "interior" in n: cap = 512
    elif "light" in n: cap = 512
    elif "badge" in n or "grille" in n or "carbon" in n: cap = 256
    else: cap = 256
    return int(min(cap, max(64, 1 << int(math.log2(max(s, 64))))))
slots = [s.material for s in car.material_slots]
sizes = [size_for(m) for m in slots]
me.uv_layers.active = me.uv_layers["orig_uv"]; me.uv_layers["orig_uv"].active_render = True
def bake_pass(kind, tag, **kw):
    imgs = []
    for m, sz in zip(slots, sizes):
        nt = m.node_tree
        for n in [n for n in nt.nodes if n.name.startswith("BAKE_")]: nt.nodes.remove(n)
        img = bpy.data.images.new("%s_%s" % (tag, m.name[-10:]), sz, sz, alpha=False)
        nd = nt.nodes.new('ShaderNodeTexImage'); nd.name = "BAKE_" + tag; nd.image = img; nt.nodes.active = nd; nd.select = True
        imgs.append(img)
    bpy.ops.object.bake(type=kind, margin=6, **kw); log("bake", kind)
    out = []
    for img in imgs:
        a = np.empty(img.size[0] * img.size[1] * 4, np.float32); img.pixels.foreach_get(a); out.append(a.reshape(img.size[1], img.size[0], 4).copy())
        bpy.data.images.remove(img)
    return out
col = bake_pass('DIFFUSE', "col", pass_filter={'COLOR'})
rough = bake_pass('ROUGHNESS', "rgh")
for m in slots:
    nt = m.node_tree; pb = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None); outn = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    if outn is None: continue
    em = nt.nodes.new('ShaderNodeEmission')
    if pb is not None and pb.inputs['Metallic'].links: nt.links.new(pb.inputs['Metallic'].links[0].from_socket, em.inputs['Color'])
    else:
        v = pb.inputs['Metallic'].default_value if pb is not None else 0.0; em.inputs['Color'].default_value = (v, v, v, 1)
    nt.links.new(em.outputs[0], outn.inputs['Surface'])
met = bake_pass('EMIT', "met")
ATL = cfg["atlas"]; W = H = ATL
order = sorted(range(len(slots)), key=lambda i: -sizes[i]); rect = {}
PAD = 4; x, y, rowh = 52, 0, 48
for i in order:
    sz = sizes[i]
    if x + sz + PAD > W: x = 0; y += rowh + PAD; rowh = 0
    rect[i] = (x, y, sz); x += sz + PAD; rowh = max(rowh, sz)
log("atlas tinggi", y + rowh, "/", H); assert y + rowh <= H, "atlas kepenuhan"
H = max(256, 1 << (int(y + rowh) - 1).bit_length()); log("atlas dipangkas ke", W, "x", H)
def rs(a, sz):
    im = Image.fromarray(np.clip(a * 255 + .5, 0, 255).astype(np.uint8)[..., :3]); return np.asarray(im.resize((sz, sz), Image.LANCZOS), np.float32) / 255
A = np.ones((H, W, 3), np.float32); SP = np.zeros((H, W, 4), np.float32); SP[..., 0] = 0.35; SP[..., 1] = 12 / 255; SP[..., 3] = 1
SP[:48, :48, 0] = 0.92; SP[:48, :48, 1] = 14 / 255
paint_idx = [i for i, m in enumerate(slots) if (("carpaint" in m.name.lower() and "trim" not in m.name.lower()) or "paint" in m.name.lower() and "solid" not in m.name.lower() and "trim" not in m.name.lower())]
for i, (x0, y0, sz) in rect.items():
    A[y0:y0 + sz, x0:x0 + sz] = rs(col[i], sz)
    r = rs(rough[i], sz)[..., 0]; mt = rs(met[i], sz)[..., 0]
    SP[y0:y0 + sz, x0:x0 + sz, 0] = np.clip(1 - r, 0, 1); SP[y0:y0 + sz, x0:x0 + sz, 1] = np.where(mt > .5, 1.0, 12 / 255)
def save_png(arr, path): Image.fromarray(np.clip(arr[::-1] * 255 + .5, 0, 255).astype(np.uint8)).save(path, optimize=True)
save_png(np.dstack([A, np.ones((H, W, 1), np.float32)]), "%s/%s.png" % (OUT, ID)); save_png(SP, "%s/%s_s.png" % (OUT, ID))
# varian warna cat (hanya bila cat = warna rata, tanpa livery)
PAINTS = [("white", "#EFEFEC"), ("black", "#0C0C0E"), ("graphite", "#3A3C40"), ("silver", "#A6A9AE"), ("red", "#B3141C"), ("blue", "#1B4DB3"), ("orange", "#E8620C"), ("yellow", "#F0C410"), ("green", "#1D6B3A")]
paint_list = []
if cfg["paints"] and paint_idx:
    for nm, hx in PAINTS:
        rgb = np.array([int(hx[i:i + 2], 16) / 255 for i in (1, 3, 5)], np.float32)
        B = A.copy()
        for i in paint_idx:
            x0, y0, sz = rect[i]; base = A[y0:y0 + sz, x0:x0 + sz].mean((0, 1)) + 1e-4
            B[y0:y0 + sz, x0:x0 + sz] = np.clip(A[y0:y0 + sz, x0:x0 + sz] / base * rgb, 0, 1)
        save_png(np.dstack([B, np.ones((H, W, 1), np.float32)]), "%s/%s_%s.png" % (OUT, ID, nm))
        Image.open("%s/%s_s.png" % (OUT, ID)).save("%s/%s_%s_s.png" % (OUT, ID, nm))
        paint_list.append((nm, hx))
log("atlas + _s disimpan")
# ------------------------------------------------------------------ UV baru
orig = np.empty(len(me.loops) * 2, np.float32); me.uv_layers["orig_uv"].data.foreach_get("uv", orig); orig = orig.reshape(-1, 2)
pm = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("material_index", pm)
ls = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_start", ls)
lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get("loop_total", lt)
roles = np.empty(len(me.polygons), np.int32); me.attributes["role"].data.foreach_get("value", roles)
newuv = np.zeros((len(me.loops), 2), np.float32)
for p in range(len(me.polygons)):
    a, b = ls[p], ls[p] + lt[p]; uv = orig[a:b]
    if roles[p] in (2, 3): newuv[a:b] = (24 / W, 24 / H); continue
    x0, y0, sz = rect[pm[p]]
    fl = np.floor(uv.min(0) + 1e-4); u = np.clip(uv - fl, 0, 1)
    newuv[a:b, 0] = (x0 + 1 + u[:, 0] * (sz - 2)) / W; newuv[a:b, 1] = (y0 + 1 + u[:, 1] * (sz - 2)) / H
# ------------------------------------------------------------------ segitiga per peran -> split_panels -> tulis OBJ
me.calc_loop_triangles()
nl_ = len(me.loops); co = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get("co", co); co = co.reshape(-1, 3)
lv = np.empty(nl_, np.int32); me.loops.foreach_get("vertex_index", lv)
me.calc_normals_split(); cn = np.empty(nl_ * 3, np.float32); me.loops.foreach_get("normal", cn); cn = cn.reshape(-1, 3)
nt_ = len(me.loop_triangles); tl = np.empty(nt_ * 3, np.int32); me.loop_triangles.foreach_get("loops", tl); tl = tl.reshape(-1, 3)
tp = np.empty(nt_, np.int32); me.loop_triangles.foreach_get("polygon_index", tp)
P = co.astype(np.float64)[lv[tl]]; N = cn.astype(np.float64)[tl]; UVt = newuv[tl].astype(np.float64); Rr = roles[tp]
def chunk(nm, sel): return [("m_" + nm, P[sel], N[sel], UVt[sel])]
og = {}
for rid, nm in ((1, "glass_main"), (2, "light_head"), (3, "light_tail"), (4, "steering_wheel")):
    sel = np.nonzero(Rr == rid)[0]
    if len(sel): og[nm] = chunk(nm, sel)
s0, s5, s6, s8 = [np.nonzero(Rr == r)[0] for r in (0, 5, 6, 8)]
ref = {"body": chunk("body", np.concatenate([s0, s5, s6, s8])), "glass_main": og.get("glass_main", [])}
inter = {"body": chunk("body", s8) if len(s8) else [], "glass_main": og.get("glass_main", [])}
sp = mce.split_panels(inter, ref=ref)
og["body"] = (chunk("body", s0) if len(s0) else []) + sp.get("body", [])
if og.get("glass_main"): og["glass_main"] = sp.get("glass_main", [])
sl = s6[P[s6].mean(1)[:, 0] > 0] if len(s6) else s6; sr = s6[P[s6].mean(1)[:, 0] <= 0] if len(s6) else s6
og["part_hood"] = (chunk("body", s5) if len(s5) else []) + sp.get("part_hood", [])
og["part_door_l"] = (chunk("body", sl) if len(sl) else []) + sp.get("part_door_l", [])
og["part_door_r"] = (chunk("body", sr) if len(sr) else []) + sp.get("part_door_r", [])
groups = [(k, v) for k, v in og.items() if v and sum(len(c[1]) for c in v)]
tris, mats_used = mce.write_obj("%s/%s.obj" % (OUT, ID), groups, ID + ".mtl")
mce.write_mtl("%s/%s.mtl" % (OUT, ID), mats_used)
open("%s/%s.mtl" % (OUT, ID), "a").write("")
log("OBJ badan:", tris, "segitiga; objek:", [(k, sum(len(c[1]) for c in v)) for k, v in groups])
# ------------------------------------------------------------------ velg kiri-depan
fcs = {k: (np.array(Mcar) @ np.append(cen[k], 1))[:3] for k in cen}
fl_key = [k for k in fcs if fcs[k][1] < 0 and fcs[k][0] > 0][0]
wobjs = [o for o in corners[fl_key]]
def is_tire(o):
    t = (o.name + " " + " ".join(mats(o))).lower(); return any(k in t for k in ("tire", "tyre", "rubber", "calliper"))
rim_objs = [o for o in wobjs if not is_tire(o)]
log("velg:", [o.name[:24] for o in rim_objs])
wc = Mcar @ __import__("mathutils").Vector(cen[fl_key].tolist())
# gabung objek velg -> satu mesh dalam ruang mobil, kurangi poligon
wnew = []
for o in rim_objs:
    ob, m2 = reduce_obj(o); bpy.data.objects.remove(ob)
    t = ntri(m2); ob2 = bpy.data.objects.new(o.name + "_w", m2); sc.collection.objects.link(ob2)
    wnew.append((ob2, t))
tot = sum(t for _, t in wnew); log("velg tri setelah planar", tot)
for ob2, t in wnew:
    r = min(1.0, cfg["wheel_budget"] / max(tot, 1))
    if r < 0.97:
        m = ob2.modifiers.new("c", 'DECIMATE'); m.decimate_type = 'COLLAPSE'; m.ratio = max(0.05, r)
        bpy.context.view_layer.update(); dgx = bpy.context.evaluated_depsgraph_get()
        m3 = bpy.data.meshes.new_from_object(ob2.evaluated_get(dgx)); ob2.modifiers.clear(); ob2.data = m3
    uvs = list(ob2.data.uv_layers)
    if uvs:
        uvs[0].name = "orig_uv"
        for u in uvs[1:]: ob2.data.uv_layers.remove(u)
    bm = bmesh.new(); bm.from_mesh(ob2.data)
    for fc in bm.faces: fc.smooth = True
    for e in bm.edges: e.smooth = not (len(e.link_faces) == 2 and e.calc_face_angle(0) > math.radians(40))
    bm.to_mesh(ob2.data); bm.free()
bpy.ops.object.select_all(action='DESELECT')
for ob2, _ in wnew: ob2.select_set(True)
bpy.context.view_layer.objects.active = wnew[0][0]
if len(wnew) > 1: bpy.ops.object.join()
wob = bpy.context.view_layer.objects.active; wm = wob.data
# bake velg (UV asli, 1024)
wslots = [s.material for s in wob.material_slots]
wm.uv_layers.active = wm.uv_layers["orig_uv"]; wm.uv_layers["orig_uv"].active_render = True
WS = 512
def wbake(kind, tag, **kw):
    img = bpy.data.images.new("w" + tag, WS, WS, alpha=False)
    for m in wslots:
        nt = m.node_tree
        for n in [n for n in nt.nodes if n.name.startswith("BAKE_")]: nt.nodes.remove(n)
        nd = nt.nodes.new('ShaderNodeTexImage'); nd.name = "BAKE_" + tag; nd.image = img; nt.nodes.active = nd; nd.select = True
    bpy.ops.object.bake(type=kind, margin=8, **kw)
    a = np.empty(WS * WS * 4, np.float32); img.pixels.foreach_get(a); return a.reshape(WS, WS, 4).copy()
wc_col = wbake('DIFFUSE', "c", pass_filter={'COLOR'}); wr = wbake('ROUGHNESS', "r")
for m in wslots:
    nt = m.node_tree; pb = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None); outn = next((n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL'), None)
    em = nt.nodes.new('ShaderNodeEmission')
    if pb is not None and pb.inputs['Metallic'].links: nt.links.new(pb.inputs['Metallic'].links[0].from_socket, em.inputs['Color'])
    else:
        v = pb.inputs['Metallic'].default_value if pb is not None else 0.0; em.inputs['Color'].default_value = (v, v, v, 1)
    nt.links.new(em.outputs[0], outn.inputs['Surface'])
wmet = wbake('EMIT', "m")
wspec = np.zeros((WS, WS, 4), np.float32); wspec[..., 0] = np.clip(1 - wr[..., 0], 0, 1); wspec[..., 1] = np.where(wmet[..., 0] > .5, 1.0, 12 / 255); wspec[..., 3] = 1
Image.fromarray(np.clip(wc_col[::-1, :, :3] * 255 + .5, 0, 255).astype(np.uint8)).save("%s/%s_wheel.png" % (OUT, ID))
Image.fromarray(np.clip(wspec[::-1] * 255 + .5, 0, 255).astype(np.uint8)).save("%s/%s_wheel_s.png" % (OUT, ID))
# geometri velg -> gauge
wm.calc_loop_triangles()
nlw = len(wm.loops); cw = np.empty(len(wm.vertices) * 3, np.float32); wm.vertices.foreach_get("co", cw); cw = cw.reshape(-1, 3)
lvw = np.empty(nlw, np.int32); wm.loops.foreach_get("vertex_index", lvw)
wm.calc_normals_split(); cnw = np.empty(nlw * 3, np.float32); wm.loops.foreach_get("normal", cnw); cnw = cnw.reshape(-1, 3)
ntw = len(wm.loop_triangles); tlw = np.empty(ntw * 3, np.int32); wm.loop_triangles.foreach_get("loops", tlw); tlw = tlw.reshape(-1, 3)
uvw = np.empty(nlw * 2, np.float32); wm.uv_layers["orig_uv"].data.foreach_get("uv", uvw); uvw = uvw.reshape(-1, 2)[tlw].astype(np.float64)
Pw = cw.astype(np.float64)[lvw[tlw]]; Nw = cnw.astype(np.float64)[tlw]
ctr = np.array(wc[:])
cen_t = Pw.mean(1); d = np.linalg.norm((cen_t - ctr)[:, 1:], axis=1)
# jari-jari ban dari bbox sudut roda (ruang mobil)
pc = (np.array(Mcar) @ np.concatenate([cc[fl_key], np.ones((len(cc[fl_key]), 1))], 1).T).T[:, :3]
ext_w = pc.max(0) - pc.min(0); tire_R = float(max(ext_w[1], ext_w[2]) / 2); width_w = float(ext_w[0])
keep = d < tire_R * 0.76   # velg saja; ban dibuat oleh mod
Pw, Nw, uvw = Pw[keep], Nw[keep], uvw[keep]
L = Pw - np.array([(pc[:, 0].min() + pc[:, 0].max()) / 2, ctr[1], ctr[2]])
Rr_ = np.linalg.norm(L.reshape(-1, 3)[:, 1:], axis=1); R_rim = float(np.percentile(Rr_, 99.5))
Wr = float(L.reshape(-1, 3)[:, 0].max() - L.reshape(-1, 3)[:, 0].min())
sr = mce.GAUGE_RIM_R / R_rim; sa_ = float(np.clip(mce.GAUGE_RIM_W / max(Wr, 1e-6), 0.8 * sr, 1.6 * sr))
Q = L.copy(); Q[..., 0] *= sa_; Q[..., 1] *= sr; Q[..., 2] *= sr
Qn = Nw.copy(); Qn[..., 0] /= sa_; Qn[..., 1] /= sr; Qn[..., 2] /= sr; Qn /= np.maximum(np.linalg.norm(Qn, axis=-1, keepdims=True), 1e-12)
uv_final = uvw.copy()
tw, _ = mce.write_obj("%s/%s_wheel.obj" % (OUT, ID), [("rim", [("m_rim", Q, Qn, uv_final)])], ID + "_wheel.mtl")
mce.write_mtl("%s/%s_wheel.mtl" % (OUT, ID), ["m_rim"])
log("velg tri", tw, "R_rim", R_rim, "tire_R", tire_R)
# ------------------------------------------------------------------ metrik
xs = [abs(v[0]) for v in fcs.values()]; ys = sorted(v[1] for v in fcs.values())
wheel_base = (np.mean(ys[2:]) - np.mean(ys[:2])); track = 2 * float(np.mean(xs))
height = float(allp[:, ua].max() - mn[ua]) * S
meta = dict(id=ID, title=cfg["title"], wheel_base=round(float(wheel_base), 4), track=round(track, 4), wheel_radius=round(tire_R, 4),
            height=round(height, 3), body_tris=int(tris), wheel_tris=int(tw), paints=paint_list, lights=[k for k, _ in groups if k.startswith("light")])
json.dump(meta, open("%s/%s.json" % (OUT, ID), "w"), indent=1)
log("SELESAI", meta)
