"""Interior prosedural (kursi, dasbor, lantai, sangkar, STIR) untuk mobil yang modelnya kosong di dalam.
Koordinat = koordinat 'to_car' di exporter: X kiri +, Y belakang + (depan = -Y), Z atas, meter (skala game)."""
import math
import numpy as np


def _tris(P, N):
    return np.asarray(P, np.float32).reshape(-1, 3, 3), np.asarray(N, np.float32).reshape(-1, 3, 3)


def _basis(a):
    a = np.asarray(a, float); a = a / np.linalg.norm(a)
    t = np.array([1.0, 0, 0]) if abs(a[0]) < 0.9 else np.array([0, 1.0, 0])
    u = np.cross(a, t); u /= np.linalg.norm(u)
    v = np.cross(a, u)
    return u, v, a


def box(c, size, rot_x_deg=0.0):
    sx, sy, sz = [s / 2 for s in size]
    corners = np.array([[x, y, z] for x in (-sx, sx) for y in (-sy, sy) for z in (-sz, sz)], float)
    th = math.radians(rot_x_deg)
    R = np.array([[1, 0, 0], [0, math.cos(th), -math.sin(th)], [0, math.sin(th), math.cos(th)]])
    faces = [([0, 1, 3, 2], (-1, 0, 0)), ([4, 6, 7, 5], (1, 0, 0)), ([0, 4, 5, 1], (0, -1, 0)),
             ([2, 3, 7, 6], (0, 1, 0)), ([0, 2, 6, 4], (0, 0, -1)), ([1, 5, 7, 3], (0, 0, 1))]
    P, N = [], []
    for idx, n in faces:
        q = [R @ corners[i] + c for i in idx]
        nn = R @ np.array(n, float)
        P += [q[0], q[1], q[2], q[0], q[2], q[3]]
        N += [nn] * 6
    return _tris(P, N)


def tube(p0, p1, r, seg=8):
    p0 = np.asarray(p0, float); p1 = np.asarray(p1, float)
    u, v, a = _basis(p1 - p0)
    P, N = [], []
    for i in range(seg):
        a0 = 2 * math.pi * i / seg; a1 = 2 * math.pi * (i + 1) / seg
        d0 = math.cos(a0) * u + math.sin(a0) * v; d1 = math.cos(a1) * u + math.sin(a1) * v
        q = [p0 + r * d0, p0 + r * d1, p1 + r * d1, p1 + r * d0]
        P += [q[0], q[1], q[2], q[0], q[2], q[3]]
        N += [d0, d1, d1, d0, d1, d0]
    return _tris(P, N)


def torus(c, axis, R, r, seg1=24, seg2=8):
    u, v, a = _basis(axis)
    c = np.asarray(c, float)
    def pt(i, j):
        t = 2 * math.pi * i / seg1; s = 2 * math.pi * j / seg2
        d = math.cos(t) * u + math.sin(t) * v
        n = math.cos(s) * d + math.sin(s) * a
        return c + R * d + r * n, n
    P, N = [], []
    for i in range(seg1):
        for j in range(seg2):
            q = [pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1)]
            for k in (0, 1, 2, 0, 2, 3):
                P.append(q[k][0]); N.append(q[k][1])
    return _tris(P, N)


def disc(c, axis, r, thick, seg=16):
    c = np.asarray(c, float); u, v, a = _basis(axis)
    p0 = c - a * thick / 2; p1 = c + a * thick / 2
    P, N = tube(p0, p1, r, seg)
    P2, N2 = [], []
    for i in range(seg):
        a0 = 2 * math.pi * i / seg; a1 = 2 * math.pi * (i + 1) / seg
        d0 = math.cos(a0) * u + math.sin(a0) * v; d1 = math.cos(a1) * u + math.sin(a1) * v
        for ctr, nrm in ((p1, a), (p0, -a)):
            P2 += [ctr, ctr + r * d0, ctr + r * d1]; N2 += [nrm] * 3
    return np.concatenate([P, _tris(P2, N2)[0]]), np.concatenate([N, _tris(P2, N2)[1]])


def cat(parts):
    return np.concatenate([p[0] for p in parts]), np.concatenate([p[1] for p in parts])


def steering_wheel(center, tilt_deg=18.0, R=0.175):
    """Stir: cincin + hub + 3 jari-jari + penanda merah jam 12. Sumbu menghadap pengemudi (belakang & atas)."""
    th = math.radians(tilt_deg)
    a = np.array([0.0, math.cos(th), math.sin(th)])
    u, v, _ = _basis(a)
    # v adalah arah "atas" di bidang stir? pilih atas = komponen z terbesar
    up = u if abs(u[2]) > abs(v[2]) else v
    if up[2] < 0: up = -up
    side = np.cross(a, up)
    c = np.asarray(center, float)
    parts = [torus(c, a, R, 0.018)]
    parts.append(disc(c + a * 0.01, a, 0.05, 0.05))
    for d in (side, -side, -up):
        p0 = c + d * 0.04; p1 = c + d * (R - 0.01)
        mid = (p0 + p1) / 2
        parts.append(tube(p0 + a * 0.0, p1, 0.013, 6))
    return cat(parts), (c + up * R, a, up)


def red_marker(center, a, up, R):
    c = np.asarray(center, float) + up * R
    u, v, _ = _basis(a)
    return tube(c - up * 0.0 - np.cross(a, up) * 0.025, c + np.cross(a, up) * 0.025, 0.021, 6)


def seat(x, y, floor_z, trim=False):
    """Kursi bucket: dudukan + sandaran miring + sandaran kepala + bantalan samping."""
    parts = [box((x, y, floor_z + 0.14), (0.46, 0.50, 0.12)),
             box((x, y + 0.22, floor_z + 0.42), (0.46, 0.10, 0.62), rot_x_deg=-12),
             box((x, y + 0.27, floor_z + 0.80), (0.28, 0.09, 0.20), rot_x_deg=-12),
             box((x - 0.21, y + 0.18, floor_z + 0.36), (0.07, 0.16, 0.50), rot_x_deg=-12),
             box((x + 0.21, y + 0.18, floor_z + 0.36), (0.07, 0.16, 0.50), rot_x_deg=-12)]
    return cat(parts)


def interior(key):
    """Kembalikan dict: nama grup -> daftar (kind, P, N). 'steering_wheel' dipisah supaya bisa berputar."""
    if key == "m3":
        wc = (0.40, -0.55, 0.88); fl = 0.20; y0, y1 = -1.02, 1.55; hw = 0.84; full = True
    else:  # m4
        wc = (0.40, -0.62, 0.90); fl = 0.22; y0, y1 = -1.05, 1.50; hw = 0.80; full = False
    out = {"body": [], "steering_wheel": []}
    # lantai
    out["body"].append(("plastic", *box((0, (y0 + y1) / 2, fl), (2 * hw, y1 - y0, 0.03))))
    # kursi (pengemudi kiri +X, penumpang kanan -X); y = pusat dudukan
    sy = wc[1] + 0.72
    for sx in (wc[0], -wc[0]):
        out["body"].append(("fabric", *seat(sx, sy, fl)))
        out["body"].append(("trim", *box((sx, sy + 0.05, fl + 0.152), (0.40, 0.42, 0.015))))
    if full:
        # dasbor + panel instrumen + konsol tengah + panel pintu + sangkar keselamatan
        out["body"].append(("fabric", *box((0, y0 + 0.19, 0.85), (2 * hw, 0.36, 0.30))))
        out["body"].append(("fabric", *box((wc[0], wc[1] - 0.22, 0.86), (0.30, 0.10, 0.12), rot_x_deg=-20)))
        out["body"].append(("fabric", *box((0, 0.1, fl + 0.24), (0.24, 2.1, 0.40))))
        for sx in (hw, -hw):
            out["body"].append(("fabric", *box((sx, 0.2, 0.62), (0.04, 2.0, 0.60))))
        cage = []
        for sx in (0.80, -0.80):
            cage.append(tube((sx, 0.55, fl + 0.05), (sx, 0.55, 1.20), 0.025))
            cage.append(tube((sx, 0.55, 1.20), (sx, -0.95, 1.20), 0.025))
            cage.append(tube((sx, -0.95, 1.20), (sx, -0.95, 0.95), 0.025))
            cage.append(tube((sx, -0.20, 1.20), (sx, -0.20, 0.75), 0.022))
        cage.append(tube((0.80, 0.55, 1.20), (-0.80, 0.55, 1.20), 0.025))
        cage.append(tube((0.80, -0.95, 1.20), (-0.80, -0.95, 1.20), 0.025))
        out["body"].append(("cage", *cat(cage)))
    (sw_P, sw_N), (top, a, up) = steering_wheel(wc)
    out["steering_wheel"].append(("leather", sw_P, sw_N))
    out["steering_wheel"].append(("marker", *red_marker(wc, a, up, 0.175)))
    return out, wc
