"""trimdoor.py in out - rapikan tepi pintu: buang serpihan/gigi yang menjulur keluar dari bentuk pintu yang mulus (spion & gagang dikecualikan)."""
import sys, numpy as np
from scipy import ndimage as ndi
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
o=Obj(sys.argv[1]); V=o.V; RES=0.01; tot=0
for dn,s in (('part_door_l',1),('part_door_r',-1)):
    df=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    P=V[[c[0] for f in df for c in f[2]]]; xo=np.percentile(np.abs(P[:,0]),90); xmax=np.percentile(np.abs(P[:,0]),99.5)
    z0,y0=P[:,2].min()-0.1,P[:,1].min()-0.1; nz=int((P[:,2].max()+0.1-z0)/RES)+1; ny=int((P[:,1].max()+0.1-y0)/RES)+1
    cov=np.zeros((nz,ny),bool)
    def cell(p): return int((p[2]-z0)/RES),int((p[1]-y0)/RES)
    for f in df:
        q=V[[c[0] for c in f[2]]]; n=np.cross(q[1]-q[0],q[2]-q[0]); l=np.linalg.norm(n)
        if l==0 or (n/l)[0]*s<0.4 or np.abs(q[:,0]).mean()<xo-0.15: continue
        m=q.mean(0)
        for p in list(q)+[m]+[(q[i]+q[(i+1)%3])/2 for i in range(3)]+[(q[i]+m)/2 for i in range(3)]:
            a,b=cell(p)
            if 0<=a<nz and 0<=b<ny: cov[a,b]=True
    mask=ndi.binary_fill_holes(ndi.binary_closing(cov,structure=np.ones((3,3)),iterations=5))
    core=ndi.binary_opening(mask,structure=np.ones((3,3)),iterations=7)
    keep=ndi.binary_dilation(core,iterations=3)
    drop=set()
    for f in df:
        q=V[[c[0] for c in f[2]]]
        if (np.abs(q[:,0])>xmax+0.03).any(): continue
        for p in q:
            a,b=cell(p)
            if not(0<=a<nz and 0<=b<ny) or not keep[a,b]: drop.add(id(f)); break
    tot+=len(drop); o.faces=[f for f in o.faces if id(f) not in drop]
print('serpihan tepi dibuang:',tot)
o.write(sys.argv[2])
