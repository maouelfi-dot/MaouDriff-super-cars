#!/usr/bin/env python3
"""
awc_to_engine.py - ubah paket suara mesin GTA V (.awc) jadi loop mesin Maou Drift.

Keluaran per mesin: engine_<tipe>_<rpm>_<lift|load>.ogg  (rpm = 900,1600,2800,4500,7000),
mono 48 kHz, 1,2 detik, bisa di-loop mulus. Ini format yang sama dengan loop mesin bawaan mod
(lihat EngineTypes.ENGINE_BANDS).

Cara kerja:
  1. baca AWC (ADAT): stream PCM16, ambil sapuan rev "accel" (03ab9171) dan "decel" (0e804842)
  2. lacak frekuensi penyalaan (rpm = f * 20 untuk mesin 6 silinder) sepanjang sapuan
  3. untuk tiap pita rpm: ambil potongan sapuan, "ratakan" nadanya ke frekuensi pita (warp waktu),
     lalu crossfade ujung ke pangkal supaya loop-nya mulus
  4. samakan loudness dengan loop bawaan, simpan sebagai ogg vorbis

Pakai:  python3 awc_to_engine.py <file.awc> <tipe> <folder_keluar> [--decel 0e804842|none]
Butuh: numpy, scipy, ffmpeg (libvorbis).
"""
import sys, os, struct, subprocess, argparse
import numpy as np
from scipy.signal import butter, sosfiltfilt, resample_poly, savgol_filter

BANDS = [900, 1600, 2800, 4500, 7000]
CYL_FIRE_DIV = 20.0          # 6 silinder 4 tak: f_nyala = rpm / 20
OUT_SR = 48000
LOOP_S = 1.2
XF_S = 0.14
SLACK_S = 0.25
PAD_S = 0.06
TARGET_RMS = {900: 0.27, 1600: 0.29, 2800: 0.30, 4500: 0.27, 7000: 0.22}
ACCEL, DECEL = 0x03ab9171, 0x0e804842

# ---------- AWC ----------
def read_awc(path):
    b = open(path, 'rb').read()
    magic, ver, flags, count, doff = struct.unpack_from('<4sHHII', b, 0)
    assert magic == b'ADAT', 'bukan AWC'
    p = 16
    idx = None
    if (flags >> 8) == 0xFF:
        idx = struct.unpack_from('<%dH' % count, b, p); p += 2 * count
    infos = struct.unpack_from('<%dI' % count, b, p); p += 4 * count
    out = {}
    for i, inf in enumerate(infos):
        sid = inf & 0x1FFFFFFF; cc = inf >> 29
        ch = {}
        for c in range(cc):
            v, = struct.unpack_from('<Q', b, p + 8 * (idx[i] + c))
            tag = v >> 56; size = (v >> 28) & 0xFFFFFFF; off = v & 0xFFFFFFF
            ch[tag] = b[off:off + size]
        if 0xFA in ch and 0x55 in ch:
            samples, loop, sr, head, lb, le, pe, pb, codec = struct.unpack_from('<IiHhHHHBB', ch[0xFA], 0)
            if codec == 0:
                out[sid] = (np.frombuffer(ch[0x55], '<i2').astype(np.float64) / 32768.0, sr)
    return out

# ---------- pelacak f0 ----------
def track_f0(x, sr, direction, win=0.3, hop=0.05, fmin=30, fmax=420, K=10, lam=40.0, against=400.0):
    n = int(win * sr); N = (1 << int(np.ceil(np.log2(n)))) * 4
    fr = np.fft.rfftfreq(N, 1 / sr)
    cands = np.exp(np.linspace(np.log(fmin), np.log(fmax), 420)); ks = np.arange(1, K + 1)
    ts = np.arange(0, len(x) / sr - win, hop); S = np.zeros((len(ts), len(cands)))
    for i, t in enumerate(ts):
        s = x[int(t * sr):int(t * sr) + n]; s = s * np.hanning(len(s))
        sp = np.log10(np.abs(np.fft.rfft(s, N)) + 1e-6)
        hi = np.interp(np.outer(cands, ks), fr, sp); lo = np.interp(np.outer(cands, ks - 0.5), fr, sp)
        S[i] = np.mean(hi - lo, axis=1)
    lc = np.log(cands); ch = lc[:, None] - lc[None, :]
    sgn = 1 if direction == 'up' else -1
    T = -lam * np.abs(ch) - against * np.maximum(0, -sgn * ch)
    dp = S[0].copy(); bp = np.zeros((len(ts), len(cands)), int)
    for i in range(1, len(ts)):
        m = dp[None, :] + T; bp[i] = np.argmax(m, axis=1); dp = S[i] + np.max(m, axis=1)
    path = [int(np.argmax(dp))]
    for i in range(len(ts) - 1, 0, -1): path.append(bp[i][path[-1]])
    f = cands[path[::-1]]
    if len(f) > 15: f = savgol_filter(f, 15, 2)
    return ts + win / 2, f

# ---------- pembuat loop ----------
def burst_score(hf_env, t0, t1, hop):
    seg = hf_env[int(t0 / hop):int(t1 / hop)]
    if len(seg) < 3: return 9.0
    return float(seg.max() / (np.median(hf_env) + 1e-9))

def make_loop(x, sr, t, f, direction, f_target, hf_env, hop_env):
    fmin, fmax = f.min(), f.max()
    # waktu sumber saat f == f_target (di luar jangkauan: ujung terdekat)
    order = np.argsort(f); tc0 = float(np.interp(np.clip(f_target, fmin * 1.0001, fmax * 0.9999), f[order], t[order]))
    need_out = LOOP_S + XF_S + SLACK_S + 2 * PAD_S
    # oversample sumber + lowpass untuk geser nada ke atas
    ratio_max = max(1.0, f_target / fmin)
    hi_sr = 192000
    from math import gcd
    g = gcd(hi_sr, int(sr)); y = resample_poly(x, hi_sr // g, int(sr) // g)
    cutoff = min(0.46 * OUT_SR, 0.46 * OUT_SR) / max(1.0, f_target / max(fmin, 1e-6) if f_target > fmax else 1.0)
    cutoff = min(cutoff, 0.46 * OUT_SR)
    sos = butter(6, cutoff, btype='low', fs=hi_sr, output='sos'); y = sosfiltfilt(sos, y)

    def fsrc(ts): return np.interp(min(ts, t[-1]), t, f)
    tend = len(x) / sr - 0.03

    def simulate(t0, dur_out, step=0.002):
        ts = t0
        for _ in range(int(dur_out / step)):
            ts += (f_target / fsrc(ts)) * step
            if ts > tend: return None
        return ts
    best = None
    for tc in np.linspace(t[0], t[-1], 70):
        sp = need_out * (f_target / fsrc(tc))
        t0 = tc - sp / 2
        if t0 < 0.03: continue
        t1 = simulate(t0, need_out)
        if t1 is None: continue
        tm = 0.5 * (t0 + t1)
        # jangan geser nada jauh dari aslinya kalau ada pilihan lain; hindari letupan (pop) di potongan
        dev = abs(np.log(fsrc(tm) / f_target))
        sc = burst_score(hf_env, t0, t1, hop_env) + 4.0 * dev + 0.2 * abs(tc - tc0)
        if best is None or sc < best[0]: best = (sc, t0)
    if best is None:
        raise RuntimeError('tidak ada potongan sumber yang cukup panjang')
    ts = best[1]
    pos = np.empty(int(need_out * OUT_SR))
    for n in range(len(pos)):
        pos[n] = ts
        ts += (f_target / fsrc(ts)) / OUT_SR
    idx = pos * hi_sr; idx = np.clip(idx, 0, len(y) - 2)
    i0 = idx.astype(int); fr_ = idx - i0
    seg = y[i0] * (1 - fr_) + y[i0 + 1] * fr_
    seg -= np.mean(seg)
    # loop: cari awal (m) dan panjang (L2) terbaik supaya ujung menyambung ke pangkal dengan fase sama.
    # Panjang boleh meleset sedikit dari 1,2 detik (mod tidak bergantung pada panjang), tapi fase harus pas.
    from scipy.signal import correlate
    L = int(LOOP_S * OUT_SR); X = int(XF_S * OUT_SR); M = int(SLACK_S * OUT_SR); D = int(PAD_S * OUT_SR)
    lp = sosfiltfilt(butter(4, 1500, 'low', fs=OUT_SR, output='sos'), seg)
    bestm, bestL, bestc = 0, L, -2.0
    for m in range(0, M, 16):
        head = lp[m:m + X]
        lo = m + L - D; hi = m + L + D + X
        if hi > len(lp): continue
        win_ = lp[lo:hi]
        cc = correlate(win_, head, mode='valid', method='fft')
        # normalisasi per posisi
        e = np.sqrt(np.convolve(win_ ** 2, np.ones(X), 'valid') + 1e-12) * np.linalg.norm(head)
        cc = cc / (e + 1e-12)
        j = int(np.argmax(cc))
        if cc[j] > bestc: bestc, bestm, bestL = float(cc[j]), m, L - D + j
    L2 = bestL
    s = seg[bestm:bestm + L2 + X]
    w = np.linspace(0, 1, X)
    w = 0.5 - 0.5 * np.cos(np.pi * w)
    loop = s[:L2].copy()
    loop[:X] = s[:X] * w + s[L2:L2 + X] * (1 - w)
    # crossfade yang fasenya tidak sama membuat suara sedikit "turun" di sambungan: ratakan lagi lewat
    # selubung RMS (target = RMS bagian yang tidak di-crossfade)
    k = int(0.02 * OUT_SR)
    tri = np.tile(loop, 3)
    env = np.sqrt(np.convolve(tri ** 2, np.ones(k) / k, 'same') + 1e-12)[len(loop):2 * len(loop)]
    ref = float(np.sqrt(np.mean(loop ** 2)))
    g = np.clip(ref / env, 0.6, 2.5)
    g = np.convolve(np.tile(g, 3), np.ones(k) / k, 'same')[len(loop):2 * len(loop)]
    # hanya pakai koreksi di dekat sambungan (awal & akhir), supaya bagian lain tidak diubah
    wgt = np.zeros(len(loop)); edge = X + k
    wgt[:edge] = 1.0; wgt[-k:] = 1.0
    wgt = np.convolve(wgt, np.ones(k) / k, 'same')
    loop = loop * (1 + (g - 1) * wgt)
    return loop, bestc

def derive_lift(load, sr=OUT_SR):
    sos = butter(2, 2500, btype='low', fs=sr, output='sos')
    return 0.55 * load + 0.45 * sosfiltfilt(sos, load)

def normalize(y, rms_target):
    y = y - np.mean(y)
    for _ in range(3):
        r = np.sqrt(np.mean(y ** 2)); y = y * (rms_target / (r + 1e-12))
        pk = np.abs(y).max()
        if pk > 0.85: y = 0.85 * np.tanh(y / 0.85)        # pembatas halus, gain kecil tetap 1
    return y

def write_ogg(y, path):
    pcm = (np.clip(y, -1, 1) * 32767).astype('<i2').tobytes()
    subprocess.run(['ffmpeg', '-y', '-v', 'error', '-f', 's16le', '-ar', str(OUT_SR), '-ac', '1', '-i', '-',
                    '-c:a', 'libvorbis', '-q:a', '5', path], input=pcm, check=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('awc'); ap.add_argument('type'); ap.add_argument('outdir')
    ap.add_argument('--decel', default='0e804842'); ap.add_argument('--accel', default='03ab9171')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    streams = read_awc(a.awc)
    def prep(sid, direction):
        x, sr = streams[int(sid, 16)]
        t, f = track_f0(x, sr, direction)
        hp = sosfiltfilt(butter(4, 3000, 'high', fs=sr, output='sos'), x)
        hop = 0.01; k = int(hop * sr)
        env = np.sqrt(np.convolve(hp ** 2, np.ones(k) / k, 'same'))[::k]
        return x, sr, t, f, env, hop
    A = prep(a.accel, 'up')
    D = prep(a.decel, 'down') if a.decel != 'none' else None
    print('accel f: %.0f..%.0f Hz (rpm %.0f..%.0f)' % (A[3].min(), A[3].max(), A[3].min() * 20, A[3].max() * 20))
    if D: print('decel f: %.0f..%.0f Hz' % (D[3].min(), D[3].max()))
    for rpm in BANDS:
        ft = rpm / CYL_FIRE_DIV
        load, c1 = make_loop(A[0], A[1], A[2], A[3], 'up', ft, A[4], A[5])
        lift = None; from_decel = False
        if D and 0.8 * D[3].min() <= ft <= 1.5 * D[3].max():
            lift, c2 = make_loop(D[0], D[1], D[2], D[3], 'down', ft, D[4], D[5]); from_decel = True
        else:
            lift = derive_lift(load)
        tr = TARGET_RMS[rpm]
        write_ogg(normalize(load, tr), f'{a.outdir}/engine_{a.type}_{rpm}_load.ogg')
        write_ogg(normalize(lift, tr), f'{a.outdir}/engine_{a.type}_{rpm}_lift.ogg')
        print(rpm, 'ok  corr_load=%.2f %s' % (c1, '(lift dari decel, corr %.2f)' % c2 if from_decel else '(lift turunan)'))

if __name__ == '__main__':
    main()
