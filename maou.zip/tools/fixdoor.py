"""fixdoor.py in.obj out.obj [mark]
Muka 'body' yang terletak di kulit luar pintu (centroid di dalam kotak pintu, x di lapisan luar, semua titik di dalam kotak) -> ikut pintu.
Muka sebagian di luar kotak dibiarkan. 'mark' = tandai jadi grup merah untuk render cek."""
import sys, numpy as np
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
o=Obj(sys.argv[1]); V=o.V; mark=len(sys.argv)>3
tot=0
for dn,s in (('part_door_l',1),('part_door_r',-1)):
    df=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    P=V[[c[0] for f in df for c in f[2]]]
    lo,hi=np.percentile(P,1,axis=0),np.percentile(P,99,axis=0)
    xo=np.percentile(np.abs(P[:,0]),90)
    for f in o.faces:
        if f[0]!='body' or 'glass' in f[1]: continue
        q=V[[c[0] for c in f[2]]]; cen=q.mean(0)
        if not (lo[2]<=cen[2]<=hi[2] and lo[1]<=cen[1]<=hi[1]): continue
        if cen[0]*s<xo-0.03: continue
        if ((q[:,2]>=lo[2]-0.02)&(q[:,2]<=hi[2]+0.02)&(q[:,1]>=lo[1]-0.02)&(q[:,1]<=hi[1]+0.02)).all():
            f[0]='mark' if mark else dn; tot+=1
print('dipindah ke pintu:',tot)
if mark and 'mark' not in o.order: o.order.append('mark')
o.write(sys.argv[2])
