"""smooth_hood.py in.obj out.obj - potong ulang tepi kap dengan garis lurus (clipping segitiga), bukan mengikuti sisi segitiga.
Garis potong = cangkang cembung (tampak atas) dari kulit atas kap. Segitiga kulit atas di dalam cangkang -> kap; di luar -> badan."""
import sys, numpy as np
from objlib import Obj
o = Obj(sys.argv[1]); V = o.V
def tri(f): return V[[c[0] for c in f[2]]]
def normal_y(p):
    n = np.cross(p[1] - p[0], p[2] - p[0]); l = np.linalg.norm(n); return n[1] / l if l > 1e-12 else 0.0
hood = [f for f in o.faces if f[0] == "part_hood" and len(f[2]) == 3 and "glass" not in f[1]]
top = [f for f in hood if abs(normal_y(tri(f))) > 0.35 and V[[c[0] for c in f[2]]][:, 1].mean() > 0.0]
# arah "atas" = sisi yang lebih banyak menghadap +y (normal model bisa terbalik)
sgn = np.sign(np.median([normal_y(tri(f)) for f in top])) or 1.0
top = [f for f in top if normal_y(tri(f)) * sgn > 0.35]
pts = V[[c[0] for f in top for c in f[2]]]; yband = np.percentile(pts[:, 1], 4) - 0.03
P = np.unique(np.round(pts[:, [0, 2]], 4), axis=0)
def hull(P):
    P = sorted(map(tuple, P)); 
    def cr(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lo = []; 
    for p in P:
        while len(lo) >= 2 and cr(lo[-2], lo[-1], p) <= 0: lo.pop()
        lo.append(p)
    up = []
    for p in reversed(P):
        while len(up) >= 2 and cr(up[-2], up[-1], p) <= 0: up.pop()
        up.append(p)
    return np.array(lo[:-1] + up[:-1])
H = hull(P); print("garis potong kap: %d titik, y-batas %.3f" % (len(H), yband))
# tepi cangkang (CCW): bagian dalam = kiri tiap tepi
edges = [(H[i], H[(i + 1) % len(H)]) for i in range(len(H))]
liner = [f for f in hood if normal_y(tri(f)) * sgn < -0.35]
if liner:
    ly = np.array([V[[c[0] for c in f[2]]][:, 1].mean() for f in liner]); yL = (np.percentile(ly, 3) - 0.02, np.percentile(ly, 97) + 0.03)
else:
    yL = None
print("liner kap:", len(liner), "rentang y", None if yL is None else tuple(round(x, 3) for x in yL))
def side(p, a, b): return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])   # >0 = dalam
class Vert:
    __slots__ = ("p", "t", "n")
    def __init__(s, p, t, n): s.p, s.t, s.n = np.array(p, float), np.array(t, float), np.array(n, float)
def lerp(a, b, k): return Vert(a.p + (b.p - a.p) * k, a.t + (b.t - a.t) * k, a.n + (b.n - a.n) * k)
def clip_half(poly, a, b, keep_inside):
    out = []
    for i in range(len(poly)):
        u, w = poly[i], poly[(i + 1) % len(poly)]
        su = side((u.p[0], u.p[2]), a, b) * (1 if keep_inside else -1); sw = side((w.p[0], w.p[2]), a, b) * (1 if keep_inside else -1)
        if su >= 0: out.append(u)
        if (su >= 0) != (sw >= 0):
            out.append(lerp(u, w, su / (su - sw)))
    return out
newN = lambda n: ["%.4f" % x for x in (n / (np.linalg.norm(n) or 1))]
def emit(poly, grp, mat):
    if len(poly) < 3: return
    idx = []
    for v in poly:
        o.V = np.vstack([o.V, v.p]); o.T.append([float(v.t[0]), float(v.t[1])]); o.N.append(newN(v.n)); idx.append(len(o.V) - 1)
    ni = len(o.N) - len(poly)
    for k in range(1, len(poly) - 1):
        o.faces_new.append([grp, mat, [[idx[0], len(o.T) - len(poly), ni], [idx[k], len(o.T) - len(poly) + k, ni + k], [idx[k + 1], len(o.T) - len(poly) + k + 1, ni + k + 1]]])
o.faces_new = []; keep = []; clipped = 0
cand = lambda f: f[0] in ("body", "part_hood") and len(f[2]) == 3 and "glass" not in f[1]
for f in o.faces:
    if not cand(f): keep.append(f); continue
    p = V[[c[0] for c in f[2]]]
    ny = normal_y(p) * sgn
    is_top = ny >= 0.35 and p[:, 1].mean() >= yband
    is_liner = yL is not None and ny <= -0.35 and yL[0] <= p[:, 1].mean() <= yL[1]
    if not (is_top or is_liner): keep.append(f); continue
    c = p[:, [0, 2]]
    ins = [side(q, a, b) >= -1e-9 for q in c for (a, b) in [(None, None)]] if False else None
    allin = all(side(q, a, b) >= -1e-9 for q in c for (a, b) in edges); allout = any(all(side(q, a, b) < -1e-9 for q in c) for (a, b) in edges)
    if allin: f[0] = "part_hood"; keep.append(f); continue
    if allout: f[0] = "body"; keep.append(f); continue
    verts = [Vert(V[c_[0]], o.T[c_[1]], np.array([float(x) for x in o.N[c_[2]]]) if c_[2] >= 0 else [0, 1, 0]) for c_ in f[2]]
    inside = verts
    for (a, b) in edges: inside = clip_half(inside, a, b, True)
    emit(inside, "part_hood", f[1])
    rest = []
    for i, (a, b) in enumerate(edges):                      # bagian luar: tepi demi tepi
        part = clip_half(verts, a, b, False)
        # buang bagian yang sudah termasuk sisa tepi sebelumnya dengan memotong 'verts' ke dalam tepi ini
        emit(part, "body", f[1])
        verts = clip_half(verts, a, b, True)
        if len(verts) < 3: break
    clipped += 1
o.faces = keep + o.faces_new
print("segitiga dipotong:", clipped, "| muka baru:", len(o.faces_new))
o.write(sys.argv[2])
