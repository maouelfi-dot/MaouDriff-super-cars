"""crop_atlas.py - potong bagian atlas yang TIDAK dipakai UV mana pun (tanpa mengubah tampilan sama sekali).
Menghemat RAM GPU: tekstur 2048x2048 yang isinya hanya 40% jadi 2048x784, dst.
Pakai: python3 crop_atlas.py in.obj out.obj tex1.png [tex2.png ...] --out-dir DIR"""
import sys, os, numpy as np
from objlib import Obj
from PIL import Image
a = sys.argv[1:]; od = a[a.index("--out-dir") + 1]; a = a[:a.index("--out-dir")]
src, dst, texs = a[0], a[1], a[2:]
o = Obj(src); H = Image.open(texs[0]).size[1]
used = {c[1] for f in o.faces for c in f[2]}
rows = np.array([(1 - o.T[i][1]) * H for i in used])
top = max(0, int((rows.min() - 4) // 16) * 16); bot = min(H, int(-(-(rows.max() + 4) // 16)) * 16); H2 = bot - top
for t in o.T: t[1] = 1 - ((1 - t[1]) * H - top) / H2
o.write(dst)
os.makedirs(od, exist_ok=True)
for t in texs:
    im = Image.open(t); assert im.size[1] == H, t
    im.crop((0, top, im.size[0], bot)).save(os.path.join(od, os.path.basename(t)), optimize=True)
print(os.path.basename(src), "tinggi", H, "->", H2, "(hemat %d%%)" % round((1 - H2 / H) * 100))
