# Simulasi undakan (tanpa Minecraft)
Menjalankan fisika asli (GroundSensor + CarPhysics + CarBody) di atas terrain buatan untuk mengukur
loncatan/getaran mobil di undakan, tanjakan, dan tangga slab.

    cd core/src/main/java
    javac -d /tmp/out com/maou/maoudrift/physics/*.java com/maou/maoudrift/ground/*.java \
          com/maou/maoudrift/debug/*.java com/maou/maoudrift/surface/*.java com/maou/maoudrift/util/Mth.java
    javac -cp /tmp/out -d /tmp/out ../../../tools/step_sim/Sim.java
    java -cp /tmp/out Sim          # undakan 0.5 naik / 1.0 turun, banyak kecepatan
    java -cp /tmp/out Sim reg      # tanjakan, tangga slab, curb, lubang 1 blok
    java -cp /tmp/out Sim one 0.5 15 coast   # satu skenario + log per tick (negatif = turun)

Kolom: airTicks = jumlah tick ke-4 roda tanpa beban; maxH-above-rest = setinggi apa badan melambung dari
tinggi diam di atas undakan.
