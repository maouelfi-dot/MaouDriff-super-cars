import com.maou.maoudrift.ground.GroundSensor;
import com.maou.maoudrift.physics.*;
import com.maou.maoudrift.surface.RoadSurface;

import java.util.*;
import java.util.function.DoubleBinaryOperator;

public class Sim {
    static final double BASE = 64.0;

    static class H implements GroundSensor.Hit {
        boolean miss, inside; double x, y, z;
        public boolean miss() { return miss; }
        public boolean inside() { return inside; }
        public double x() { return x; }
        public double y() { return y; }
        public double z() { return z; }
        public RoadSurface surface() { return RoadSurface.PAVED; }
    }

    static class W implements GroundSensor.World {
        final DoubleBinaryOperator h;
        W(DoubleBinaryOperator h) { this.h = h; }
        double top(double x, double z) { return h.applyAsDouble(Math.floor(x), Math.floor(z)); }
        public GroundSensor.Hit castDown(double x, double fromY, double toY, double z) {
            double t = top(x, z);
            H r = new H(); r.x = x; r.z = z;
            if (fromY < t) { r.inside = true; r.y = t; return r; }
            if (t >= toY) { r.y = t; return r; }
            r.miss = true; return r;
        }
        public double solidTopAbove(double x, double y, double z) {
            double t = top(x, z);
            return y < t ? t : Double.NEGATIVE_INFINITY;
        }
        public double[] tireGroundEdges() { return new double[]{0.1, 0.25}; }
        public boolean recordsTrace() { return false; }
    }

    static CarSpec spec() {
        return CarSpec.builder().wheelBase(3.2964).frontTrackWidth(2.0706).rearTrackWidth(2.0706)
                .mass(1750).wheelRadius(0.4329).peakTorque(650).peakTorqueRpm(4600).redlineRpm(7400)
                .maxSteerAngle(0.8378).build();
    }

    static void fill(BlockField f, W w, double x, double z) {
        f.clear();
        for (int cx = (int) Math.floor(x) - 6; cx <= Math.floor(x) + 6; cx++)
            for (int cz = (int) Math.floor(z) - 9; cz <= Math.floor(z) + 9; cz++) {
                double t = w.h.applyAsDouble(cx, cz);
                f.add(cx, t - 4.0, cz, cx + 1, t, cz + 1);
            }
    }

    static String run(String name, DoubleBinaryOperator terrain, double speed, boolean gas, double z0, double edgeZ, boolean verbose) {
        CarSpec spec = spec();
        W world = new W(terrain);
        GroundSensor sensor = new GroundSensor(world);
        CarState s = new CarState();
        BlockField field = new BlockField();
        CarBody body = CarBody.of(spec);
        double x = 0.5, z = z0;
        double g0 = terrain.applyAsDouble(x, z);
        s.height = g0 + spec.staticRideHeight() + 0.02;
        s.forwardSpeed = speed;
        s.gear = 1;
        double av = speed / spec.wheelRadius();
        Arrays.fill(s.wheelAngularVelocity, av);
        sensor.forgetHeights();
        CarInput in = gas ? new CarInput(true, false, false, false) : CarInput.NONE;
        CarInput settle = CarInput.NONE;
        double dt = 0.05 / 4;
        double maxVy = 0, maxUp = -1e9, maxPitch = 0, maxRoll = 0, maxImpact = 0;
        int airTicks = 0, ticks = 0;
        double crossT = -1;
        List<Double> vyAfter = new ArrayList<>();
        double startZ = z;
        double minVy = 0;
        double baselineAfter = terrain.applyAsDouble(x, edgeZ + 20) + spec.staticRideHeight();
        int total = (int) (8.0 / 0.05);
        for (int t = 0; t < total; t++) {
            fill(field, world, x, z);
            double impactTick = 0; boolean allAir = true;
            for (int i = 0; i < 4; i++) {
                sensor.update(s, spec, spec, 0.0, x, z, dt);
                CarPhysics.step(spec, s, sensor.contact(), dt, i == 0 ? (t < 10 ? settle : in) : in.withoutShift());
                CarBody.Result r = body.solve(spec, s, sensor.contact(), x, z, field, dt);
                impactTick = Math.max(impactTick, r.impact);
                x += s.velocityX() * dt; z += s.velocityZ() * dt;
            }
            for (int w2 = 0; w2 < Wheel.COUNT; w2++) if (s.wheelLoad[w2] > 1.0) allAir = false;
            ticks++;
            if (z > edgeZ - 3 && crossT < 0) crossT = t;
            if (crossT >= 0 && z < edgeZ + 40) {
                if (allAir) airTicks++;
                maxVy = Math.max(maxVy, s.verticalSpeed);
                minVy = Math.min(minVy, s.verticalSpeed);
                maxPitch = Math.max(maxPitch, Math.abs(s.pitch));
                maxRoll = Math.max(maxRoll, Math.abs(s.roll));
                maxImpact = Math.max(maxImpact, impactTick);
                maxUp = Math.max(maxUp, s.height);
            }
            if (z > edgeZ + 10 && z < edgeZ + 40) vyAfter.add(s.verticalSpeed);
            if (verbose && crossT >= 0 && t < crossT + 110)
                System.out.printf("t=%3d z=%6.2f v=%5.1f h=%6.3f vy=%6.2f pitch=%5.1f roll=%5.1f load=%.0f %.0f %.0f %.0f%n", t, z - edgeZ, s.forwardSpeed, s.height - g0, s.verticalSpeed,
                        Math.toDegrees(s.pitch), Math.toDegrees(s.roll), s.wheelLoad[0], s.wheelLoad[1], s.wheelLoad[2], s.wheelLoad[3]);
            if (z > edgeZ + 45) break;
        }
        double sd = 0; if (!vyAfter.isEmpty()) { double m = vyAfter.stream().mapToDouble(d -> d).average().orElse(0); sd = Math.sqrt(vyAfter.stream().mapToDouble(d -> (d - m) * (d - m)).average().orElse(0)); }
        double finalGround = terrain.applyAsDouble(x, z);
        return String.format("%-22s v0=%4.0f %s | maxVy=%5.2f minVy=%5.2f airTicks=%3d maxPitch=%5.1f maxRoll=%5.1f impact=%5.1f settleJitter=%.3f maxH-above-rest=%.2f",
                name, speed, gas ? "gas " : "coast", maxVy, minVy, airTicks, Math.toDegrees(maxPitch), Math.toDegrees(maxRoll), maxImpact, sd,
                (maxUp - (finalGround + spec.staticRideHeight())));
    }

    public static void main(String[] a) {
        if (a.length >= 1 && a[0].equals("reg")) {
            Object[][] sc = {
                {"ramp12.5%-up", (DoubleBinaryOperator) (cx, cz) -> BASE + (cz < 0 ? 0 : Math.min(cz, 16) * 0.125 - (Math.min(cz, 16) * 0.125) % 0.0625)},
                {"ramp12.5%-down", (DoubleBinaryOperator) (cx, cz) -> BASE + 2.0 - (cz < 0 ? 0 : Math.min(cz, 16) * 0.125 - (Math.min(cz, 16) * 0.125) % 0.0625)},
                {"slabstairs-up", (DoubleBinaryOperator) (cx, cz) -> BASE + (cz < 0 ? 0 : 0.5 * Math.min(8, Math.floor(cz / 2) + 1))},
                {"slabstairs-down", (DoubleBinaryOperator) (cx, cz) -> BASE + 4.0 - (cz < 0 ? 0 : 0.5 * Math.min(8, Math.floor(cz / 2) + 1))},
                {"curb0.5-1wide", (DoubleBinaryOperator) (cx, cz) -> BASE + (cz == 0 ? 0.5 : 0)},
                {"slab0.5-up-down", (DoubleBinaryOperator) (cx, cz) -> BASE + (cz >= 0 && cz < 6 ? 0.5 : 0)},
                {"block1-down-up", (DoubleBinaryOperator) (cx, cz) -> BASE + (cz >= 0 && cz < 6 ? -1.0 : 0)},
            };
            for (Object[] o : sc) for (double sp : new double[]{8, 15, 25}) for (boolean gas : new boolean[]{false}) {
                System.out.println(run((String) o[0], (DoubleBinaryOperator) o[1], sp, gas, -40, 0, false));
            }
            return;
        }
        if (a.length >= 4 && a[0].equals("one")) {
            double up = Double.parseDouble(a[1]); double sp = Double.parseDouble(a[2]); boolean gas = a[3].equals("gas");
            boolean down = up < 0; double stepH = Math.abs(up);
            DoubleBinaryOperator t = down ? (cx, cz) -> cz < 0 ? BASE + stepH : BASE : (cx, cz) -> cz < 0 ? BASE : BASE + stepH;
            System.out.println(run("one", t, sp, gas, -40, 0, true));
            return;
        }
        double edge = 0;
        boolean verbose = a.length > 0 && a[0].equals("v");
        double[] speeds = {5, 10, 15, 25, 35};
        double[][] heights = {{1.0, 1.0}, {0.5, 0.5}, {1.0, -1.0}};
        for (double[] hh : heights) {
            double up = hh[0]; boolean down = hh[1] < 0;
            String label = (down ? "STEP-DOWN " : "STEP-UP ") + (down ? 1.0 : up);
            for (double sp : speeds) for (boolean gas : new boolean[]{false, true}) {
                final double stepH = up;
                DoubleBinaryOperator t = down
                        ? (cx, cz) -> cz < edge ? BASE + 1.0 : BASE
                        : (cx, cz) -> cz < edge ? BASE : BASE + stepH;
                double z0 = edge - 40;
                double base0 = down ? 1.0 : 0.0;
                System.out.println(run(label, t, sp, gas, z0, edge, verbose && sp == 15 && !gas));
            }
        }
    }
}
