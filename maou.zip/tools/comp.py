import sys, numpy as np
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
def comps(o, sel):
    V=o.V; key={}; pid=np.empty(len(V),int)
    for i,p in enumerate(np.round(V,3)): pid[i]=key.setdefault(tuple(p),len(key))
    par=list(range(len(key)))
    def find(a):
        while par[a]!=a: par[a]=par[par[a]]; a=par[a]
        return a
    for f in sel:
        ids=[pid[c[0]] for c in f[2]]
        for v in ids[1:]:
            ra,rb=find(ids[0]),find(v)
            if ra!=rb: par[ra]=rb
    C={}
    for f in sel: C.setdefault(find(pid[f[2][0][0]]),[]).append(f)
    return list(C.values())
if __name__=='__main__':
    o=Obj(sys.argv[1]); V=o.V
    sel=[f for f in o.faces if 'glass' in f[1]]
    print(len(sel),'glass faces')
    for c in sorted(comps(o,sel),key=lambda c:-len(c)):
        p=V[[x[0] for f in c for x in f[2]]]
        g={}
        for f in c: g[(f[0],f[1])]=g.get((f[0],f[1]),0)+1
        print(len(c),'lo',p.min(0).round(2),'hi',p.max(0).round(2),g)
