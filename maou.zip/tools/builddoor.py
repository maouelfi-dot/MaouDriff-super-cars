"""builddoor.py car in.obj out.obj
Bangun ulang pintu: (1) buang isi dalam yang berantakan, (2) pasang panel dalam pintu yang bersih + bibir tepi,
(3) pasang bingkai (lapisan) di tepi kaca pintu: cat di luar, hitam di dalam."""
import sys, numpy as np
from scipy import ndimage as ndi
from PIL import Image
sys.path.insert(0,'/home/claude/src/tools')
from objlib import Obj
TEX={'zacoe_m2':'zacoe_m2','varis_gts':'varis_gts','supra':'supra','krc_supra':'krc_supra_black'}
car,inp,outp=sys.argv[1:4]
OPEN={'supra':10,'krc_supra':6}.get(car,7)
R='/home/claude/src/core/src/main/resources/assets/maoudrift/textures/entity/'
im=np.array(Image.open(R+TEX[car]+'.png').convert('RGB')); th,tw=im.shape[:2]
def texel(uv): return im[min(th-1,int((1-uv[1]%1)*th)),min(tw-1,int((uv[0]%1)*tw))].astype(float)
o=Obj(inp); V=o.V.copy(); T=o.T; N=o.N
NV=[tuple(v) for v in V]; newf=[]
def addv(p): NV.append(tuple(p)); return len(NV)-1
def addt(u,v): T.append([u,v]); return len(T)-1
def addn(n): N.append(['%.5f'%n[0],'%.5f'%n[1],'%.5f'%n[2]]); return len(N)-1
def fnorm(a,b,c):
    n=np.cross(b-a,c-a); l=np.linalg.norm(n); return n/l if l>0 else np.array([0,1.,0])
RES=0.01
# 0. pintu salah sisi
for f in o.faces:
    if f[0] in ('part_door_l','part_door_r'):
        q=V[[c[0] for c in f[2]]]
        if q[:,0].mean()>0.3: f[0]='part_door_l'
        elif q[:,0].mean()<-0.3: f[0]='part_door_r'
for dn,s in (('part_door_l',1),('part_door_r',-1)):
    df=[f for f in o.faces if f[0]==dn and 'glass' not in f[1]]
    gl=[f for f in o.faces if f[0]==dn and 'glass' in f[1]]
    P=V[[c[0] for f in df for c in f[2]]]; xo=np.percentile(np.abs(P[:,0]),90)
    z0,y0=P[:,2].min()-0.1,P[:,1].min()-0.1; nz=int((P[:,2].max()+0.1-z0)/RES)+1; ny=int((P[:,1].max()+0.1-y0)/RES)+1
    cov=np.zeros((nz,ny),bool); hm=np.full((nz,ny),-1.0)
    def cell(p): return int((p[2]-z0)/RES),int((p[1]-y0)/RES)
    for f in df:
        q=V[[c[0] for c in f[2]]]; n=fnorm(q[0],q[1],q[2])
        if n[0]*s<0.4 or np.abs(q[:,0]).mean()<xo-0.15: continue
        m=q.mean(0)
        for p in list(q)+[m]+[(q[i]+q[(i+1)%len(q)])/2 for i in range(len(q))]+[(q[i]+m)/2 for i in range(len(q))]:
            a,b=cell(p)
            if 0<=a<nz and 0<=b<ny: cov[a,b]=True; hm[a,b]=max(hm[a,b],abs(p[0]))
    mask=ndi.binary_fill_holes(ndi.binary_closing(cov,structure=np.ones((3,3)),iterations=5))
    mask=ndi.binary_opening(mask,structure=np.ones((3,3)),iterations=3)|cov
    idx=ndi.distance_transform_edt(hm<0,return_distances=False,return_indices=True); H=hm[idx[0],idx[1]]
    ys=np.where(mask.any(0))[0]; ybelt=y0+ys.max()*RES
    edge=mask&~ndi.binary_erosion(mask,iterations=3)
    core=ndi.binary_dilation(ndi.binary_opening(mask,structure=np.ones((3,3)),iterations=OPEN),iterations=2)
    keep=[];skin=[];drop=0
    for f in df:
        q=V[[c[0] for c in f[2]]]; cen=q.mean(0); a,b=cell(cen)
        inm=0<=a<nz and 0<=b<ny and mask[a,b]
        n=fnorm(q[0],q[1],q[2])
        if inm:
            bad=False
            for p in q:
                pa,pb=cell(p)
                if not(0<=pa<nz and 0<=pb<ny) or not core[pa,pb]: bad=True;break
            if bad: drop+=1; continue
            if abs(cen[0])>=H[a,b]-0.06:
                keep.append(f)
                if n[0]*s>0.5: skin.append(f)
            else: drop+=1
        else:
            if cen[1]>=ybelt-0.02: keep.append(f)
            else: drop+=1
    kid={id(f) for f in keep}
    o.faces=[f for f in o.faces if not(f[0]==dn and 'glass' not in f[1] and id(f) not in kid)]
    # warna cat & hitam
    cols=[(f,texel(np.mean([T[c[1]] for c in f[2]],axis=0))) for f in skin[::7]]
    med=np.median([c for _,c in cols],axis=0)
    pf=min(cols,key=lambda fc:np.abs(fc[1]-med).sum())[0]; paint_uv=np.mean([T[c[1]] for c in pf[2]],axis=0); paint_mat=pf[1]
    black_uv=np.mean([T[c[1]] for g in gl for c in g[2]],axis=0) if gl else paint_uv
    tp=addt(*paint_uv); tb=addt(*black_uv)
    TH=0.085
    # 3. panel dalam (salinan kulit, digeser ke dalam, dibalik)
    vmap={}
    def inner(i):
        if i not in vmap: p=V[i].copy(); p[0]-=s*TH; vmap[i]=addv(p)
        return vmap[i]
    nb=addn(np.array([-s,0,0]))
    for f in skin:
        ids=[c[0] for c in f[2]]
        if len(ids)<3: continue
        tri=[inner(i) for i in ids][::-1]
        o_f=[tri[k] for k in range(len(tri))]
        newf.append([dn,paint_mat,[[v,tb,nb] for v in o_f]])
    # 4. bibir tepi: tepi batas dari kulit, hanya yang di tepi topeng
    cnt={}
    key=lambda i:tuple(np.round(V[i],4))
    for f in skin:
        ids=[c[0] for c in f[2]]
        for k in range(len(ids)):
            e=(key(ids[k]),key(ids[(k+1)%len(ids)])); cnt.setdefault(frozenset(e),[]).append((ids[k],ids[(k+1)%len(ids)]))
    cz,cy=np.argwhere(mask).mean(0); cc=np.array([0,y0+cy*RES,z0+cz*RES])
    for e,lst in cnt.items():
        if len(lst)!=1: continue
        a,b=lst[0]; m=(V[a]+V[b])/2; ia,ib=cell(m)
        if not(0<=ia<nz and 0<=ib<ny) or not edge[max(0,min(nz-1,ia)),max(0,min(ny-1,ib))]: continue
        a2,b2=inner(a),inner(b)
        qd=[a,b,b2,a2]; pts=[np.array(NV[i]) for i in qd]
        n=fnorm(pts[0],pts[1],pts[2]); out=np.array([0,m[1]-cc[1],m[2]-cc[2]])
        if np.dot(n,out)<0: qd=qd[::-1]; n=-n
        nn=addn(n); newf.append([dn,paint_mat,[[v,tp,nn] for v in qd]])
    # 5. bingkai kaca
    for comp_f in gl:
        pass
    G=0.005
    gP=V[[c[0] for f in gl for c in f[2]]] if gl else np.zeros((1,3))
    gz0,gy0=gP[:,2].min()-0.05,gP[:,1].min()-0.05; gnz=int((gP[:,2].max()+0.05-gz0)/G)+1; gny=int((gP[:,1].max()+0.05-gy0)/G)+1
    gm=np.zeros((gnz,gny),bool)
    for f in gl:
        q=V[[c[0] for c in f[2]]]; m_=q.mean(0)
        for p in list(q)+[m_]+[(q[i]+q[(i+1)%len(q)])/2 for i in range(len(q))]+[(q[i]+m_)/2 for i in range(len(q))]+[(q[i]+(q[i]+q[(i+1)%len(q)])/2)/2 for i in range(len(q))]:
            a_=int((p[2]-gz0)/G); b_=int((p[1]-gy0)/G)
            if 0<=a_<gnz and 0<=b_<gny: gm[a_,b_]=True
    gm=ndi.binary_fill_holes(ndi.binary_closing(np.pad(gm,15),structure=np.ones((3,3)),iterations=12)[15:-15,15:-15])
    gedge=gm&~ndi.binary_erosion(gm,iterations=3)
    import cv2
    W=0.036; TK=0.014
    if gl:
        gxs=np.abs(gP[:,0]); outer=gP[gxs>=np.percentile(gxs,40)]
        A_=np.c_[outer[:,2],outer[:,1],np.ones(len(outer))]; coef=np.linalg.lstsq(A_,outer[:,0],rcond=None)[0]
        xat=lambda z,y: coef[0]*z+coef[1]*y+coef[2]
        cs,_=cv2.findContours(gm.astype(np.uint8),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
        cnt_=cv2.convexHull(max(cs,key=cv2.contourArea))
        ap=cv2.approxPolyDP(cnt_,2.0,True)[:,0,:].astype(float)   # (col=y idx, row=z idx)?  cv2: x=col(axis1=y), y=row(axis0=z)
        pts=np.array([[gz0+(p[1]+0.5)*G, gy0+(p[0]+0.5)*G] for p in ap])  # (z,y)
        if len(pts)>=3:
            cen2=pts.mean(0); n=len(pts); inn=[];out=[]
            for i in range(n):
                p0,p1,p2=pts[i-1],pts[i],pts[(i+1)%n]
                def nrm(a,b):
                    d=b-a; l=np.linalg.norm(d); d=d/l if l>0 else d
                    nv=np.array([d[1],-d[0]]); 
                    return nv if np.dot(nv,(a+b)/2-cen2)>0 else -nv
                n1,n2=nrm(p0,p1),nrm(p1,p2); nm=n1+n2; l=np.linalg.norm(nm)
                nm=nm/l if l>1e-6 else n1; cosv=max(0.45,np.dot(nm,n1))
                inn.append(p1); out.append(p1+nm*W/cosv)
            def P3(zy,dx): return np.array([xat(zy[0],zy[1])+s*dx,zy[1],zy[0]])
            # kaca bersih: triangulasi siluet
            from scipy.spatial import Delaunay
            gmat=gl[0][1]; tg=addt(*black_uv)
            xs_=np.linspace(pts[:,0].min(),pts[:,0].max(),14); ys_=np.linspace(pts[:,1].min(),pts[:,1].max(),10)
            extra=[[a,b] for a in xs_ for b in ys_ if cv2.pointPolygonTest(pts.astype(np.float32),(float(a),float(b)),True)>0.03]
            allp2=np.vstack([pts]+[np.array(extra)]) if extra else pts
            dl=Delaunay(allp2); gids={}
            def gv(k,layer):
                if (k,layer) not in gids: gids[(k,layer)]=addv(P3(allp2[k],0.0 if layer==0 else -0.004))
                return gids[(k,layer)]
            ng1=addn(np.array([s,0,0])); ng2=addn(np.array([-s,0,0]))
            for tri_ in dl.simplices:
                cz_,cy_=allp2[tri_].mean(0)
                if cv2.pointPolygonTest(pts.astype(np.float32),(float(cz_),float(cy_)),False)<0: continue
                A,B,C=[P3(allp2[k],0) for k in tri_]
                if np.dot(fnorm(A,B,C),np.array([s,0,0]))<0: tri_=tri_[::-1]
                newf.append([dn,gmat,[[gv(k,0),tg,ng1] for k in tri_]])
                newf.append([dn,gmat,[[gv(k,1),tg,ng2] for k in tri_[::-1]]])
            gid={id(f) for f in gl}; o.faces=[f for f in o.faces if id(f) not in gid]
            for i in range(n):
                j=(i+1)%n
                midy=(inn[i][1]+inn[j][1])/2
                if midy<ybelt+0.05: continue
                if max(inn[i][1],inn[j][1])<ybelt+0.08: continue
                q_top=[P3(inn[i],0.004),P3(inn[j],0.004),P3(out[j],0.004),P3(out[i],0.004)]
                q_bot=[P3(inn[i],-TK),P3(inn[j],-TK),P3(out[j],-TK),P3(out[i],-TK)]
                nt=fnorm(q_top[0],q_top[1],q_top[2])
                if nt[0]*s<0: q_top=q_top[::-1]; nt=-nt
                ia=[addv(p) for p in q_top]; ib_=[addv(p) for p in q_bot]
                newf.append([dn,paint_mat,[[v,tp,addn(nt)] for v in ia]])
                newf.append([dn,paint_mat,[[v,tb,addn(-nt)] for v in ib_[::-1]]])
                # dinding luar
                wq=[P3(out[i],0.004),P3(out[j],0.004),P3(out[j],-TK),P3(out[i],-TK)]
                nw=fnorm(wq[0],wq[1],wq[2]); outv=np.array([0,(out[i][1]+out[j][1])/2-cen2[1],(out[i][0]+out[j][0])/2-cen2[0]])
                if np.dot(nw,outv)<0: wq=wq[::-1]; nw=-nw
                iw=[addv(p) for p in wq]; newf.append([dn,paint_mat,[[v,tp,addn(nw)] for v in iw]])
    print(car,dn,'dibuang',drop,'kulit',len(skin),'faces baru so far',len(newf))
o.V=np.array(NV); o.N=N; o.T=T
for f in newf: o.faces.append(f)
o.write(outp)
