"""swap_steer.py target.obj donor.obj out.obj [supra]
Ganti grup steering_wheel target dengan stir donor (halus, lingkar penuh), diselaraskan ke bidang/ukuran/posisi stir target.
Mode 'supra': target rusak (hanya busur) -> pindah saja ke posisi hub target."""
import sys, collections, numpy as np
from objlib import Obj
tgt, don, dst = sys.argv[1:4]; mode = sys.argv[4] if len(sys.argv) > 4 else ""
t = Obj(tgt); d = Obj(don)
dfaces = [f for f in d.faces if f[0] == "steering_wheel"]
tfaces = [f for f in t.faces if f[0] == "steering_wheel"]
dv = d.V[sorted({c[0] for f in dfaces for c in f[2]})]
tv = t.V[sorted({c[0] for f in tfaces for c in f[2]})]
def basis(p):
    c = (p.min(0) + p.max(0)) / 2
    w, E = np.linalg.eigh(np.cov((p - p.mean(0)).T)); n = E[:, 0]
    if n[2] > 0: n = -n                          # menghadap pengemudi (depan model = +z)
    e1 = np.array([1.0, 0, 0]); e1 = e1 - n * (e1 @ n); e1 /= np.linalg.norm(e1); e2 = np.cross(n, e1)
    return c, np.stack([e1, e2, n], 1)
cd_, Bd = basis(dv)
if mode == "supra":
    R = np.eye(3); s = 1.0
    ctr_t = np.array([(tv[:, 0].min() + tv[:, 0].max()) / 2, tv[:, 1].max() - (dv[:, 1].max() - cd_[1]), (tv[:, 2].min() + tv[:, 2].max()) / 2])
else:
    ct, Bt = basis(tv); R = Bt @ Bd.T
    s = (tv[:, 0].max() - tv[:, 0].min()) / (dv[:, 0].max() - dv[:, 0].min()); ctr_t = ct
print("skala", round(s, 3), "pusat", ctr_t.round(3))
# uv & material warna kulit: ambil yang paling sering di setir target
cnt = collections.Counter((f[1], c[1]) for f in tfaces for c in f[2])
(mat, vt), _ = cnt.most_common(1)[0]
newV = {}; newN = {}
def addv(i):
    p = (d.V[i] - cd_) @ R.T * s + ctr_t
    if i not in newV: t.V = np.vstack([t.V, p]); newV[i] = len(t.V) - 1
    return newV[i]
def addn(i):
    if i < 0: return -1
    if i not in newN:
        n = np.array([float(x) for x in d.N[i]]); n = R @ n
        t.N.append(["%.4f" % x for x in n]); newN[i] = len(t.N) - 1
    return newN[i]
t.faces = [f for f in t.faces if f[0] != "steering_wheel"]
for f in dfaces:
    t.faces.append(["steering_wheel", mat, [[addv(c[0]), vt, addn(c[2])] for c in f[2]]])
t.write(dst); print("faces setir baru:", len(dfaces))
