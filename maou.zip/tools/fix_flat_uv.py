"""fix_flat_uv.py in.obj tex.png out.obj
Segitiga yang menempel pada area warna POLOS (cat) tapi UV sudutnya menyentuh tepi tile / tile tetangga akan
menghasilkan garis-garis hitam ("barcode") dan stiker ketarik. UV-nya dikumpulkan ke titik tengah area polos itu."""
import sys, numpy as np
from objlib import Obj
from PIL import Image
def run(src, tex, dst):
    o = Obj(src)
    img = np.asarray(Image.open(tex).convert("RGB")).astype(int); H, W, _ = img.shape
    def px(u, v): return (min(H - 1, max(0, int((1 - v) * H))), min(W - 1, max(0, int(u * W))))
    def S(u, v):
        y, x = px(u, v); return img[y, x]
    def around(u, v):
        y, x = px(u, v)
        return [img[min(H - 1, max(0, y + dy)), min(W - 1, max(0, x + dx))] for dy in (-1, 0, 1) for dx in (-1, 0, 1)]
    new = {}; cnt = 0; tot = 0
    for f in o.faces:
        c = f[2]
        if len(c) != 3: continue
        t = np.array([o.T[x[1]] for x in c]); ctr = t.mean(0)
        if max(np.ptp(t[:, 0]) * W, np.ptp(t[:, 1]) * H) < 3: continue
        tot += 1
        cen = S(*ctr)
        inner = [S(*(ctr + (p - ctr) * 0.7)) for p in t]
        if max(np.abs(x - cen).max() for x in inner) >= 6: continue       # bukan area polos
        bad = any(np.abs(a - cen).max() > 12 for p in t for a in around(*p))
        if not bad: continue
        key = (round(ctr[0] * W), round(ctr[1] * H))
        if key not in new:
            o.T.append([(round(ctr[0] * W) + 0.5) / W, (round(ctr[1] * H) + 0.5) / H]); new[key] = len(o.T) - 1
        for x in c: x[1] = new[key]
        cnt += 1
    o.write(dst); return tot, cnt
if __name__ == "__main__":
    print(run(*sys.argv[1:4]))
