import numpy as np, glob, json, shutil
from PIL import Image
R='v8/core/src/main/resources/assets/maoudrift/'
car='krc_supra'; RX,RY,RW,RH=1232,0,800,235
TW,TH=2048,768
wrap=Image.open('liv/519_generated.jpg').convert('RGB').crop((0,742,1920,1280)).resize((RW-4,RH-4),Image.LANCZOS)
base=np.array(Image.open(R+'textures/entity/krc_supra_green.png').convert('RGB'))
p=R+'models/entity/%s.obj'%car; L=open(p).read().rstrip('\n').split('\n')
V=[];VT=[];VN=[]
for l in L:
    t=l.split()
    if not t: continue
    if t[0]=='v': V.append([float(x) for x in t[1:4]])
    elif t[0]=='vt': VT.append([float(x) for x in t[1:3]])
    elif t[0]=='vn': VN.append([float(x) for x in t[1:4]])
V=np.array(V);VT=np.array(VT);VN=np.array(VN)
# body extents
ys=V[:,1];zs=V[:,2]
body=[];g=None
for i,l in enumerate(L):
    t=l.split()
    if t and t[0] in('g','o'): g=t[1]
    if t and t[0]=='f' and g in('body','part_door_l','part_door_r'): body.append(i)
bv=sorted({int(x.split('/')[0])-1 for i in body for x in L[i].split()[1:]})
zmin,zmax=V[bv,2].min(),V[bv,2].max(); ymin,ymax=V[bv,1].min(),V[bv,1].max()
new=[];out=list(L);nvt=len(VT);cnt=0;sample=None
for i in body:
    t=L[i].split(); cs=[x.split('/') for x in t[1:]]
    ids=[int(c[0])-1 for c in cs]; uvs=[VT[int(c[1])-1] for c in cs]; vns=[VN[int(c[2])-1] for c in cs]
    cc=V[ids].mean(0); uv=np.mean(uvs,0)
    px=base[int((1-uv[1])*TH)%TH,int(uv[0]*TW)%TW].astype(int)
    if not(px[1]>70 and px[1]>px[0]+40 and px[1]>px[2]+40): continue
    if abs(cc[0])<0.3: continue
    nx=np.mean(vns,0)[0]*np.sign(cc[0])
    if nx<0.5: continue
    if sample is None: sample=(int((1-uv[1])*TH)%TH,int(uv[0]*TW)%TW)
    toks=[]
    for c,v in zip(cs,ids):
        u=(zmax-V[v,2])/(zmax-zmin); w=(ymax-V[v,1])/(ymax-ymin)
        u=min(max(u,0),1); w=min(max(w,0),1)
        tx=RX+2+u*(RW-4-1); ty=RY+2+w*(RH-4-1)
        new.append('vt %.6f %.6f'%(tx/TW,1-ty/TH)); c[1]=str(nvt+len(new)); toks.append('/'.join(c))
    out[i]='f '+' '.join(toks); cnt+=1
open(p,'w').write('\n'.join(out+new)+'\n'); print('remapped faces',cnt,'sample',sample)
# textures: fill rect with each variant's own paint colour; livery on new variant
for f in glob.glob(R+'textures/entity/%s*.png'%car):
    n=f.split('/')[-1]
    if n.endswith('_s.png') or n.startswith('wheel'): continue
    im=Image.open(f).convert('RGBA'); col=im.getpixel((sample[1],sample[0]))
    im.paste(Image.new('RGBA',(RW,RH),col),(RX,RY)); im.save(f)
gi=Image.open(R+'textures/entity/krc_supra_green.png').convert('RGBA')
gi.paste(wrap.convert('RGBA'),(RX+2,RY+2))
# edge padding so filtering never shows white
for k in range(2):
    gi.paste(wrap.crop((0,0,wrap.width,1)).resize((wrap.width,2)).convert('RGBA'),(RX+2,RY+k*0))
gi.save(R+'textures/entity/krc_supra_green_livery.png')
shutil.copy(R+'textures/entity/krc_supra_green_s.png',R+'textures/entity/krc_supra_green_livery_s.png')
if glob.glob(R+'textures/entity/krc_supra_green.png.mcmeta'): shutil.copy(R+'textures/entity/krc_supra_green.png.mcmeta',R+'textures/entity/krc_supra_green_livery.png.mcmeta')
jp=R+'vehicles/krc_supra.json'; d=json.load(open(jp))
d['paints'].insert(0,{'id':'green_livery','name':'Green Livery','texture':'maoudrift:textures/entity/krc_supra_green_livery.png','swatch':'#7CC52A'})
d['body']['texture']='maoudrift:textures/entity/krc_supra_green_livery.png'
json.dump(d,open(jp,'w'),indent=2)
