# Maou Drift

Maou Drift is a modified derivative of **KurumaMod** by **Deexel**, licensed under GPL-3.0-only.
Original project: KurumaMod (Deexel). All original copyright notices and the GPL-3.0 licence (`LICENSE`) are retained.

Changes (v1.2.0): renamed to Maou Drift (`maoudrift`), original cars removed, cars: Toyota Supra MK IV (optimized),
Varis M4 Widebody, BMW M2 G87 Zacoe Widebody, Varis M4 GTS, all with labPBR specular maps (shine ONLY with a PBR shader),
solid collision, openable doors/hood, underglow. The fake (matcap) shine without shader was removed.
The HUD (round gauges) is the original KurumaMod HUD.

Because this is a derivative of a GPL-3.0 work, Maou Drift is also distributed under GPL-3.0-only,
and its complete source must be made available to anyone who receives the mod.
Car models/textures are supplied by the project owner; verify you have the right to redistribute them.

Sound (v1.3.1): engine loops bmw_s55 / bmw_n55 / bmw_m4_akrapovic are converted from GTA V engine sound packs
(BMW M2-3-4 N/S55 Engine Sound Pack, BMW M4 Akrapovic Sound Legacy DMC). Check the original authors' permission before redistributing.
