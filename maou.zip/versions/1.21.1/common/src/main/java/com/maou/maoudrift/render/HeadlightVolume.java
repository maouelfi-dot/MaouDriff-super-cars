package com.maou.maoudrift.render;

import com.maou.maoudrift.Platform;

import com.maou.maoudrift.client.hook.ShaderRegistrar;

import com.maou.maoudrift.client.hook.LevelRenderStage;

import com.maou.maoudrift.MaouDrift;
import com.maou.maoudrift.entity.CarEntity;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import com.maou.maoudrift.client.ClientPlatform;

/**
 * ヘッドライトの光を<b>画面の画素ごとに</b>解く（{@code shaders/core/headlight_volume.fsh}）。
 *
 * <h2>何をしているか</h2>
 *
 * <p>世界を描き終えたところで画面の色と深度を写し取り、画面いっぱいの四角形を 1 枚描く。
 * シェーダーは画素ごとに:</p>
 * <ul>
 *   <li><b>路面</b> … 深度から位置と面の向きを組み直し、配光から照度を求めてその画素を明るくする。
 *       見えている面にしか乗らないので、ブロックでも車でも人でも、形どおりに照らされる</li>
 *   <li><b>霧の中の光線</b> … カメラから見えている面までの視線を刻み、光の円錐の中で
 *       霧がカメラへ散らす光を足す。前方散乱なのでランプの方を見るほど明るく、
 *       霧に吸われるので奥ほど薄れる。視線は面で止まるので、光線は地面や壁に当たったところで終わる</li>
 * </ul>
 *
 * <p>形を積んで描く {@link CarLights} の路面と光の筋は、これが使えるときは描かない
 * （二重に明るくなる）。光芒（レンズの滲み）はどちらの場合も {@link CarLights} が描く。</p>
 *
 * <h2>使えないとき</h2>
 *
 * <p>シェーダーパック（Iris / Oculus）が入っているとき。あちらは世界の描画そのものを
 * 差し替えるので、ここで写し取る画面が別物になる。シェーダーの読み込みに失敗したときも
 * {@link CarLights} の代用に落ちる。</p>
 *
 * <h2>描くのは <b>AFTER_LEVEL</b></h2>
 *
 * <p>半透明のブロック・天候まで描き終えた後。最高（Fabulous）でも、ここでは合成が済んで
 * 主画面に戻っている。<b>ミラーの描画中は描かない</b>——{@link MirrorRenderer} も
 * {@code renderLevel} を呼ぶのでこのイベントが飛んでくるが、写し取る画面が主画面ではない。</p>
 */
public final class HeadlightVolume {

    private static final Logger LOGGER = LogUtils.getLogger();

    /**
     * ランプを集める入れ物の大きさ。<b>シェーダー側に灯数の決め打ちは無い</b>（ランプはテクスチャで渡す。
     * {@link HeadlightShadows#uploadLamps}）。実際に描く台数は設定
     * （{@link com.maou.maoudrift.config.ClientConfig#headlightCars}、無制限あり）で絞り、天井は GPU の
     * テクスチャの大きさ（{@link HeadlightShadows#maxLamps}）。シェーダーのループは {@code LampCount}
     * までしか回らないので、絞ったぶんだけ軽くなる。
     */
    private static final int MAX_LAMPS = HeadlightShadows.LAMP_CAP;
    /** これより遠い車の光は計算しない。 */
    private static final double MAX_DISTANCE = 128.0;

    /** 光を描く車を集める距離。128m か、光の届く距離 +32m の大きい方（96m 以下では 128m のまま）。 */
    private static double collectDistance() {
        return Math.max(MAX_DISTANCE, com.maou.maoudrift.config.ClientConfig.headlightRange + 32.0);
    }

    /**
     * 霧の濃さ（1m あたりに吸われ・散らされる割合）。
     *
     * <p><b>晴れた夜でもうっすら光線が見える</b>程度を基準にして、雨で濃くする。
     * 濃いほど光線ははっきりするが、そのぶん奥まで届かなくなる。</p>
     */
    private static final float CLEAR_FOG = 0.025F;
    private static final float RAIN_FOG = 0.05F;
    private static final float THUNDER_FOG = 0.03F;

    private static ShaderInstance shader;
    /** ランプから見た距離の地図を描く（{@link HeadlightShadows}）。 */
    private static ShaderInstance shadowShader;
    /** 主画面の色と深度の写し。シェーダーはこれを読み、主画面へ書く。 */
    private static TextureTarget copy;

    private static final Matrix4f[] LAMPS = new Matrix4f[MAX_LAMPS];

    private HeadlightVolume() {
    }

    /** 画素ごとの光が使えるか。使えないなら {@link CarLights} が形を積んで代用する。 */
    public static boolean isActive() {
        if (true) {
            return false; // mode ringan: matikan cahaya per piksel & bayangan lampu
        }
        ensureShaders();
        return shader != null && shadowShader != null && !suppressedByShaderPack();
    }

    /** {@link #ensureShaders} で自分で読もうとしたか。読み直しの合図が来たら戻す。 */
    private static boolean loadAttempted;

    /**
     * シェーダーが無ければ、自分で読む。
     *
     * <p><b>シェーダーパックを有効にしたまま起動すると、{@code RegisterShadersEvent} が飛ばない。</b>
     * Oculus が Minecraft 標準のシェーダーの読み直しを止めるため。合図を待つだけだと、MaouDrift の
     * シェーダーは空のままで、<b>パックを切った後も代用の描き方（ブロック単位のギザギザ）に落ちたままになった</b>。
     * 合図が来たときはそちらで読み直す。描画のスレッドで呼ぶこと。</p>
     */
    static void ensureShaders() {
        if ((shader != null && shadowShader != null) || loadAttempted) {
            return;
        }
        loadAttempted = true;
        try {
            var resources = Minecraft.getInstance().getResourceManager();
            if (shader == null) {
                shader = ClientPlatform.shader(resources, ResourceLocation.fromNamespaceAndPath(MaouDrift.MODID, "headlight_volume"),
                        DefaultVertexFormat.POSITION);
            }
            if (shadowShader == null) {
                shadowShader = ClientPlatform.shader(resources, ResourceLocation.fromNamespaceAndPath(MaouDrift.MODID, "headlight_shadow"),
                        DefaultVertexFormat.POSITION);
            }
            LOGGER.info("ヘッドライトのシェーダーを自分で読んだ（読み直しの合図が来なかった。シェーダーパックを有効にしたまま起動したとき）");
        } catch (IOException | RuntimeException e) {
            LOGGER.error("ヘッドライトのシェーダーを読めなかった。形を積む描き方で代用する", e);
        }
    }

    /**
     * シェーダーパックのために光を止めているか。<b>止めるのは、パックが使われていて、かつ設定で
     * 「使用中も光を描く」を切っているときだけ</b>（{@link com.maou.maoudrift.config.ClientConfig#headlightWithShaderPacks}）。
     *
     * <p>以前はパックが使われていれば無条件に止めていた（Oculus で描画がおかしくなったため）。
     * 2026-10-01 に Oculus 1.8.0 ＋ Embeddium で試すと、路面の照り返しも光芒も深度どおりに乗ったので、
     * 既定で描くようにした。合わないパックのときだけプレイヤーが切れる。パックが無ければ何も変わらない。</p>
     */
    public static boolean suppressedByShaderPack() {
        return !com.maou.maoudrift.config.ClientConfig.headlightWithShaderPacks && ShaderPacks.inUse();
    }

    /**
     * シェーダーパックが<b>いま実際に使われているか</b>。
     *
     * <p>Oculus / Iris / OptiFine のシェーダーは世界の描画そのものを差し替えるので、そこへ
     * 画面を写し取って重ねると壊れる（Oculus で実際に描画がおかしくなった）。<b>MOD が
     * 入っているかではなく、パックが有効か</b>で見る——入っているだけで止めると、シェーダーを
     * 切って遊んでいる人まで光を失う。パックは遊んでいる途中に切り替えられるので毎回聞く。</p>
     *
     * <p>どれもコンパイル時には依存しないのでリフレクションで聞く。<b>聞けなかったら
     * 「使われている」とみなす</b>（壊れた画面より、控えめな代用の方がまし）。</p>
     */
    public static final class ShaderPacks {
        private static boolean resolved;
        private static java.lang.reflect.Method irisInUse;
        private static java.lang.reflect.Method irisShadowPass;
        private static Object irisApi;
        private static java.lang.reflect.Method optifineInUse;
        /** 聞き方が分からなかった（API が変わった）。安全側に倒す。 */
        private static boolean unknown;

        private ShaderPacks() {
        }

        public static boolean inUse() {
            if (!resolved) {
                resolve();
            }
            if (unknown) {
                return true;
            }
            boolean inUse;
            try {
                inUse = (irisInUse != null && (Boolean) irisInUse.invoke(irisApi))
                        || (optifineInUse != null && (Boolean) optifineInUse.invoke(null));
            } catch (ReflectiveOperationException | RuntimeException e) {
                LOGGER.warn("シェーダーパックが使われているか聞けなかった。以後は使われているものとして扱う", e);
                unknown = true;
                return true;
            }
            if (last == null || last != inUse) {
                // 切り替わったときだけ残す。光が出ない・おかしいときに、どちらの描き方かを切り分けるため
                LOGGER.info(inUse
                        ? "シェーダーパックが使われている（光の効果を描くかは設定 headlightWithShaderPacks しだい）"
                        : "シェーダーパックは使われていない。ヘッドライトを画素ごとに描く");
                last = inUse;
            }
            return inUse;
        }

        private static Boolean last;

        /** Oculus / Iris のパックを使っているか。OptiFine と、聞けなかったときは false。 */
        static boolean irisInUse() {
            if (!resolved) {
                resolve();
            }
            if (irisInUse == null) {
                return false;
            }
            try {
                return (Boolean) irisInUse.invoke(irisApi);
            } catch (ReflectiveOperationException | RuntimeException e) {
                return false;
            }
        }

        /**
         * Oculus / Iris が<b>影を描いている最中</b>か。パックは影のために光源の視点からもエンティティを
         * 描くので、その間に光芒を記録すると、光源の視点の座標が混ざって変な場所に描かれる。
         * 聞けなければ false（影のパスが無い OptiFine やパック無しと同じ扱い）。
         */
        static boolean renderingShadowPass() {
            if (!resolved) {
                resolve();
            }
            if (irisShadowPass == null) {
                return false;
            }
            try {
                return (Boolean) irisShadowPass.invoke(irisApi);
            } catch (ReflectiveOperationException | RuntimeException e) {
                irisShadowPass = null;
                return false;
            }
        }

        private static void resolve() {
            resolved = true;
            boolean iris = Platform.isModLoaded("oculus") || Platform.isModLoaded("iris");
            if (iris) {
                try {
                    Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                    irisApi = api.getMethod("getInstance").invoke(null);
                    irisInUse = api.getMethod("isShaderPackInUse");
                    irisShadowPass = api.getMethod("isRenderingShadowPass");
                } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
                    LOGGER.warn("Oculus / Iris の API が見つからない。シェーダーパックが使われているものとして扱う", e);
                    unknown = true;
                }
            }
            try {
                // OptiFine は Forge の MOD 一覧に載らないので、クラスがあるかで見る
                Class<?> config = Class.forName("net.optifine.Config");
                optifineInUse = config.getMethod("isShaders");
            } catch (ClassNotFoundException e) {
                // OptiFine は入っていない
            } catch (ReflectiveOperationException | RuntimeException | LinkageError e) {
                LOGGER.warn("OptiFine のシェーダーの状態が聞けない。使われているものとして扱う", e);
                unknown = true;
            }
        }
    }

    /** シェーダーの登録。<b>mod のイベントバス</b>に飛んでくる。 */
    public static final class Registration {
        private Registration() {
        }

        public static void onRegisterShaders(ShaderRegistrar event) {
            loadAttempted = false;
            try {
                event.registerShader(ResourceLocation.fromNamespaceAndPath(MaouDrift.MODID, "headlight_volume"),
                                DefaultVertexFormat.POSITION,
                        loaded -> shader = loaded);
                event.registerShader(ResourceLocation.fromNamespaceAndPath(MaouDrift.MODID, "headlight_shadow"),
                                DefaultVertexFormat.POSITION,
                        loaded -> shadowShader = loaded);
            } catch (IOException e) {
                // 光が描けないだけで遊べなくはない。形を積む代用に落ちる
                LOGGER.error("ヘッドライトのシェーダーを読めなかった。形を積む描き方で代用する", e);
                shader = null;
                shadowShader = null;
            }
        }
    }

    /**
     * このフレームのカメラの向き。{@code AFTER_SKY} で覚えておく。
     *
     * <p><b>1.21 では {@code getPoseStack()} にカメラの向きが入っていない。</b>1.20.5 から
     * カメラの回転は PoseStack から外れ、別の行列（{@link RenderLevelStageEvent#getModelViewMatrix()}）
     * で渡されるようになった。1.20.1 版のように PoseStack から取ると単位行列になり、
     * 画面から世界へ戻す計算が向きを失って<b>照らす場所がずれる</b>（プレイヤーの周りが丸く
     * 光る・地面が格子状に光る、という形で出た）。</p>
     */
    private static final Matrix4f VIEW = new Matrix4f();
    private static boolean viewCaptured;
    private static boolean announced;

    /**
     * 粒（タイヤの煙・土煙）を描く<b>前</b>の画面の色と深度。
     *
     * <p><b>粒は深度を書く。</b>描き終えた画面の深度だけで光を解くと、煙が壁として扱われ、
     * 光線は煙のところで止まり、その奥の光がまるごと消える（煙越しに見ると光が打ち消されて
     * 見えた）。粒の前の深度で光線と路面を解き、粒は「描く前と後の差」＝その粒が画素に
     * 足した色として別に照らす。</p>
     */
    private static TextureTarget solid;
    private static boolean solidCaptured;
    private static int lampCount;

    /** 粒の直前（AFTER_TRIPWIRE_BLOCKS）で覚えた、このフレームの射影・カメラ・補間の割合。 */
    private static final Matrix4f PROJECTION = new Matrix4f();
    private static Vec3 frameCamera = Vec3.ZERO;
    private static float framePartialTick;
    /** このフレームの光をもう描いたか（シェーダーパックの仕上げ前か、AFTER_LEVEL のどちらか一方で描く）。 */
    private static boolean renderedThisFrame;
    /** シェーダーパックの仕上げ前に路面を描いた。AFTER_LEVEL では光線だけを足す。 */
    private static boolean packSurfaceDone;
    /** このフレームの影の地図をもう描いたか（路面と光線を 2 回に分けて描くとき、2 回目は使い回す）。 */
    private static boolean shadowsDone;

    public static void onRenderLevel(LevelRenderStage event) {
        LevelRenderStage.Stage stage = event.getStage();
        if (stage == LevelRenderStage.Stage.AFTER_SKY) {
            // ミラーの描画中は鏡の視点が入ってくるので覚えない
            if (!MirrorRenderer.isRendering()) {
                VIEW.set(event.getModelViewMatrix());
                viewCaptured = true;
                solidCaptured = false;
                renderedThisFrame = false;
                packSurfaceDone = false;
                shadowsDone = false;
            }
            return;
        }
        if (!isActive() || MirrorRenderer.isRendering() || !viewCaptured) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        RenderTarget main = mc.getMainRenderTarget();

        if (stage == LevelRenderStage.Stage.AFTER_TRIPWIRE_BLOCKS) {
            // 粒の直前。ランプが無ければ写さない（写すぶんだけ無駄）
            lampCount = collect(level, event.getCamera().getPosition(), event.getPartialTick().getGameTimeDeltaPartialTick(true));
            PROJECTION.set(event.getProjectionMatrix());
            frameCamera = event.getCamera().getPosition();
            framePartialTick = event.getPartialTick().getGameTimeDeltaPartialTick(true);
            if (lampCount > 0) {
                solid = snapshot(solid, main);
                solidCaptured = true;
            }
            return;
        }
        if (stage != LevelRenderStage.Stage.AFTER_LEVEL) {
            return;
        }
        viewCaptured = false;
        // シェーダーパックの仕上げの前に描けていれば、ここでは描かない
        if (packSurfaceDone) {
            // 路面はパックの仕上げ前に入れた。光線は仕上がった絵に足す（PackMode 2）
            render(level, main, -1, 2.0F);
        } else if (!renderedThisFrame) {
            // パック使用中に仕上げの前へ入れなかった（設定で切った・パックの絵が読めない）ときは、
            // 仕上がった画面に路面も光の筋もまとめて重ねる（PackMode 3）
            render(level, main, -1, ShaderPacks.inUse() ? 3.0F : 0.0F);
        }
    }

    /**
     * シェーダーパック（Oculus / Iris）が仕上げ（composite・final）を流す<b>直前</b>に呼ばれる
     * （{@code IrisPipelineMixin}）。ここで仕上げ前の絵（colortex0）に光を入れれば、パックが霧・ブルーム・
     * トーンマップを一度だけ掛けてくれる。
     *
     * <p><b>Forge の {@code AFTER_LEVEL} は仕上げの後に飛ぶ</b>（{@code GameRenderer} から投げられ、
     * Iris の仕上げは {@code renderLevel} の最後）。そこで描いていた頃は、仕上がった絵（月明かり・霧・
     * トーンマップ済み）を明るくするしかなく、暗い所のブロックの色が残っていないので色褪せた。</p>
     *
     * <p>パックの絵が読めなければ何もしない（{@code AFTER_LEVEL} で今までどおり描かれる）。
     * GL の状態は Iris がこのあと自分の枠で描くので、書き込み先と描く範囲だけ元に戻す。</p>
     */
    public static void renderBeforePackComposite() {
        if (renderedThisFrame || !viewCaptured || !isActive() || MirrorRenderer.isRendering()
                || !com.maou.maoudrift.config.ClientConfig.headlightPackPreComposite) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            return;
        }
        int packScene = IrisScene.colorTexture();
        if (packScene < 0) {
            return;
        }
        int drawFramebuffer = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        int readFramebuffer = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        try {
            render(mc.level, mc.getMainRenderTarget(), packScene, 1.0F);
            packSurfaceDone = true;
        } finally {
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFramebuffer);
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFramebuffer);
            GlStateManager._viewport(viewport[0], viewport[1], viewport[2], viewport[3]);
        }
    }

    /**
     * 光を描く。{@code packScene} が 0 以上なら、シェーダーパックの仕上げ前の絵を読んでそこへ書き戻す。
     * 負なら主画面を写して主画面へ描く（パック無し、またはパックの絵が読めないとき）。
     */
    private static void render(ClientLevel level, RenderTarget main, int packScene, float packMode) {
        int count = lampCount;
        if (count == 0 || !solidCaptured) {
            return;
        }
        renderedThisFrame = true;
        float partialTick = framePartialTick;
        int width = main.width;
        int height = main.height;
        // 深度はパックを使っていても主画面のもの（Iris は Minecraft の深度をそのまま使う）
        copy = snapshot(copy, main);
        int packColor = packScene >= 0 ? IrisScene.copy(packScene) : -1;
        main.bindWrite(true);

        // 影。ブロックの格子を少し読み直してから、ランプから見た距離の地図を描く
        Vec3 camera = frameCamera;
        if (!shadowsDone) {
            HeadlightShadows.update(level, camera);
            HeadlightShadows.uploadLamps(LAMPS, count);
            HeadlightShadows.renderMap(shadowShader, count, camera, main);
            shadowsDone = true;
        }

        // 画面の座標から、カメラを原点にした世界の向きの座標へ戻す行列
        Matrix4f inverse = new Matrix4f(PROJECTION)
                .mul(VIEW)
                .invert();

        shader.setSampler("SceneSampler", packColor >= 0 ? packColor : copy.getColorTextureId());
        shader.setSampler("FinalDepthSampler", copy.getDepthTextureId());
        shader.setSampler("SolidSampler", packColor >= 0 ? packColor : solid.getColorTextureId());
        shader.setSampler("DepthSampler", solid.getDepthTextureId());
        shader.setSampler("ShadowSampler", HeadlightShadows.mapTexture());
        shader.setSampler("VoxelSampler", HeadlightShadows.voxelTexture());
        HeadlightShadows.setGridUniforms(shader, camera);
        shader.safeGetUniform("ShadowSize").set((float) HeadlightShadows.MAP_WIDTH,
                (float) HeadlightShadows.mapHeight(count));
        shader.safeGetUniform("InvViewProj").set(inverse);
        shader.setSampler("LampSampler", HeadlightShadows.lampTexture());
        shader.safeGetUniform("LampCount").set(count);
        shader.safeGetUniform("LightRange").set((float) com.maou.maoudrift.config.ClientConfig.headlightRange);
        shader.safeGetUniform("FogDensity").set(fogDensity(level, partialTick));
        shader.safeGetUniform("ScreenSize").set((float) width, (float) height);
        // 明るさは 1 本のつまみ（Ctrl+L）で、路面とビームに同じ割合で掛ける
        float brightness = (float) com.maou.maoudrift.config.ClientConfig.headlightBrightness;
        shader.safeGetUniform("SurfaceGain").set(SURFACE_GAIN * brightness);
        shader.safeGetUniform("VolumeGain").set(VOLUME_GAIN * brightness);
        shader.safeGetUniform("SmokeGain").set((float) com.maou.maoudrift.config.ClientConfig.headlightSmoke);
        // シェーダーパックの仕上げ前の絵に描くときは明るくし方を変える
        shader.safeGetUniform("PackMode").set(packMode);
        shader.safeGetUniform("PackContrast").set((float) com.maou.maoudrift.config.ClientConfig.headlightPackContrast);
        shader.safeGetUniform("PackTint").set((float) com.maou.maoudrift.config.ClientConfig.headlightPackTint);
        shader.safeGetUniform("PackAdd").set((float) com.maou.maoudrift.config.ClientConfig.headlightPackAdd);
        float[] lightColor = com.maou.maoudrift.config.ClientConfig.headlightColor.rgb();
        shader.safeGetUniform("LightColor").set(lightColor[0], lightColor[1], lightColor[2]);

        // 画面いっぱいに 1 枚。色はシェーダーが全部決めるので混色も深度も要らない
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableBlend();
        if (packScene >= 0) {
            IrisScene.bindForWrite(packScene);
        }
        RenderSystem.setShader(() -> shader);
        BufferBuilder builder = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION);
        builder.addVertex(-1.0F, -1.0F, 0.0F);
        builder.addVertex(1.0F, -1.0F, 0.0F);
        builder.addVertex(1.0F, 1.0F, 0.0F);
        builder.addVertex(-1.0F, 1.0F, 0.0F);
        BufferUploader.drawWithShader(builder.buildOrThrow());
        if (packScene >= 0) {
            main.bindWrite(true);
        }
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        if (!announced) {
            // 光が見えないときに「描いていない」のか「描いているが外れている」のかを切り分けるため
            announced = true;
            LOGGER.info("ヘッドライトを画素ごとに描き始めた（{} 灯、{}x{}）", count, width, height);
        }
    }

    /**
     * 主画面の色と深度を {@code target} へ写す（大きさが違えば作り直す）。
     *
     * <p>書いている最中の画面を同時に読むことはできないので、読むのは写しのほう。</p>
     */
    /**
     * このフレームのランプと影の地図を、タイヤの煙のシェーダー（{@code tire_smoke}）にも渡す。
     * 煙が路面や光線と<b>同じ配光・同じ影</b>で照らされるため。ランプを用意していないフレーム
     * （昼・ランプ無し・パック使用中に光を切ってある）は灯数 0 を渡す。
     *
     * <p>呼ぶのはこのフレームのヘッドライトを描いた後（{@link #shadowsDone} が立ってから）。</p>
     *
     * @return 渡した灯数
     */
    static int bindLampsForSmoke(ShaderInstance target) {
        int count = shadowsDone && solidCaptured && isActive() ? lampCount : 0;
        target.safeGetUniform("LampCount").set(count);
        if (count == 0) {
            return 0;
        }
        target.setSampler("LampSampler", HeadlightShadows.lampTexture());
        target.setSampler("ShadowSampler", HeadlightShadows.mapTexture());
        HeadlightShadows.setGridUniforms(target, frameCamera);
        target.safeGetUniform("ShadowSize").set((float) HeadlightShadows.MAP_WIDTH,
                (float) HeadlightShadows.mapHeight(count));
        target.safeGetUniform("LightRange").set((float) com.maou.maoudrift.config.ClientConfig.headlightRange);
        float[] lightColor = com.maou.maoudrift.config.ClientConfig.headlightColor.rgb();
        target.safeGetUniform("LightColor").set(lightColor[0], lightColor[1], lightColor[2]);
        // ヘッドライトの「煙の照らされ方」（既定 4）。粒のときと同じつまみで、体積の煙の明るさへ。
        // 既定で 3（周りの明るさの 3 倍）。照らされた煙は夜でもはっきり白く浮かぶ
        target.safeGetUniform("LampGain").set((float) com.maou.maoudrift.config.ClientConfig.headlightSmoke * 0.75F);
        return count;
    }

    private static TextureTarget snapshot(TextureTarget target, RenderTarget main) {
        int width = main.width;
        int height = main.height;
        if (target == null) {
            target = new TextureTarget(width, height, true, Minecraft.ON_OSX);
        } else if (target.width != width || target.height != height) {
            target.resize(width, height, Minecraft.ON_OSX);
        }
        // ステンシルの有無が違うと深度を写せない（形式が一致しないと blit が失敗する）
        ClientPlatform.matchStencil(main, target);
        GlStateManager._glBindFramebuffer(GL_READ_FRAMEBUFFER, main.frameBufferId);
        GlStateManager._glBindFramebuffer(GL_DRAW_FRAMEBUFFER, target.frameBufferId);
        GlStateManager._glBlitFrameBuffer(0, 0, width, height, 0, 0, width, height,
                GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT, GL_NEAREST);
        main.bindWrite(true);
        return target;
    }

    /** 近い車から順に、ヘッドライトを点けている車のランプを詰める。 */
    /** 車 1 台が出す光の数の上限（ヘッドライト 2 灯とナンバー灯 1 灯）。 */
    private static final int LAMPS_PER_CAR = 3;

    private static int collect(ClientLevel level, Vec3 camera, float partialTick) {
        List<CarEntity> cars = new ArrayList<>();
        for (Entity entity : level.entitiesForRendering()) {
            if (entity instanceof CarEntity car && car.isHeadlightOn() && !car.isGhost()
                    && car.position().distanceToSqr(camera) < collectDistance() * collectDistance()) {
                cars.add(car);
            }
        }
        cars.sort(Comparator.comparingDouble(car -> car.position().distanceToSqr(camera)));
        int wanted = com.maou.maoudrift.config.ClientConfig.headlightCars;
        int limit = wanted >= com.maou.maoudrift.config.ClientConfig.UNLIMITED_HEADLIGHT_CARS
                ? HeadlightShadows.maxLamps()
                : Math.min(HeadlightShadows.maxLamps(), Math.max(1, wanted) * LAMPS_PER_CAR);
        int count = 0;
        int taken = 0;
        for (CarEntity car : cars) {
            if (count >= limit || taken >= limit / LAMPS_PER_CAR) {
                break;
            }
            count += CarLights.collectLamps(car, partialTick, camera, LAMPS, count);
            taken++;
        }
        return Math.min(count, limit);
    }

    private static float fogDensity(ClientLevel level, float partialTick) {
        // 晴れの濃さは調整画面（Ctrl+L、HeadlightScreen）で動かせる。既定は CLEAR_FOG
        return (float) com.maou.maoudrift.config.ClientConfig.headlightFog + RAIN_FOG * level.getRainLevel(partialTick)
                + THUNDER_FOG * level.getThunderLevel(partialTick);
    }

    /** 明るさ 1.0 のときの、照らされた路面を何倍まで明るくするか。 */
    private static final float SURFACE_GAIN = 5.0F;
    /** 明るさ 1.0 のときの、霧の中のビームの強さ。 */
    private static final float VOLUME_GAIN = 120.0F;

    private static final int GL_READ_FRAMEBUFFER = 0x8CA8;
    private static final int GL_DRAW_FRAMEBUFFER = 0x8CA9;
    private static final int GL_COLOR_BUFFER_BIT = 0x4000;
    private static final int GL_DEPTH_BUFFER_BIT = 0x0100;
    private static final int GL_NEAREST = 0x2600;
}
