package com.maou.maoudrift.client;

import com.maou.maoudrift.entity.CarEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Saklar mesin (sisi klien).
 *
 * <ul>
 *   <li>Mobil kosong: mesin mati (suara mesin/knalpot/turbo diam).</li>
 *   <li>Ada pengemudi naik: mesin otomatis hidup. Turun: mesin mati lagi.</li>
 *   <li>Tombol B (TOGGLE_ENGINE): hidup/mati. Di dalam mobil = mobil yang dikendarai,
 *       di luar = mobil terdekat dalam jarak {@link #REACH} blok.</li>
 * </ul>
 */
public final class EngineSwitch {

    private static final double REACH = 8.0;
    private static final Map<CarEntity, Boolean> ON = new WeakHashMap<>();
    private static final Map<CarEntity, Boolean> OCCUPIED = new WeakHashMap<>();

    private EngineSwitch() {
    }

    public static boolean isOn(CarEntity car) {
        return ON.getOrDefault(car, false);
    }

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null) {
            return;
        }
        for (Entity e : level.entitiesForRendering()) {
            if (!(e instanceof CarEntity car) || car.isRemoved() || car.isGhost()) {
                continue;
            }
            boolean occupied = car.getControllingPassenger() != null;
            boolean was = OCCUPIED.getOrDefault(car, false);
            OCCUPIED.put(car, occupied);
            if (occupied && !was) {
                ON.put(car, true);
            } else if (!occupied && was) {
                ON.put(car, false);
            }
        }
        LocalPlayer player = mc.player;
        tickLights(mc, level, player);
        while (MaouDriftKeys.TOGGLE_ENGINE.consumeClick()) {
            if (player == null || mc.screen != null) {
                continue;
            }
            CarEntity target = player.getVehicle() instanceof CarEntity ridden ? ridden : nearest(level, player);
            if (target == null) {
                continue;
            }
            boolean next = !isOn(target);
            ON.put(target, next);
            player.displayClientMessage(Component.literal(next ? "Mesin: ON" : "Mesin: OFF"), true);
        }
    }

    private static void tickLights(Minecraft mc, ClientLevel level, LocalPlayer player) {
        while (MaouDriftKeys.TOGGLE_HEADLIGHTS.consumeClick()) {
            if (player == null || mc.screen != null || player.getVehicle() instanceof CarEntity) {
                continue;
            }
            CarEntity target = nearest(level, player);
            if (target == null) {
                continue;
            }
            boolean next = !target.outsideLights();
            target.setOutsideLights(next);
            player.displayClientMessage(Component.literal(next ? "Lampu: ON" : "Lampu: OFF"), true);
        }
    }

    private static CarEntity nearest(ClientLevel level, LocalPlayer player) {
        CarEntity best = null;
        double bestDist = REACH * REACH;
        for (Entity e : level.entitiesForRendering()) {
            if (e instanceof CarEntity car && !car.isRemoved() && !car.isGhost()) {
                double d = car.distanceToSqr(player);
                if (d < bestDist) {
                    bestDist = d;
                    best = car;
                }
            }
        }
        return best;
    }
}
