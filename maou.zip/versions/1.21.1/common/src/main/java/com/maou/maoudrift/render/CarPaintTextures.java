package com.maou.maoudrift.render;

import com.maou.maoudrift.MaouDrift;
import com.maou.maoudrift.car.CarId;
import com.maou.maoudrift.client.model.CarModel;
import com.maou.maoudrift.part.PartFitment;
import com.maou.maoudrift.platform.McIds;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Warna bodi bebas (RGB). id cat {@code custom_rrggbb} disinkronkan lewat paket cat yang sudah ada.
 *
 * <p>Tekstur bodi menyimpan warna cat di satu blok palet kecil (mis. 16x16 piksel) yang dipakai semua
 * permukaan cat. Blok itu dicari dengan membandingkan dua tekstur varian cat mobil (hanya blok itu yang
 * berbeda). Lalu tekstur varian pertama disalin dan blok palet diisi warna pilihan, jadi satu tekstur
 * dinamis per (mobil, warna). Dibatasi {@link #MAX} tekstur; yang tertua dibuang.</p>
 *
 * <p>Batasan: tekstur dinamis tidak punya pasangan {@code _s} (PBR shader pack) dan tanpa mipmap. Bila
 * blok palet tidak ketemu, dipakai tekstur cat bawaan.</p>
 */
public final class CarPaintTextures {

    public static final String PREFIX = "custom_";
    private static final int MAX = 6;
    /** Palet lebih besar dari ini dianggap bukan blok palet. */
    private static final int MAX_PALETTE_PIXELS = 64 * 64;

    private record Entry(ResourceLocation location, boolean owned) {
    }

    private static final Map<String, Entry> CACHE = new LinkedHashMap<>();
    /** id mobil -> {minX, minY, maxX, maxY} blok palet. */
    private static final Map<String, int[]> RECTS = new HashMap<>();
    private static int nextId;

    private CarPaintTextures() {
    }

    /** Tekstur bodi untuk mobil dan pemasangan ini (cat bawaan, atau tekstur RGB bebas). */
    public static ResourceLocation bodyTexture(CarModel model, CarId carId, PartFitment fitment) {
        ResourceLocation base = McIds.mc(model.bodyTexture(fitment));
        String id = fitment.paint();
        if (id == null || !id.startsWith(PREFIX) || id.length() != PREFIX.length() + 6) {
            return base;
        }
        List<CarModel.Paint> paints = model.paints();
        if (paints.size() < 2) {
            return base;
        }
        String hex = id.substring(PREFIX.length());
        String key = carId.path() + ":" + hex;
        Entry cached = CACHE.get(key);
        if (cached != null) {
            return cached.location();
        }
        int rgb;
        try {
            rgb = Integer.parseInt(hex, 16);
        } catch (NumberFormatException e) {
            return base;
        }
        ResourceLocation made = build(carId.path(), paints, rgb);
        CACHE.put(key, new Entry(made != null ? made : base, made != null));
        trim();
        return made != null ? made : base;
    }

    private static void trim() {
        int owned = 0;
        for (Entry entry : CACHE.values()) {
            if (entry.owned()) {
                owned++;
            }
        }
        Iterator<Entry> it = CACHE.values().iterator();
        while (owned > MAX && it.hasNext()) {
            Entry entry = it.next();
            if (entry.owned()) {
                Minecraft.getInstance().getTextureManager().release(entry.location());
                it.remove();
                owned--;
            }
        }
    }

    private static NativeImage read(com.maou.maoudrift.car.CarId texture) throws IOException {
        var resource = Minecraft.getInstance().getResourceManager().getResource(McIds.mc(texture));
        if (resource.isEmpty()) {
            throw new IOException("tidak ada tekstur: " + texture);
        }
        try (InputStream in = resource.get().open()) {
            return NativeImage.read(in);
        }
    }

    private static ResourceLocation build(String carPath, List<CarModel.Paint> paints, int rgb) {
        NativeImage image = null;
        NativeImage other = null;
        try {
            image = read(paints.get(0).texture());
            int[] rect = RECTS.get(carPath);
            if (rect == null) {
                other = read(paints.get(1).texture());
                rect = diffRect(image, other);
                if (rect == null) {
                    return null;
                }
                RECTS.put(carPath, rect);
            }
            int abgr = 0xFF000000 | ((rgb & 0xFF) << 16) | (rgb & 0xFF00) | ((rgb >> 16) & 0xFF);
            for (int y = rect[1]; y <= rect[3]; y++) {
                for (int x = rect[0]; x <= rect[2]; x++) {
                    image.setPixelRGBA(x, y, abgr);
                }
            }
            ResourceLocation location = ResourceLocation.fromNamespaceAndPath(MaouDrift.MODID,
                    "paint_baked/" + (nextId++));
            Minecraft.getInstance().getTextureManager().register(location, new DynamicTexture(image));
            image = null;
            return location;
        } catch (IOException | RuntimeException e) {
            return null;
        } finally {
            if (image != null) {
                image.close();
            }
            if (other != null) {
                other.close();
            }
        }
    }

    /** Kotak piksel yang berbeda antara dua tekstur. Null bila sama, ukuran beda, atau terlalu besar. */
    private static int[] diffRect(NativeImage a, NativeImage b) {
        if (a.getWidth() != b.getWidth() || a.getHeight() != b.getHeight()) {
            return null;
        }
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = -1;
        int maxY = -1;
        for (int y = 0; y < a.getHeight(); y++) {
            for (int x = 0; x < a.getWidth(); x++) {
                if (a.getPixelRGBA(x, y) != b.getPixelRGBA(x, y)) {
                    minX = Math.min(minX, x);
                    minY = Math.min(minY, y);
                    maxX = Math.max(maxX, x);
                    maxY = Math.max(maxY, y);
                }
            }
        }
        if (maxX < 0 || (maxX - minX + 1) * (maxY - minY + 1) > MAX_PALETTE_PIXELS) {
            return null;
        }
        return new int[] {minX, minY, maxX, maxY};
    }

    /** Dipanggil saat resource dimuat ulang. */
    public static void clearCache() {
        for (Entry entry : CACHE.values()) {
            if (entry.owned()) {
                Minecraft.getInstance().getTextureManager().release(entry.location());
            }
        }
        CACHE.clear();
        RECTS.clear();
    }
}
