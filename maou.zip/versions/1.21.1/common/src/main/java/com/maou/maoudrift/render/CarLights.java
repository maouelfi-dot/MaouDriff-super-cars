package com.maou.maoudrift.render;

import com.maou.maoudrift.entity.CarEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.util.Mth;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import com.maou.maoudrift.client.model.CarModel;
import com.maou.maoudrift.client.light.HeadlightBeam;
import com.maou.maoudrift.client.light.HeadlightAim;
import com.maou.maoudrift.client.Vec3d;
import com.maou.maoudrift.client.light.HeadlightGround;
import com.maou.maoudrift.client.BlockQuads;

/**
 * 灯火の描画。
 *
 * <p>4 つに分かれる:</p>
 * <ul>
 *   <li><b>レンズ</b> … {@code light_*} のオブジェクトを<b>明るさ最大</b>で描く。
 *       消灯時は車体と同じ明るさで、色だけ薄く残す</li>
 *   <li><b>路面の照り返し</b> … 配光（ロービームのカットオフ付き）を<b>実際のブロックの面</b>へ
 *       投影して明るくする（{@link #renderGround}）。<b>Minecraft には動的ライトが無い</b>ので
 *       世界の明るさは変わらないが、見た目の上では路面・段差・壁が照らされる</li>
 *   <li><b>光の筋</b> … ヘッドライトから伸びる薄い光の層（{@link #renderVolume}）</li>
 *   <li><b>光芒</b> … レンズの前に浮かべる光の滲み（{@link #renderGlows}）。
 *       正面から見たときだけ強く出る</li>
 * </ul>
 *
 * <p>どれも<b>周りが暗いときだけ濃くする</b>。昼間に出しっぱなしにすると
 * 白い板が浮いて見えるだけで、ヘッドライトには見えない。</p>
 *
 * <h2>座標</h2>
 *
 * <p>ここで扱う位置はすべて<b>車の補間位置を原点にした世界の向きの座標</b>。
 * レンズの位置と光軸は車体と同じ変換（{@link CarObjRenderer#applyRotations} と
 * {@link CarObjRenderer#applyBodyTransform}）から求めるので、<b>ノーズダイブで照射が手前へ
 * 寄り、スクワットで奥へ伸びる</b>。路面はブロックの座標から原点を引いて置く。</p>
 */
public final class CarLights {

    /** レンズの名前。Blender 側は役割ごとに 1 オブジェクトでよい（左右はミラーのままでよい）。 */
    public static final String HEAD = ObjModel.LIGHT_PREFIX + "head";
    public static final String TAIL = ObjModel.LIGHT_PREFIX + "tail";
    public static final String REVERSE = ObjModel.LIGHT_PREFIX + "reverse";

    /**
     * 点灯時のレンズの色。
     *
     * <p><b>テクスチャがレンズの色を持っていないときだけ</b>掛ける。UV が展開されている
     * レンズには {@link #TEXTURED_COLOR}（白）を掛けて、描かれた色をそのまま出す。</p>
     */
    private static final float[] HEAD_COLOR = {1.0F, 0.97F, 0.88F};
    private static final float[] TAIL_COLOR = {1.0F, 0.15F, 0.10F};
    private static final float[] REVERSE_COLOR = {1.0F, 1.0F, 1.0F};

    /** テクスチャに色が描かれているレンズへ掛ける色。明暗だけを残す。 */
    private static final float[] TEXTURED_COLOR = {1.0F, 1.0F, 1.0F};

    /** 消灯時にレンズへ掛ける暗さ。0 だと真っ黒になって穴に見える。 */
    private static final float OFF_DIM = 0.35F;
    /** テールランプは常時うっすら点いている。ブレーキで最大になる。 */
    private static final float TAIL_IDLE = 0.35F;

    /** 照らされた光の色（Ctrl+L で選ぶ。既定はハロゲン寄りの暖かい白）。書き換えないこと。 */
    private static float[] beamColor() {
        return com.maou.maoudrift.config.ClientConfig.headlightColor.rgb();
    }

    // ---- 配光 ----------------------------------------------------------------------
    // 配光の形と露出は core の HeadlightBeam（pattern・exposure・aimDown）


    // ---- 路面 ----------------------------------------------------------------------

    /** これより遠い車の路面は描かない。ブロックを数百個調べるので。 */
    private static final double GROUND_MAX_DISTANCE = 96.0;
    /** Mode ringan: tanpa hitungan cahaya ke tanah per blok dan tanpa shader piksel; hanya kerucut cahaya + kilau. */
    private static final boolean LITE = true;
    /**
     * 照らされた面を昼の姿へどこまで近づけるか。1 で昼と同じ明るさ。
     *
     * <p>1 にすると照らされた路面だけ真昼になって、夜の景色から浮く。</p>
     */
    private static final float LIT_MAX = 0.82F;
    /** 照らされた面に重ねる光の色味（加算）。これが無いと白昼の色のままで、ライトの暖かさが出ない。 */
    private static final float GROUND_ADD = 0.12F;
    /** テクスチャを持たない面（水面など）は加算だけで描くので、そのぶん強く足す。 */
    private static final float UNTEXTURED_BOOST = 2.5F;

    // ---- 光の筋 --------------------------------------------------------------------

    private static final double VOLUME_LENGTH = 34.0;
    private static final int VOLUME_RINGS = 7;
    private static final int VOLUME_SEGMENTS = 8;
    /** 根元の半径 [m]。レンズより少し大きい。 */
    private static final double VOLUME_START_RADIUS = 0.12;
    /** 横の広がりの半角。配光の広がりより狭い（空気が光って見えるのは芯の近くだけ）。 */
    private static final double VOLUME_SPREAD_X = Math.tan(Math.toRadians(7.5));
    /** 下の縁。上の縁はカットオフ。 */
    private static final double VOLUME_BOTTOM = -Math.tan(Math.toRadians(4.0));
    private static final float VOLUME_ALPHA = 0.24F;

    // ---- 光芒 ----------------------------------------------------------------------

    private static final double HEAD_GLOW_RADIUS = 0.42;
    private static final double TAIL_GLOW_RADIUS = 0.34;
    private static final double BRAKE_GLOW_RADIUS = 0.52;
    private static final double REVERSE_GLOW_RADIUS = 0.30;
    /** 横に流れる光の筋（アナモルフィック風）の半分の長さ [m]。 */
    private static final double STREAK_LENGTH = 1.9;
    private static final double STREAK_HEIGHT = 0.035;
    private static final int GLOW_SEGMENTS = 16;
    /** 光芒の半径方向の濃さ。中心が詰まっていて外へ長く尾を引く。 */
    private static final double[] GLOW_RING_RADIUS = {0.0, 0.16, 0.42, 1.0};
    private static final float[] GLOW_RING_ALPHA = {1.0F, 0.55F, 0.16F, 0.0F};

    /**
     * 明るい場所でも残す濃さの割合。
     *
     * <p>0 にすると昼間はまったく出なくなる。<b>出ていないのか、出ていて見えないのかが
     * 区別できなくなる</b>ので、光の筋と光芒は薄くても常に出す。路面だけは昼間 0 にする
     * （昼の路面を 1 割明るくしても誰にも見えず、ブロックを調べる分だけ損）。</p>
     */
    private static final float VOLUME_DAYLIGHT = 0.0F;
    private static final float GLOW_DAYLIGHT = 0.15F;

    /** 路面の形は 1 ティックに 1 度だけ調べ直す。車ごとに持つ。 */
    private static final Map<CarEntity, HeadlightGround.Field> FIELDS = new WeakHashMap<>();

    private CarLights() {
    }

    /** レンズを描く。点いていれば明るさ最大、消えていれば車体と同じ明るさで暗く。 */
    public static void renderLenses(CarEntity car, ObjModel model, PoseStack pose,
                                    MultiBufferSource buffer, int packedLight,
                                    net.minecraft.resources.ResourceLocation texture) {
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityCutoutNoCull(texture));
        java.util.Set<String> shown = shownParts(car, model);
        for (String name : model.roleNames(HEAD, shown)) {
            lens(model, pose, consumer, packedLight, name, HEAD_COLOR, car.isHeadlightOn() ? 1.0F : 0.0F);
        }
        for (String name : model.roleNames(TAIL, shown)) {
            lens(model, pose, consumer, packedLight, name, TAIL_COLOR,
                    car.isBrakeLightOn() ? 1.0F : (car.isHeadlightOn() ? TAIL_IDLE : 0.0F));
        }
        for (String name : model.roleNames(REVERSE, shown)) {
            lens(model, pose, consumer, packedLight, name, REVERSE_COLOR, car.isReverseLightOn() ? 1.0F : 0.0F);
        }
    }

    /** いま見せている部品の形。部品の中のライトは、その部品を付けているときだけ光る。 */
    private static java.util.Set<String> shownParts(CarEntity car, ObjModel body) {
        return CarModel.get(car.getCarId()).bodyParts(car.getEffectiveFitment(), body.optionalNames()).shown();
    }

    /** その役目のライトの位置（いつものライトと、見せている部品の中のライト）。 */
    private static java.util.List<Vec3> lampCenters(ObjModel body, String role, java.util.Set<String> shown) {
        java.util.List<String> names = body.roleNames(role, shown);
        if (names.size() == 1) {
            return body.groupSideCenters(names.get(0));
        }
        java.util.List<Vec3> centers = new java.util.ArrayList<>();
        for (String name : names) {
            centers.addAll(body.groupSideCenters(name));
        }
        return centers;
    }

    /**
     * レンズ 1 つ。
     *
     * <p><b>色を掛けるのは、テクスチャがレンズの色を持っていないときだけ。</b>UV が
     * 1 点に潰れているレンズはテクスチャの 1 画素を全面に写しているだけなので、赤いテール
     * ランプにするにはコード側で色を掛けるしかない。一方、Blender で展開してテクスチャに
     * 色を描いたなら、そこへさらに赤を掛けると<b>二重に掛かって暗い赤茶になる</b>。
     * 展開されているかで自動的に切り替える。</p>
     *
     * <p>どちらの場合も明暗（{@code tint} と明るさ最大）はそのまま効かせる。ここまで
     * 手放すと点いているのか消えているのか見て分からなくなる。</p>
     */
    private static void lens(ObjModel model, PoseStack pose, VertexConsumer consumer,
                             int packedLight, String name, float[] color, float power) {
        if (!model.hasGroup(name)) {
            return;
        }
        float[] hue = model.isUvMapped(name) ? TEXTURED_COLOR : color;
        // 点いている部分だけ明るさを最大にする。0xF000F0 は「空も松明も最大」
        int light = power > 0.0F ? LightTexture.FULL_BRIGHT : packedLight;
        float tint = OFF_DIM + (1.0F - OFF_DIM) * power;
        model.render(pose.last(), consumer, light, net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,
                hue[0] * tint, hue[1] * tint, hue[2] * tint, 1.0F, name);
    }

    /**
     * 光の効果（路面・光の筋・光芒）をまとめて描く。
     *
     * <p><b>車体もタイヤも描き終えた後に、姿勢を掛ける前の {@code pose} で呼ぶこと。</b>
     * どれも深度を書かないので、先に描くと後から描いた車体に上書きされ、
     * 車体の手前にあるはずの光芒が消える。</p>
     */
    public static void renderEffects(CarEntity car, CarModel carModel, float partialTick,
                                     PoseStack pose, MultiBufferSource buffer) {
        ObjModel body = ObjModel.get(carModel.bodyModel());
        java.util.Set<String> shown = shownParts(car, body);
        boolean head = car.isHeadlightOn() && !body.roleNames(HEAD, shown).isEmpty();
        boolean tail = (car.isHeadlightOn() || car.isBrakeLightOn()) && !body.roleNames(TAIL, shown).isEmpty();
        boolean reverse = car.isReverseLightOn() && !body.roleNames(REVERSE, shown).isEmpty();
        // Lampu kolong: kuat 0 kalau siang / dimatikan di config
        float underglow = underglowStrength(car);
        // Lampu alis (eyebrow): menyala bersama lampu utama bila diaktifkan di menu H
        boolean eyebrow = com.maou.maoudrift.config.ClientConfig.eyebrowEnabled && car.isHeadlightOn()
                && !body.roleNames(HEAD, shown).isEmpty();
        if (!head && !tail && !reverse && underglow <= 0.01F && !eyebrow) {
            return;
        }
        // Bila shader pack dipakai dan opsi "gambar cahaya saat shader" dimatikan, hanya lensa yang menyala.
        // Lampu kolong tetap boleh (ia punya pengaturan sendiri di maoudrift-underglow.toml)
        if (HeadlightVolume.suppressedByShaderPack()) {
            head = false;
            tail = false;
            reverse = false;
            if (underglow <= 0.01F && !eyebrow) {
                return;
            }
        }
        // パックが影を描いている最中（光源の視点）は、光を描いても意味がなく、記録すると変な場所に出る
        if (DeferredGlows.skip()) {
            return;
        }

        // 車体と同じ変換を、姿勢を掛ける前の原点から組み直す。ここで出た位置は
        // 「車の補間位置を原点にした世界の向き」になる
        PoseStack rig = new PoseStack();
        CarObjRenderer.applyRotations(car, rig, partialTick);
        CarObjRenderer.applyBodyTransform(carModel, car.getSpec(), rig);
        Matrix4f bodyMatrix = rig.last().pose();

        Vec3 origin = car.getPosition(partialTick);
        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        Vec3 eye = camera.getPosition().subtract(origin);
        float darkness = darkness(car);
        Matrix4f matrix = pose.last().pose();

        Vec3 forward = direction(bodyMatrix, 0.0F, 0.0F, -1.0F);
        Vec3 bodyUp = direction(bodyMatrix, 0.0F, 1.0F, 0.0F);

        Beam beam = null;
        if (head) {
            beam = Beam.of(transform(bodyMatrix, lampCenters(body, HEAD, shown)), forward, bodyUp,
                    suspensionPitch(car, partialTick));
        }

        // 掛け算の層は加算の層より先に、まとめて流す。種類の違うバッファを交互に取ると、
        // 共有のバッファがそのたびに流されてしまう
        // 画素ごとに解く光（HeadlightVolume）が使えるなら、路面と光の筋はそちらに任せる。
        // こちらは光芒だけ描く。使えないとき（シェーダーパックなど）はここで形を積んで代用する
        boolean screenSpace = !LITE && HeadlightVolume.isActive();
        if (beam != null && !screenSpace && !LITE && !MirrorRenderer.isRendering()) {
            float strength = darkness;
            if (strength > 0.03F && eye.lengthSqr() < GROUND_MAX_DISTANCE * GROUND_MAX_DISTANCE) {
                HeadlightGround.Field field = FIELDS.computeIfAbsent(car, key -> new HeadlightGround.Field());
                if (field.tick != car.tickCount) {
                    field.rebuild(blocks(car.level()), origin.x + beam.mid.x, origin.z + beam.mid.z, origin.y + beam.mid.y,
                            beam.axis.x, beam.axis.z);
                    field.tick = car.tickCount;
                }
                Lighting lit = renderGround(car.level(), field, beam, origin, strength);
                if (lit != null) {
                    if (lit.textured.count > 0) {
                        lit.textured.emit(pose.last(), buffer.getBuffer(MaouDriftRenderTypes.LIT_SURFACE));
                    }
                    if (lit.glow.count > 0) {
                        lit.glow.emit(matrix, buffer.getBuffer(MaouDriftRenderTypes.LIGHT_ADDITIVE), GROUND_ADD);
                    }
                }
                beam.field = field;
            }
        }

        // シェーダーパックを使っている間は、加算の RenderType がパックのプログラムに差し替えられて
        // 灰色の板に化ける。世界を描き終えた後に自前のシェーダーで足す（DeferredGlows）。パックが無ければ今までどおり
        VertexConsumer additive = DeferredGlows.active()
                ? DeferredGlows.recorder()
                : buffer.getBuffer(MaouDriftRenderTypes.LIGHT_ADDITIVE);
        // Lampu kolong (underglow): kolam cahaya lembut di tanah di sekeliling badan mobil
        if (underglow > 0.01F) {
            renderUnderglowPool(matrix, additive, body, bodyMatrix, car, underglow);
        }
        if (eyebrow) {
            List<Vec3> eyeLamps = beam != null ? beam.lamps : transform(bodyMatrix, lampCenters(body, HEAD, shown));
            List<List<Vec3>> eyeEdges = new java.util.ArrayList<>();
            for (String lampName : body.roleNames(HEAD, shown)) {
                for (List<Vec3> edge : body.groupUpperEdges(lampName)) {
                    eyeEdges.add(transform(bodyMatrix, edge));
                }
            }
            renderEyebrows(matrix, additive, eyeLamps, eyeEdges, forward, bodyUp, direction(bodyMatrix, 1.0F, 0.0F, 0.0F),
                    (car.tickCount + partialTick) / 20.0F, 0.55F + 0.45F * darkness);
        }
        // Sorot lampu depan versi ringan: pola cahaya di jalan (memanjang jauh ke depan) + seberkas tipis di udara.
        // Hanya digambar saat gelap dan untuk mobil yang masih dalam jarak sorot; siang hari semuanya dilewati.
        if (beam != null && !screenSpace) {
            boolean near = eye.lengthSqr() < LIGHT_RANGE * LIGHT_RANGE;
            if (near && darkness > 0.04F) {
                float k = (float) Math.max(0.0, Math.min(2.5, com.maou.maoudrift.config.ClientConfig.headlightBrightness));
                renderRoadBeam(car.level(), car, beam, origin, matrix, additive, darkness * k);
                renderVolume(matrix, additive, beam, beam.lamps.get(0), eye, origin, darkness * k, 1.0, 1.0F);
                renderVolume(matrix, additive, beam, beam.lamps.get(0), eye, origin, darkness * k, 0.38, 1.7F);
                if (beam.lamps.size() > 1) {
                    renderVolume(matrix, additive, beam, beam.lamps.get(beam.lamps.size() - 1), eye, origin, darkness * k, 1.0, 1.0F);
                    renderVolume(matrix, additive, beam, beam.lamps.get(beam.lamps.size() - 1), eye, origin, darkness * k, 0.38, 1.7F);
                }
            }
        }

        float glow = GLOW_DAYLIGHT + (1.0F - GLOW_DAYLIGHT) * darkness;
        if (head) {
            for (Vec3 lamp : beam.lamps) {
                renderGlows(matrix, additive, camera, lamp, forward, eye, HEAD_GLOW_RADIUS,
                        beamColor(), glow, true);
            }
        }
        if (tail) {
            boolean braking = car.isBrakeLightOn();
            // ブレーキは昼間でもはっきり見えないと困る。テールだけのときは夜だけ
            float power = braking ? Math.max(0.55F, glow) : glow * 0.55F;
            for (Vec3 lamp : transform(bodyMatrix, lampCenters(body, TAIL, shown))) {
                renderGlows(matrix, additive, camera, lamp, forward.scale(-1.0), eye,
                        braking ? BRAKE_GLOW_RADIUS : TAIL_GLOW_RADIUS, TAIL_COLOR, power, false);
            }
        }
        if (reverse) {
            for (Vec3 lamp : transform(bodyMatrix, lampCenters(body, REVERSE, shown))) {
                renderGlows(matrix, additive, camera, lamp, forward.scale(-1.0), eye,
                        REVERSE_GLOW_RADIUS, REVERSE_COLOR, glow * 0.8F, false);
            }
        }
    }

    /**
     * {@link HeadlightVolume} へ渡すランプを {@code out[start..]} に詰める。詰めた数を返す。
     *
     * <p>1 灯を行列 1 つで渡す。列 0 = 位置（カメラ基準）と届く距離、列 1 = 光軸と強さ、
     * 列 2 = 右、列 3 = 上。</p>
     *
     * <p>届く距離（列 0 の w）は今は使っていない（大きな値を入れる）。以前は光軸に沿って
     * 1 本だけ光線を飛ばして決めていたが、光軸から外れた幹が影を落とさなかった。
     * 遮るのは {@link HeadlightShadows} の仕事。</p>
     */
    static int collectLamps(CarEntity car, float partialTick, Vec3 camera, Matrix4f[] out, int start) {
        CarModel carModel = CarModel.get(car.getCarId());
        ObjModel body = ObjModel.get(carModel.bodyModel());
        java.util.Set<String> shown = shownParts(car, body);
        if (!car.isHeadlightOn()) {
            return 0;
        }
        if (body.roleNames(HEAD, shown).isEmpty()) {
            // ヘッドライトの無い車でもナンバー灯は灯る
            return collectPlateLamp(car, partialTick, camera, out, start, darkness(car));
        }
        PoseStack rig = new PoseStack();
        CarObjRenderer.applyRotations(car, rig, partialTick);
        CarObjRenderer.applyBodyTransform(carModel, car.getSpec(), rig);
        Matrix4f bodyMatrix = rig.last().pose();
        Beam beam = Beam.of(transform(bodyMatrix, lampCenters(body, HEAD, shown)),
                direction(bodyMatrix, 0.0F, 0.0F, -1.0F), direction(bodyMatrix, 0.0F, 1.0F, 0.0F),
                suspensionPitch(car, partialTick));
        Vec3 origin = car.getPosition(partialTick);
        float strength = darkness(car);
        int count = 0;
        for (Vec3 lamp : beam.lamps) {
            if (start + count >= out.length) {
                break;
            }
            Vec3 from = origin.add(lamp);
            // 壁で光を止めるのは影（HeadlightShadows）の仕事。ここでは切らない
            double reach = 1000.0;
            Vec3 at = from.subtract(camera);
            Matrix4f m = new Matrix4f();
            m.setColumn(0, new Vector4f((float) at.x, (float) at.y, (float) at.z, (float) reach));
            m.setColumn(1, new Vector4f((float) beam.axis.x, (float) beam.axis.y, (float) beam.axis.z, strength));
            m.setColumn(2, new Vector4f((float) beam.right.x, (float) beam.right.y, (float) beam.right.z, 0.0F));
            m.setColumn(3, new Vector4f((float) beam.up.x, (float) beam.up.y, (float) beam.up.z, 0.0F));
            out[start + count] = m;
            count++;
        }
        return count + collectPlateLamp(car, partialTick, camera, out, start + count, strength);
    }

    /** ナンバー灯がプレートの中央を照らす強さ（暗さ 1 のとき）。プレートの中央の露出が 6 割ほどになる値。 */
    private static final float PLATE_LAMP_STRENGTH = 3.5e-6F;
    /** ナンバー灯の届く距離 [m]。プレートとその下のバンパーの縁だけ。 */
    private static final float PLATE_LAMP_REACH = 0.45F;

    /**
     * ナンバー灯 1 灯を {@code out[start]} に詰める。詰めたら 1、無ければ 0。
     *
     * <p>行列の形はヘッドライトと同じだが、<b>列 3 の w を 1 にする</b>のが印。シェーダーはこれを見て、
     * カットオフの無い柔らかい円錐で、路面（プレートの面）だけを照らす（霧の光線・煙には出さない）。
     * 届く距離（列 0 の w）は {@link #PLATE_LAMP_REACH}。</p>
     */
    private static int collectPlateLamp(CarEntity car, float partialTick, Vec3 camera, Matrix4f[] out, int start,
                                        float strength) {
        if (start >= out.length || strength <= 0.0F) {
            return 0;
        }
        org.joml.Vector3f[] lamp = PlateRenderer.rearLamp(car, partialTick);
        if (lamp == null) {
            return 0;
        }
        Vec3 at = car.getPosition(partialTick).add(lamp[0].x(), lamp[0].y(), lamp[0].z()).subtract(camera);
        Matrix4f m = new Matrix4f();
        m.setColumn(0, new Vector4f((float) at.x, (float) at.y, (float) at.z, PLATE_LAMP_REACH));
        m.setColumn(1, new Vector4f(lamp[1].x(), lamp[1].y(), lamp[1].z(), strength * PLATE_LAMP_STRENGTH));
        m.setColumn(2, new Vector4f(lamp[2].x(), lamp[2].y(), lamp[2].z(), 0.0F));
        m.setColumn(3, new Vector4f(lamp[3].x(), lamp[3].y(), lamp[3].z(), 1.0F));
        out[start] = m;
        return 1;
    }

    /**
     * サスの沈み込みで生じた前後の傾き [rad]。正で鼻上げ（前のサスが長い）。
     *
     * <p>車体の姿勢（ピッチ）をそのまま使ってはいけない。あちらは坂の傾きも含むので、
     * 打ち消すと坂道で光が路面に沿わなくなる。前後のサスの長さの差なら、路面に対する
     * 車体の傾きだけが取れる——実車のオートレベライザーが車高センサーで測っているのと同じ量。</p>
     */
    private static double suspensionPitch(CarEntity car, float partialTick) {
        return HeadlightAim.suspensionPitch(car.carCore(), partialTick);
    }

    /** 周りの暗さ 0..1。松明の下や昼間は 0 に近づく。 */
    private static float darkness(CarEntity car) {
        BlockPos pos = car.blockPosition();
        int block = car.level().getBrightness(LightLayer.BLOCK, pos);
        // 空の明るさは時刻で減る。
        //
        // <b>int の getSkyDarken() を使ってはいけない。クライアントでは更新されず、夜でも 0 のまま</b>
        // （サーバーの tick でしか計算されない）。そのせいで夜なのに「真昼」と判定し、光の強さが
        // ずっと 0 だった——路面が照らされない、光線がうっすらとしか出ない、の原因はすべてこれ。
        // クライアントの getSkyDarken(partialTick) は時刻と雨から毎回求めた空の明るさで、
        // 夜 0.2・真昼 1.0 を返す
        float daylight = car.level() instanceof net.minecraft.client.multiplayer.ClientLevel client
                ? Mth.clamp((client.getSkyDarken(1.0F) - 0.2F) / 0.8F, 0.0F, 1.0F)
                : 1.0F;
        float sky = car.level().getBrightness(LightLayer.SKY, pos) * daylight;
        float ambient = Math.max(block, sky);
        return Mth.clamp(1.0F - ambient / 12.0F, 0.0F, 1.0F);
    }

    // ---- 配光 ----------------------------------------------------------------------

    /**
     * ヘッドライト 2 灯ぶんの位置と光軸。
     *
     * <p>光軸は<b>車体の前方を {@link HeadlightBeam#AIM_DOWN} だけ下げたもの</b>。レンズの平均法線から
     * 取ろうとしたことがあるが、箱で作ると法線が打ち消し合って向きが定まらない。</p>
     */
    private static final class Beam {
        final List<Vec3> lamps;
        final Vec3 mid;
        final Vec3 axis;
        final Vec3 right;
        final Vec3 up;
        /** 光の筋の裾を路面で消すのに使う。路面を調べていないときは null。 */
        HeadlightGround.Field field;
        /** 光軸と照度の計算（core）。 */
        private final HeadlightAim aim;

        private Beam(List<Vec3> lamps, HeadlightAim aim) {
            this.lamps = lamps;
            this.aim = aim;
            this.mid = vec3(aim.mid);
            this.axis = vec3(aim.axis);
            this.right = vec3(aim.right);
            this.up = vec3(aim.up);
        }

        /**
         * @param suspensionPitch サスの沈み込みで生じた前後の傾き [rad]。正で鼻上げ。
         *                        {@link HeadlightBeam#LEVELING} の割合だけ打ち消す
         */
        static Beam of(List<Vec3> lamps, Vec3 forward, Vec3 bodyUp, double suspensionPitch) {
            List<Vec3d> points = new java.util.ArrayList<>(lamps.size());
            for (Vec3 lamp : lamps) {
                points.add(vec3d(lamp));
            }
            return new Beam(lamps, HeadlightAim.of(points, vec3d(forward), vec3d(bodyUp), suspensionPitch));
        }

        /** 点 (x, y, z) の面（法線 n）が受ける照度。2 灯の合計（{@link HeadlightAim#illuminance}）。 */
        double illuminance(double x, double y, double z, double nx, double ny, double nz) {
            return aim.illuminance(x, y, z, nx, ny, nz);
        }

        private static Vec3 vec3(Vec3d v) {
            return new Vec3(v.x(), v.y(), v.z());
        }

        private static Vec3d vec3d(Vec3 v) {
            return new Vec3d(v.x, v.y, v.z);
        }
    }


    // ---- 路面 ----------------------------------------------------------------------

    /**
     * そのブロックの上面の高さ。当たり判定も液体も無ければ NaN。
     *
     * <p>液体も面として扱う（水面が照らされ、その下の水底は照らされない）。
     * 草や花は当たり判定が無いので素通りして、下の地面が照らされる。</p>
     *
     * <p><b>当たり判定だけで見てはいけない。</b>雪の層 1 枚や、道路 MOD のアスファルトの薄い層は
     * 当たり判定が空なので素通りしてしまい、<b>その下のブロックの上面</b>を照らすことになる。
     * そこは層に覆われて見えないので、路面がまったく明るくならなかった。見た目の形が
     * <b>1 ブロックの床いっぱいに広がっているもの</b>は面として数える（草花は広がっていないので素通り）。</p>
     */
    private static double surfaceTop(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (state.isAir()) {
            return Double.NaN;
        }
        double top = Double.NaN;
        VoxelShape shape = state.getCollisionShape(level, pos);
        if (!shape.isEmpty()) {
            top = pos.getY() + shape.max(net.minecraft.core.Direction.Axis.Y);
        }
        VoxelShape outline = state.getShape(level, pos);
        if (!outline.isEmpty()) {
            AABB box = outline.bounds();
            if (box.minX < 0.01 && box.maxX > 0.99 && box.minZ < 0.01 && box.maxZ > 0.99) {
                double visible = pos.getY() + box.maxY;
                top = Double.isNaN(top) ? visible : Math.max(top, visible);
            }
        }
        FluidState fluid = state.getFluidState();
        if (!fluid.isEmpty()) {
            double surface = pos.getY() + fluid.getHeight(level, pos);
            top = Double.isNaN(top) ? surface : Math.max(top, surface);
        }
        return top;
    }

    /** 路面を読む口（{@link HeadlightGround.Blocks}）。 */
    private static HeadlightGround.Blocks blocks(Level level) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        return new HeadlightGround.Blocks() {
            @Override
            public double surfaceTop(int x, int y, int z) {
                return CarLights.surfaceTop(level, pos.set(x, y, z));
            }

            @Override
            public double[] wallBox(int x, int y, int z) {
                pos.set(x, y, z);
                VoxelShape shape = level.getBlockState(pos).getCollisionShape(level, pos);
                AABB box = shape.isEmpty() ? new AABB(0, 0, 0, 1, 1, 1) : shape.bounds();
                return new double[]{box.minX, box.maxX, box.minZ, box.maxZ};
            }
        };
    }

    /**
     * 路面の照り返しを組み立てる（どこを照らすかは {@link HeadlightGround#light}）。ブロックごとに<b>上面と、光源を
     * 向いている側面</b>を、<b>そのブロックのモデルの面</b>として明るさ最大で描き直し、頂点ごとに配光から求めた濃さで重ねる。
     */
    private static Lighting renderGround(Level level, HeadlightGround.Field field, Beam beam, Vec3 origin,
                                         float strength) {
        double fx = beam.axis.x;
        double fz = beam.axis.z;
        double length = Math.hypot(fx, fz);
        if (length < 1.0E-4) {
            return null;
        }
        double mx = origin.x + beam.mid.x;
        double mz = origin.z + beam.mid.z;
        double lampY = origin.y + beam.mid.y;
        Lighting lighting = new Lighting(level, beam, origin, strength, mx, mz, fx / length, fz / length,
                -fz / length, fx / length);
        boolean any = HeadlightGround.light(field, new HeadlightGround.Faces() {
            @Override
            public boolean surface(int x, int y, int z, HeadlightGround.Side side) {
                return lighting.surface(x, y, z, switch (side) {
                    case UP -> Direction.UP;
                    case WEST -> Direction.WEST;
                    case EAST -> Direction.EAST;
                    case NORTH -> Direction.NORTH;
                    case SOUTH -> Direction.SOUTH;
                });
            }

            @Override
            public void quad(float x0, float y0, float z0, float x1, float y1, float z1,
                             float x2, float y2, float z2, float x3, float y3, float z3,
                             double nx, double ny, double nz) {
                lighting.quad(lighting.glow, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3, nx, ny, nz);
            }
        }, mx, mz, lampY, fx, fz);
        return any ? lighting : null;
    }

    /** 路面の頂点の明るさを求めて積む係。範囲の端で消していくのもここ。 */
    private static final class Lighting {
        /** 照らされた面を、そのブロックのテクスチャで描き直したもの。 */
        final Textured textured = new Textured();
        /** 光の色味として足すもの。 */
        final Vertices glow = new Vertices();
        final Level level;
        final BlockRenderDispatcher blocks = Minecraft.getInstance().getBlockRenderer();
        final BlockColors colors = Minecraft.getInstance().getBlockColors();
        final RandomSource random = RandomSource.create();
        final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        final Beam beam;
        final Vec3 origin;
        final float strength;
        final double mx;
        final double mz;
        final double fx;
        final double fz;
        final double rx;
        final double rz;

        Lighting(Level level, Beam beam, Vec3 origin, float strength, double mx, double mz,
                 double fx, double fz, double rx, double rz) {
            this.level = level;
            this.beam = beam;
            this.origin = origin;
            this.strength = strength;
            this.mx = mx;
            this.mz = mz;
            this.fx = fx;
            this.fz = fz;
            this.rx = rx;
            this.rz = rz;
        }

        void quad(Vertices out, float x0, float y0, float z0, float x1, float y1, float z1,
                  float x2, float y2, float z2, float x3, float y3, float z3,
                  double nx, double ny, double nz) {
            float b0 = brightness(x0, y0, z0, nx, ny, nz);
            float b1 = brightness(x1, y1, z1, nx, ny, nz);
            float b2 = brightness(x2, y2, z2, nx, ny, nz);
            float b3 = brightness(x3, y3, z3, nx, ny, nz);
            if (b0 + b1 + b2 + b3 < 0.01F) {
                return;
            }
            float k = UNTEXTURED_BOOST;
            out.add(x0 - origin.x, y0 - origin.y, z0 - origin.z, b0 * k);
            out.add(x1 - origin.x, y1 - origin.y, z1 - origin.z, b1 * k);
            out.add(x2 - origin.x, y2 - origin.y, z2 - origin.z, b2 * k);
            out.add(x3 - origin.x, y3 - origin.y, z3 - origin.z, b3 * k);
        }

        /**
         * ブロック (x, y, z) の、{@code side} を向いたモデルの面を照らして積む。
         *
         * <p>面の一覧は描画と同じ乱数の種で引く（草のように向きがばらつくテクスチャで、
         * 照らした面だけ模様がずれないように）。色の付く面（草の上面・葉）は
         * {@link BlockColors} で染める。付けないと草が灰色に光る。</p>
         *
         * @return モデルにその向きの面があったか（照らされたかどうかではない）
         */
        boolean surface(int x, int y, int z, Direction side) {
            pos.set(x, y, z);
            BlockState state = level.getBlockState(pos);
            if (state.getRenderShape() != RenderShape.MODEL) {
                return false;
            }
            BakedModel model = blocks.getBlockModel(state);
            // 面の取り出し方はローダーで違う（NeoForge はモデルデータと描画の層を通す）ので BlockQuads に任せる
            boolean[] found = {false};
            BlockQuads.collect(model, level, pos, state, side, random,
                    quad -> found[0] |= emitQuad(state, quad, x, y, z));
            return found[0];
        }

        private boolean emitQuad(BlockState state, BakedQuad quad, int x, int y, int z) {
            Direction face = quad.getDirection();
            double nx = face.getStepX();
            double ny = face.getStepY();
            double nz = face.getStepZ();
            int[] data = quad.getVertices();
            int stride = data.length / 4;
            float[] px = new float[4];
            float[] py = new float[4];
            float[] pz = new float[4];
            float[] b = new float[4];
            float sum = 0.0F;
            for (int v = 0; v < 4; v++) {
                int o = v * stride;
                px[v] = (float) (x + Float.intBitsToFloat(data[o]) + nx * HeadlightGround.SURFACE_LIFT);
                py[v] = (float) (y + Float.intBitsToFloat(data[o + 1]) + ny * HeadlightGround.SURFACE_LIFT);
                pz[v] = (float) (z + Float.intBitsToFloat(data[o + 2]) + nz * HeadlightGround.SURFACE_LIFT);
                b[v] = brightness(px[v], py[v], pz[v], nx, ny, nz);
                sum += b[v];
            }
            if (sum < 0.01F) {
                return true;
            }
            float r = 1.0F;
            float g = 1.0F;
            float bl = 1.0F;
            if (quad.isTinted()) {
                int color = colors.getColor(state, level, pos, quad.getTintIndex());
                r = (color >> 16 & 0xFF) / 255.0F;
                g = (color >> 8 & 0xFF) / 255.0F;
                bl = (color & 0xFF) / 255.0F;
            }
            // 光の色も掛ける。昼の白い光で描くと、照らされたところだけ真昼に見える
            r *= beamColor()[0];
            g *= beamColor()[1];
            bl *= beamColor()[2];
            for (int v = 0; v < 4; v++) {
                int o = v * stride;
                float rx = px[v] - (float) origin.x;
                float ry = py[v] - (float) origin.y;
                float rz = pz[v] - (float) origin.z;
                textured.add(rx, ry, rz, r, g, bl, b[v] * LIT_MAX,
                        Float.intBitsToFloat(data[o + 4]), Float.intBitsToFloat(data[o + 5]),
                        (float) nx, (float) ny, (float) nz);
                glow.add(rx, ry, rz, b[v]);
            }
            return true;
        }

        private float brightness(double x, double y, double z, double nx, double ny, double nz) {
            double dx = x - mx;
            double dz = z - mz;
            double f = dx * fx + dz * fz;
            double l = Math.abs(dx * rx + dz * rz);
            // 調べた範囲の奥と横の端でなめらかに消す。切れ目がそのまま見えないように
            double fade = (1.0 - HeadlightBeam.smoothstep(HeadlightGround.GROUND_FADE_START, HeadlightGround.GROUND_RANGE, f))
                    * (1.0 - HeadlightBeam.smoothstep(HeadlightGround.halfWidth(Math.max(0.0, f)) - 2.5, HeadlightGround.halfWidth(Math.max(0.0, f)), l));
            if (fade <= 0.0) {
                return 0.0F;
            }
            double e = beam.illuminance(x - origin.x, y - origin.y, z - origin.z, nx, ny, nz);
            return (float) (strength * fade) * HeadlightBeam.exposure(e);
        }
    }

    // ---- 光の筋 --------------------------------------------------------------------

    /**
     * 光の筋。<b>空気中の塵が光って見える</b>層を、光軸を包む殻として描く。
     *
     * <ul>
     *   <li><b>上の縁はカットオフ</b>で水平に近く、下の縁は路面へ向かって落ちる。
     *       ロービームの光は円錐ではなく、路面へ向かう薄い板に近い</li>
     *   <li><b>殻を斜めから見るほど薄くする。</b>光る空気の層は、厚みを真横から透かしたときに
     *       いちばん濃く、縁（接線方向から見る）では 0 になる。一様な濃さの殻は
     *       プラスチックの円錐に見える</li>
     *   <li><b>路面の近くで消す。</b>地面に潜った部分は深度テストで切られるので、
     *       そのままでは地面との交わりが硬い線になる</li>
     * </ul>
     */
    private static void renderVolume(Matrix4f matrix, VertexConsumer consumer, Beam beam, Vec3 lamp,
                                     Vec3 eye, Vec3 origin, float strength, double spreadScale, float alphaMul) {
        // Makin jauh dari kamera, sinar makin tipis (seperti sinar senter di udara berdebu)
        double camDist = eye.distanceTo(lamp);
        float farFade = (float) (1.0 - 0.75 * HeadlightBeam.smoothstep(12.0, 60.0, camDist));
        double centerY = (HeadlightBeam.CUTOFF + VOLUME_BOTTOM) / 2.0;
        double halfY = (HeadlightBeam.CUTOFF - VOLUME_BOTTOM) / 2.0;
        double[] ringZ = new double[VOLUME_RINGS];
        double[] ringGround = new double[VOLUME_RINGS];
        for (int r = 0; r < VOLUME_RINGS; r++) {
            // 根元を細かく刻む（形の変化が大きいのは手前）
            double z = VOLUME_LENGTH * Math.pow(r / (double) (VOLUME_RINGS - 1), 1.6) + 0.05;
            ringZ[r] = z;
            Vec3 center = lamp.add(beam.axis.scale(z));
            double ground = beam.field != null
                    ? beam.field.floorAt(origin.x + center.x, origin.z + center.z) - origin.y
                    : Double.NaN;
            ringGround[r] = ground;
        }

        float[][] ring0 = null;
        for (int r = 0; r < VOLUME_RINGS; r++) {
            float[][] ring = new float[VOLUME_SEGMENTS + 1][];
            double z = ringZ[r];
            double t = z / VOLUME_LENGTH;
            // 根元から立ち上がり、奥へ行くほど薄れる
            double along = Math.min(1.0, z / 2.0) * Math.pow(1.0 - t, 1.8) * Math.exp(-z / 16.0);
            double semiX = (VOLUME_START_RADIUS + z * VOLUME_SPREAD_X) * spreadScale;
            double semiY = (VOLUME_START_RADIUS * 0.55 + z * halfY) * spreadScale;
            for (int s = 0; s <= VOLUME_SEGMENTS; s++) {
                double phi = 2.0 * Math.PI * s / VOLUME_SEGMENTS;
                double cos = Math.cos(phi);
                double sin = Math.sin(phi);
                double lx = semiX * cos;
                double ly = z * centerY * (0.5 + 0.5 * spreadScale) + semiY * sin;
                Vec3 pos = lamp.add(beam.axis.scale(z)).add(beam.right.scale(lx)).add(beam.up.scale(ly));
                // 楕円の法線
                Vec3 normal = beam.right.scale(cos / semiX).add(beam.up.scale(sin / semiY)).normalize();
                Vec3 view = eye.subtract(pos).normalize();
                double facing = Math.abs(normal.dot(view));
                double ground = ringGround[r];
                double groundFade = Double.isNaN(ground) ? 1.0 : HeadlightBeam.smoothstep(0.0, 0.45, pos.y - ground);
                float alpha = (float) (VOLUME_ALPHA * alphaMul * farFade * strength * along * Math.pow(facing, 1.3) * groundFade);
                ring[s] = new float[]{(float) pos.x, (float) pos.y, (float) pos.z, alpha};
            }
            if (ring0 != null) {
                for (int s = 0; s < VOLUME_SEGMENTS; s++) {
                    colored(matrix, consumer, ring0[s], beamColor());
                    colored(matrix, consumer, ring0[s + 1], beamColor());
                    colored(matrix, consumer, ring[s + 1], beamColor());
                    colored(matrix, consumer, ring[s], beamColor());
                }
            }
            ring0 = ring;
        }
    }

    // ---- Lampu kolong (underglow) ---------------------------------------------------

    /** Jarak maksimum [m] dari kamera untuk menggambar sorot lampu. Lebih jauh dari ini dilewati (hemat GPU). */
    private static final double LIGHT_RANGE = 80.0;
    private static final int GLOW_POOL_SEGMENTS = 24;
    /** Posisi tiap lingkaran kolam relatif ke tepi badan [m] dan terangnya. Terang paling kuat di dekat tepi badan. */
    private static final double[] POOL_OFFSET = {-0.55, -0.20, 0.10, -1.0};
    private static final float[] POOL_ALPHA = {0.12F, 0.90F, 0.55F, 0.0F};

    /** Kekuatan lampu kolong 0..~1.5 untuk mobil ini. 0 = tidak digambar. */
    private static float underglowStrength(CarEntity car) {
        com.maou.maoudrift.config.UnderglowConfig.maybeReload();
        if (!com.maou.maoudrift.config.UnderglowConfig.enabled
                || !com.maou.maoudrift.config.ClientConfig.underglowEnabled) {
            return 0.0F;
        }
        // "Underglow ikut lampu utama" (menu H): menyala bersama tombol L. Kalau dimatikan, ikut
        // pengaturan lama di maoudrift-underglow.toml (menyala sendiri saat gelap, atau requireHeadlights).
        boolean linked = com.maou.maoudrift.config.ClientConfig.underglowWithHeadlights;
        boolean lightsOn = car.isHeadlightOnSynced();
        if ((linked || com.maou.maoudrift.config.UnderglowConfig.requireHeadlights) && !lightsOn) {
            return 0.0F;
        }
        float k = (float) com.maou.maoudrift.config.UnderglowConfig.intensity;
        if (com.maou.maoudrift.config.UnderglowConfig.onlyAtNight) {
            // gelap 0.35 -> mulai muncul, 0.85 -> penuh. Siang hari = 0 (tetap samar bila ikut lampu utama).
            float night = (float) HeadlightBeam.smoothstep(0.35, 0.85, darkness(car));
            k *= linked ? Math.max(night, 0.6F) : night;
        }
        return k;
    }

    /**
     * Kolam cahaya di tanah: cincin persegi membulat di sekeliling badan, paling terang dekat tepi badan lalu
     * memudar ke luar (gradasi lembut, bukan kotak kasar). Hanya ~170 titik, tanpa shader khusus.
     */
    private static void renderUnderglowPool(Matrix4f matrix, VertexConsumer consumer, ObjModel body,
                                            Matrix4f bodyMatrix, CarEntity car, float strength) {
        double[] b = body.bounds();
        if (b == null || b.length < 6) {
            return;
        }
        float[] rgb = com.maou.maoudrift.config.UnderglowConfig.color(car.getCarId().getPath());
        double cx = (b[0] + b[3]) * 0.5;
        double cz = (b[2] + b[5]) * 0.5;
        // tepi lampu = sedikit di dalam badan (roda & bumper menjorok)
        double hx = (b[3] - b[0]) * 0.5 * 0.86;
        double hz = (b[5] - b[2]) * 0.5 * 0.88;
        double y = b[1] + 0.025;
        double spread = com.maou.maoudrift.config.UnderglowConfig.spread;
        float peak = 0.8F * strength;
        Vector3f tmp = new Vector3f();
        float[][][] ring = new float[POOL_OFFSET.length][GLOW_POOL_SEGMENTS][];
        for (int r = 0; r < POOL_OFFSET.length; r++) {
            double off = POOL_OFFSET[r] < -0.9 ? spread : POOL_OFFSET[r];
            double a = Math.max(0.15, hx + off);
            double c = Math.max(0.15, hz + off);
            float alpha = POOL_ALPHA[r] * peak;
            for (int s = 0; s < GLOW_POOL_SEGMENTS; s++) {
                double t = 2.0 * Math.PI * s / GLOW_POOL_SEGMENTS;
                double ct = Math.cos(t);
                double st = Math.sin(t);
                // persegi membulat (superellipse pangkat 4)
                double px = a * Math.signum(ct) * Math.pow(Math.abs(ct), 0.5);
                double pz = c * Math.signum(st) * Math.pow(Math.abs(st), 0.5);
                bodyMatrix.transformPosition(tmp.set((float) (cx + px), (float) y, (float) (cz + pz)));
                ring[r][s] = new float[] {tmp.x, tmp.y, tmp.z, alpha};
            }
        }
        // Strip cahaya di bawah rocker kiri/kanan & bumper (terlihat jelas dari samping): tepi atas terang, memudar ke bawah
        double sx = hx * 0.93;
        double sz = hz * 0.93;
        double yTop = b[1] + 0.20;
        double yBot = b[1] + 0.03;
        double[][] corners = {{-sx, -sz}, {sx, -sz}, {sx, sz}, {-sx, sz}};
        float stripAlpha = Math.min(1.0F, 0.95F * strength);
        for (int c = 0; c < 4; c++) {
            double[] p0 = corners[c];
            double[] p1 = corners[(c + 1) % 4];
            float[] a0 = new float[3];
            float[] a1 = new float[3];
            float[] b1 = new float[3];
            float[] b0 = new float[3];
            bodyMatrix.transformPosition(tmp.set((float) (cx + p0[0]), (float) yTop, (float) (cz + p0[1])));
            a0[0] = tmp.x; a0[1] = tmp.y; a0[2] = tmp.z;
            bodyMatrix.transformPosition(tmp.set((float) (cx + p1[0]), (float) yTop, (float) (cz + p1[1])));
            a1[0] = tmp.x; a1[1] = tmp.y; a1[2] = tmp.z;
            bodyMatrix.transformPosition(tmp.set((float) (cx + p1[0]), (float) yBot, (float) (cz + p1[1])));
            b1[0] = tmp.x; b1[1] = tmp.y; b1[2] = tmp.z;
            bodyMatrix.transformPosition(tmp.set((float) (cx + p0[0]), (float) yBot, (float) (cz + p0[1])));
            b0[0] = tmp.x; b0[1] = tmp.y; b0[2] = tmp.z;
            poolVertex(matrix, consumer, new float[] {a0[0], a0[1], a0[2], stripAlpha}, rgb);
            poolVertex(matrix, consumer, new float[] {a1[0], a1[1], a1[2], stripAlpha}, rgb);
            poolVertex(matrix, consumer, new float[] {b1[0], b1[1], b1[2], 0.0F}, rgb);
            poolVertex(matrix, consumer, new float[] {b0[0], b0[1], b0[2], 0.0F}, rgb);
            // sisi dalam (supaya terlihat dari dua arah)
            poolVertex(matrix, consumer, new float[] {b0[0], b0[1], b0[2], 0.0F}, rgb);
            poolVertex(matrix, consumer, new float[] {b1[0], b1[1], b1[2], 0.0F}, rgb);
            poolVertex(matrix, consumer, new float[] {a1[0], a1[1], a1[2], stripAlpha}, rgb);
            poolVertex(matrix, consumer, new float[] {a0[0], a0[1], a0[2], stripAlpha}, rgb);
        }
        for (int r = 0; r < POOL_OFFSET.length - 1; r++) {
            for (int s = 0; s < GLOW_POOL_SEGMENTS; s++) {
                int n = (s + 1) % GLOW_POOL_SEGMENTS;
                poolVertex(matrix, consumer, ring[r][s], rgb);
                poolVertex(matrix, consumer, ring[r][n], rgb);
                poolVertex(matrix, consumer, ring[r + 1][n], rgb);
                poolVertex(matrix, consumer, ring[r + 1][s], rgb);
            }
        }
    }

    private static void poolVertex(Matrix4f matrix, VertexConsumer consumer, float[] v, float[] rgb) {
        consumer.addVertex(matrix, v[0], v[1], v[2]).setColor(rgb[0], rgb[1], rgb[2], Math.min(1.0F, v[3]));
    }

    // ---- Lampu alis (eyebrow) -------------------------------------------------------

    /** Setengah panjang garis [m], tinggi di atas pusat lensa, miringnya ujung luar, tebal inti & tebal cahaya lembut. */
    private static final float EYE_HALF = 0.14F;
    private static final float EYE_LIFT = 0.095F;
    private static final float EYE_TILT = 0.022F;
    private static final float EYE_CORE = 0.008F;
    private static final float EYE_SOFT = 0.034F;
    private static final float EYE_FORWARD = 0.03F;

    /**
     * Garis LED di atas tiap lampu depan: beberapa quad terang (tanpa shader, tanpa tekstur). Ujung dalam sedikit
     * lebih tinggi dari ujung luar supaya terlihat seperti alis. Gaya dihitung dari waktu saja.
     */
    private static void renderEyebrows(Matrix4f matrix, VertexConsumer consumer, List<Vec3> lamps,
                                       List<List<Vec3>> edges, Vec3 forward,
                                       Vec3 up, Vec3 right, float time, float strength) {
        float r;
        float g;
        float b;
        float power = strength;
        com.maou.maoudrift.config.EyebrowStyle style = com.maou.maoudrift.config.ClientConfig.eyebrowStyle;
        if (style == com.maou.maoudrift.config.EyebrowStyle.RAINBOW) {
            float h = (time * 0.25F) % 1.0F * 6.0F;
            r = Math.max(0.0F, Math.min(1.0F, Math.abs(h - 3.0F) - 1.0F));
            g = Math.max(0.0F, Math.min(1.0F, 2.0F - Math.abs(h - 2.0F)));
            b = Math.max(0.0F, Math.min(1.0F, 2.0F - Math.abs(h - 4.0F)));
        } else {
            com.maou.maoudrift.config.EyebrowColor color = com.maou.maoudrift.config.ClientConfig.eyebrowColor;
            if (color == com.maou.maoudrift.config.EyebrowColor.CUSTOM) {
                r = (float) com.maou.maoudrift.config.ClientConfig.eyebrowRed;
                g = (float) com.maou.maoudrift.config.ClientConfig.eyebrowGreen;
                b = (float) com.maou.maoudrift.config.ClientConfig.eyebrowBlue;
            } else {
                float[] rgb = color.rgb();
                r = rgb[0];
                g = rgb[1];
                b = rgb[2];
            }
            if (style == com.maou.maoudrift.config.EyebrowStyle.PULSE) {
                power *= 0.65F + 0.35F * (float) Math.sin(time * 4.0F);
            }
        }
        float ux = (float) up.x;
        float uy = (float) up.y;
        float uz = (float) up.z;
        float fx = (float) forward.x;
        float fy = (float) forward.y;
        float fz = (float) forward.z;
        float rx = (float) right.x;
        float ry = (float) right.y;
        float rz = (float) right.z;
        if (!edges.isEmpty()) {
            // Mengikuti kontur tepi atas lampu depan yang sebenarnya (seperti strip LED DRL pada lampu aftermarket)
            final float lift = 0.022F;
            final float fwd = 0.012F;
            for (List<Vec3> edge : edges) {
                for (int i = 0; i + 1 < edge.size(); i++) {
                    Vec3 p = edge.get(i);
                    Vec3 q = edge.get(i + 1);
                    float ax = (float) p.x + ux * lift + fx * fwd;
                    float ay = (float) p.y + uy * lift + fy * fwd;
                    float az = (float) p.z + uz * lift + fz * fwd;
                    float bx = (float) q.x + ux * lift + fx * fwd;
                    float by = (float) q.y + uy * lift + fy * fwd;
                    float bz = (float) q.z + uz * lift + fz * fwd;
                    eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, ux * 0.006F, uy * 0.006F, uz * 0.006F,
                            ux * 0.006F, uy * 0.006F, uz * 0.006F, r, g, b, Math.min(1.0F, power * 1.2F),
                            Math.min(1.0F, power * 1.2F));
                    for (int axis = 0; axis < 2; axis++) {
                        float dx = (axis == 0 ? ux : fx) * 0.026F;
                        float dy = (axis == 0 ? uy : fy) * 0.026F;
                        float dz = (axis == 0 ? uz : fz) * 0.026F;
                        eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, 0.0F, 0.0F, 0.0F, dx, dy, dz, r, g, b,
                                power * 0.45F, 0.0F);
                        eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, 0.0F, 0.0F, 0.0F, -dx, -dy, -dz, r, g, b,
                                power * 0.45F, 0.0F);
                    }
                }
            }
            return;
        }
        double mid = 0.0;
        for (Vec3 lamp : lamps) {
            mid += lamp.x * right.x + lamp.y * right.y + lamp.z * right.z;
        }
        mid /= Math.max(1, lamps.size());
        for (Vec3 lamp : lamps) {
            float side = lamp.x * right.x + lamp.y * right.y + lamp.z * right.z - mid >= 0.0 ? 1.0F : -1.0F;
            float cx = (float) lamp.x + ux * EYE_LIFT + fx * EYE_FORWARD;
            float cy = (float) lamp.y + uy * EYE_LIFT + fy * EYE_FORWARD;
            float cz = (float) lamp.z + uz * EYE_LIFT + fz * EYE_FORWARD;
            // ujung dalam (ke arah tengah mobil) naik, ujung luar turun
            float ax = cx - side * rx * EYE_HALF + ux * EYE_TILT;
            float ay = cy - side * ry * EYE_HALF + uy * EYE_TILT;
            float az = cz - side * rz * EYE_HALF + uz * EYE_TILT;
            float bx = cx + side * rx * EYE_HALF - ux * EYE_TILT;
            float by = cy + side * ry * EYE_HALF - uy * EYE_TILT;
            float bz = cz + side * rz * EYE_HALF - uz * EYE_TILT;
            // inti terang
            eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, ux * EYE_CORE, uy * EYE_CORE, uz * EYE_CORE,
                    ux * EYE_CORE, uy * EYE_CORE, uz * EYE_CORE, r, g, b, Math.min(1.0F, power * 1.2F), Math.min(1.0F, power * 1.2F));
            // cahaya lembut (tegak dan mendatar): pusat terang, tepi memudar
            for (int axis = 0; axis < 2; axis++) {
                float dx = (axis == 0 ? ux : fx) * EYE_SOFT;
                float dy = (axis == 0 ? uy : fy) * EYE_SOFT;
                float dz = (axis == 0 ? uz : fz) * EYE_SOFT;
                eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, 0.0F, 0.0F, 0.0F, dx, dy, dz, r, g, b, power * 0.45F, 0.0F);
                eyeQuad(matrix, consumer, ax, ay, az, bx, by, bz, 0.0F, 0.0F, 0.0F, -dx, -dy, -dz, r, g, b, power * 0.45F, 0.0F);
            }
        }
    }

    /**
     * Satu quad: sisi a-b ditambah (offset near) lalu (offset far) di sisi seberangnya.
     * Alpha {@code nearAlpha} di sisi garis pusat, {@code farAlpha} di sisi offset.
     */
    private static void eyeQuad(Matrix4f matrix, VertexConsumer consumer,
                                float ax, float ay, float az, float bx, float by, float bz,
                                float nx, float ny, float nz, float fx, float fy, float fz,
                                float r, float g, float b, float centerAlpha, float edgeAlpha) {
        consumer.addVertex(matrix, ax - nx, ay - ny, az - nz).setColor(r, g, b, centerAlpha);
        consumer.addVertex(matrix, bx - nx, by - ny, bz - nz).setColor(r, g, b, centerAlpha);
        consumer.addVertex(matrix, bx + fx, by + fy, bz + fz).setColor(r, g, b, edgeAlpha);
        consumer.addVertex(matrix, ax + fx, ay + fy, az + fz).setColor(r, g, b, edgeAlpha);
    }

    // ---- Sorot lampu depan ringan (pola cahaya di jalan) -----------------------------

    /** Jarak baris-baris pola cahaya dari lampu [m]. Memanjang jauh ke depan, rapat di dekat mobil. */
    private static final double[] ROAD_DIST = {1.5, 3.5, 6.5, 10.5, 15.5, 21.5, 29.0, 38.0, 48.0, 58.0};
    private static final int ROAD_ROWS = ROAD_DIST.length;
    /** Titik melintang: -1 .. 1 dari tengah sorot, dan terangnya. */
    private static final double[] ROAD_U = {-1.0, -0.55, 0.0, 0.55, 1.0};
    private static final float[] ROAD_U_ALPHA = {0.0F, 0.70F, 1.0F, 0.70F, 0.0F};
    private static final float ROAD_ALPHA = 0.38F;

    private static final class RoadCache {
        int tick = Integer.MIN_VALUE;
        final double[] ground = new double[ROAD_ROWS];
    }

    private static final Map<CarEntity, RoadCache> ROAD = new WeakHashMap<>();

    /**
     * Pola cahaya di jalan, selebar sorot lampu asli dan sepanjang ~58 m, mengikuti tinggi tanah (tiap baris
     * dicek tinggi tanahnya sekali per tick). Terangnya jatuh mengikuti jarak (hukum kuadrat terbalik),
     * jadi jelas dan terang dekat mobil lalu memudar natural ke kejauhan. Hanya ~200 titik per mobil.
     */
    private static void renderRoadBeam(Level level, CarEntity car, Beam beam, Vec3 origin, Matrix4f matrix,
                                       VertexConsumer consumer, float strength) {
        double fx = beam.axis.x;
        double fz = beam.axis.z;
        double length = Math.hypot(fx, fz);
        if (length < 1.0E-4) {
            return;
        }
        fx /= length;
        fz /= length;
        double rx = -fz;
        double rz = fx;
        double baseX = origin.x + beam.mid.x;
        double baseZ = origin.z + beam.mid.z;
        double lampY = origin.y + beam.mid.y;

        RoadCache cache = ROAD.computeIfAbsent(car, key -> new RoadCache());
        if (cache.tick != car.tickCount) {
            cache.tick = car.tickCount;
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
            double previous = lampY - 0.7;
            for (int i = 0; i < ROAD_ROWS; i++) {
                int x = Mth.floor(baseX + fx * ROAD_DIST[i]);
                int z = Mth.floor(baseZ + fz * ROAD_DIST[i]);
                previous = findGround(level, pos, x, z, lampY, previous);
                cache.ground[i] = previous;
            }
        }

        float[] color = beamColor();
        float[][] row = new float[ROAD_U.length][];
        float[][] prev = null;
        for (int i = 0; i < ROAD_ROWS; i++) {
            double d = ROAD_DIST[i];
            double halfWidth = Math.min(10.0, 1.2 + 0.20 * d);
            double falloff = 1.0 / (1.0 + (d / 14.0) * (d / 14.0));
            // ujung terjauh memudar sampai 0 supaya tidak ada tepi keras
            double end = i == ROAD_ROWS - 1 ? 0.0 : (i == ROAD_ROWS - 2 ? 0.6 : 1.0);
            // dekat bumper sedikit lebih redup (sebagian tertutup kap)
            double near = i == 0 ? 0.65 : 1.0;
            float a = (float) (ROAD_ALPHA * strength * falloff * end * near);
            double y = cache.ground[i] + 0.035 - origin.y;
            row = new float[ROAD_U.length][];
            for (int j = 0; j < ROAD_U.length; j++) {
                double px = baseX + fx * d + rx * ROAD_U[j] * halfWidth - origin.x;
                double pz = baseZ + fz * d + rz * ROAD_U[j] * halfWidth - origin.z;
                row[j] = new float[] {(float) px, (float) y, (float) pz, a * ROAD_U_ALPHA[j]};
            }
            if (prev != null) {
                for (int j = 0; j < ROAD_U.length - 1; j++) {
                    roadVertex(matrix, consumer, prev[j], color);
                    roadVertex(matrix, consumer, prev[j + 1], color);
                    roadVertex(matrix, consumer, row[j + 1], color);
                    roadVertex(matrix, consumer, row[j], color);
                }
            }
            prev = row;
        }
    }

    private static void roadVertex(Matrix4f matrix, VertexConsumer consumer, float[] v, float[] color) {
        consumer.addVertex(matrix, v[0], v[1], v[2]).setColor(color[0], color[1], color[2], Math.min(1.0F, v[3]));
    }

    /** Tinggi permukaan tanah di kolom (x, z) dekat tinggi lampu. Tidak ketemu = pakai tinggi baris sebelumnya. */
    private static double findGround(Level level, BlockPos.MutableBlockPos pos, int x, int z, double lampY,
                                     double fallback) {
        int top = Mth.floor(lampY) + 2;
        int bottom = Mth.floor(lampY) - 6;
        for (int y = top; y >= bottom; y--) {
            double t = surfaceTop(level, pos.set(x, y, z));
            if (!Double.isNaN(t) && t <= lampY + 1.3) {
                return t;
            }
        }
        return fallback;
    }

    private static void colored(Matrix4f matrix, VertexConsumer consumer, float[] v, float[] color) {
        consumer.addVertex(matrix, v[0], v[1], v[2]).setColor(color[0], color[1], color[2], v[3]);
    }

    // ---- 光芒 ----------------------------------------------------------------------

    /**
     * レンズの前に浮かぶ光の滲み。
     *
     * <p>カメラの方を向いた円盤で、<b>ランプの正面から見たときだけ</b>強く出る
     * （横や後ろから見たヘッドライトは眩しくない）。深度テストはするので、壁や他の車の
     * 陰に入れば隠れる。レンズに埋もれないよう、カメラ側へ少し浮かせる。</p>
     */
    private static void renderGlows(Matrix4f matrix, VertexConsumer consumer, Camera camera, Vec3 lamp,
                                    Vec3 facing, Vec3 eye, double radius, float[] color, float strength,
                                    boolean streak) {
        Vec3 toEye = eye.subtract(lamp);
        double distance = toEye.length();
        if (distance < 0.5) {
            return;
        }
        toEye = toEye.scale(1.0 / distance);
        double visibility = HeadlightBeam.smoothstep(-0.05, 0.55, facing.dot(toEye));
        float alpha = (float) (strength * visibility);
        if (alpha < 0.005F) {
            return;
        }
        Vector3f left = camera.getLeftVector();
        Vector3f upVector = camera.getUpVector();
        Vec3 right = new Vec3(-left.x(), -left.y(), -left.z());
        Vec3 up = new Vec3(upVector.x(), upVector.y(), upVector.z());
        Vec3 center = lamp.add(toEye.scale(Math.min(0.35, distance * 0.5)));

        for (int r = 0; r < GLOW_RING_RADIUS.length - 1; r++) {
            double r0 = GLOW_RING_RADIUS[r] * radius;
            double r1 = GLOW_RING_RADIUS[r + 1] * radius;
            float a0 = GLOW_RING_ALPHA[r] * alpha;
            float a1 = GLOW_RING_ALPHA[r + 1] * alpha;
            for (int s = 0; s < GLOW_SEGMENTS; s++) {
                double p0 = 2.0 * Math.PI * s / GLOW_SEGMENTS;
                double p1 = 2.0 * Math.PI * (s + 1) / GLOW_SEGMENTS;
                glowVertex(matrix, consumer, center, right, up, Math.cos(p0) * r0, Math.sin(p0) * r0, color, a0);
                glowVertex(matrix, consumer, center, right, up, Math.cos(p1) * r0, Math.sin(p1) * r0, color, a0);
                glowVertex(matrix, consumer, center, right, up, Math.cos(p1) * r1, Math.sin(p1) * r1, color, a1);
                glowVertex(matrix, consumer, center, right, up, Math.cos(p0) * r1, Math.sin(p0) * r1, color, a1);
            }
        }

        if (streak) {
            // 横に流れる細い光。夜に正面から見たときにだけ効く
            float a = alpha * 0.35F;
            for (int side = -1; side <= 1; side += 2) {
                double end = side * STREAK_LENGTH * radius / HEAD_GLOW_RADIUS;
                for (int half = -1; half <= 1; half += 2) {
                    double edge = half * STREAK_HEIGHT;
                    glowVertex(matrix, consumer, center, right, up, 0.0, 0.0, color, a);
                    glowVertex(matrix, consumer, center, right, up, end, 0.0, color, 0.0F);
                    glowVertex(matrix, consumer, center, right, up, end, edge, color, 0.0F);
                    glowVertex(matrix, consumer, center, right, up, 0.0, edge, color, 0.0F);
                }
            }
        }
    }

    private static void glowVertex(Matrix4f matrix, VertexConsumer consumer, Vec3 center, Vec3 right, Vec3 up,
                                   double x, double y, float[] color, float alpha) {
        consumer.addVertex(matrix,
                        (float) (center.x + right.x * x + up.x * y),
                        (float) (center.y + right.y * x + up.y * y),
                        (float) (center.z + right.z * x + up.z * y))
                .setColor(color[0], color[1], color[2], alpha);
    }

    // ---- 小道具 --------------------------------------------------------------------

    /** 路面の頂点（位置と明るさ）。掛け算と加算の 2 層へ同じものを流すので、いったん溜める。 */
    private static final class Vertices {
        float[] data = new float[4096];
        int count;

        void add(double x, double y, double z, float brightness) {
            if ((count + 1) * 4 > data.length) {
                data = Arrays.copyOf(data, data.length * 2);
            }
            int o = count * 4;
            data[o] = (float) x;
            data[o + 1] = (float) y;
            data[o + 2] = (float) z;
            data[o + 3] = brightness;
            count++;
        }

        /** 加算の層へ流す。明るさを α に入れる（加算は色 × α を足す）。 */
        void emit(Matrix4f matrix, VertexConsumer consumer, float gain) {
            for (int v = 0; v < count; v++) {
                int o = v * 4;
                consumer.addVertex(matrix, data[o], data[o + 1], data[o + 2])
                        .setColor(beamColor()[0], beamColor()[1], beamColor()[2], Math.min(1.0F, data[o + 3] * gain));
            }
        }
    }

    /** 照らされた面の頂点（位置・色・濃さ・UV・法線）。 */
    private static final class Textured {
        private static final int STRIDE = 12;
        float[] data = new float[STRIDE * 1024];
        int count;

        void add(float x, float y, float z, float r, float g, float b, float a,
                 float u, float v, float nx, float ny, float nz) {
            if ((count + 1) * STRIDE > data.length) {
                data = Arrays.copyOf(data, data.length * 2);
            }
            int o = count * STRIDE;
            data[o] = x;
            data[o + 1] = y;
            data[o + 2] = z;
            data[o + 3] = r;
            data[o + 4] = g;
            data[o + 5] = b;
            data[o + 6] = a;
            data[o + 7] = u;
            data[o + 8] = v;
            data[o + 9] = nx;
            data[o + 10] = ny;
            data[o + 11] = nz;
            count++;
        }

        /** 明るさ最大（{@code FULL_BRIGHT}）で流す。暗さは α が受け持つ。 */
        void emit(PoseStack.Pose pose, VertexConsumer consumer) {
            Matrix4f matrix = pose.pose();
            Matrix3f normal = pose.normal();
            Vector3f n = new Vector3f();
            for (int v = 0; v < count; v++) {
                int o = v * STRIDE;
                normal.transform(n.set(data[o + 9], data[o + 10], data[o + 11]));
                consumer.addVertex(matrix, data[o], data[o + 1], data[o + 2])
                        .setColor(data[o + 3], data[o + 4], data[o + 5], data[o + 6])
                        .setUv(data[o + 7], data[o + 8])
                        .setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(LightTexture.FULL_BRIGHT)
                        .setNormal(n.x, n.y, n.z);
            }
        }
    }

    private static List<Vec3> transform(Matrix4f matrix, List<Vec3> points) {
        return points.stream().map(p -> {
            Vector3f v = matrix.transformPosition(new Vector3f((float) p.x, (float) p.y, (float) p.z));
            return new Vec3(v.x(), v.y(), v.z());
        }).toList();
    }

    private static Vec3 direction(Matrix4f matrix, float x, float y, float z) {
        Vector3f v = matrix.transformDirection(new Vector3f(x, y, z)).normalize();
        return new Vec3(v.x(), v.y(), v.z());
    }

}
