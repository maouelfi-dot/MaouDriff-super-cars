package com.maou.maoudrift.network;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.player.Player;

import java.util.function.Consumer;
import java.util.function.Function;

/**
 * クライアントでのパケットの受け口と、サーバーへの送り口（Fabric 版）。<b>専用サーバーには無いクラス
 * （{@link ClientPlayNetworking}）に触るので、{@link MaouDriftNetwork} から分けてある。</b>
 */
public final class MaouDriftNetworkClient {

    private MaouDriftNetworkClient() {
    }

    /** クライアントで 1 回だけ呼ぶ（{@code onInitializeClient}）。種類の登録は {@link MaouDriftNetwork#register()} が済ませている。 */
    public static void register() {
        on(CorePackets.CAR_SPEC.type(), p -> p::handle);
        on(CorePackets.RACE_EVENT.type(), p -> p::handle);
        on(CorePackets.COURSE_LINES.type(), p -> p::handle);
        on(CorePackets.CAR_IMPACT.type(), p -> p::handle);
        on(CorePackets.CAR_SCRAPE.type(), p -> p::handle);
        on(CorePackets.RACE_STANDINGS.type(), p -> p::handle);
        on(CorePackets.CAR_TYPES.type(), p -> p::handle);
        on(CorePackets.CAR_RULES.type(), p -> p::handle);
        on(CorePackets.CAR_PUSH.type(), p -> p::handle);
        on(CorePackets.CAR_PART_TYPES.type(), p -> p::handle);
        on(CorePackets.CAR_PARTS.type(), p -> p::handle);
        on(CorePackets.RACE_LOBBY.type(), p -> p::handle);
        on(CorePackets.RACE_CLASSES.type(), p -> p::handle);
        on(CorePackets.TIME_ATTACK_RECORDS.type(), p -> p::handle);
        on(GhostRidePacket.TYPE, p -> p::handle);
        on(CarSpawnDataPacket.TYPE, p -> p::handle);
    }

    private static <T extends CustomPacketPayload> void on(CustomPacketPayload.Type<T> type,
                                                           Function<T, Consumer<PacketContext>> handler) {
        ClientPlayNetworking.registerGlobalReceiver(type, (payload, context) ->
                handler.apply(payload).accept(new PacketContext() {
                    @Override
                    public Player player() {
                        return context.player();
                    }

                    @Override
                    public void enqueueWork(Runnable task) {
                        Minecraft.getInstance().execute(task);
                    }
                }));
    }

    static void send(CustomPacketPayload payload) {
        ClientPlayNetworking.send(payload);
    }
}
