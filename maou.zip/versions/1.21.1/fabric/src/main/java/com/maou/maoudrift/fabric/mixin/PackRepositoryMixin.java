package com.maou.maoudrift.fabric.mixin;

import com.maou.maoudrift.fabric.CarPacks;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackRepository;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.TreeMap;

/** Menambahkan carpack dari config/maoudrift/carpacks ke daftar pack (resource pack klien dan data pack server). */
@Mixin(PackRepository.class)
public abstract class PackRepositoryMixin {

    // require = 0: kalau nama metode berbeda di versi lain, mixin ini diam saja (carpack tidak jalan) dan game tetap hidup.
    @Inject(method = "discoverAvailable", at = @At("RETURN"), cancellable = true, require = 0)
    private void maoudrift$addCarPacks(CallbackInfoReturnable<Map<String, Pack>> cir) {
        try {
            Map<String, Pack> extra = CarPacks.discover();
            if (extra.isEmpty()) {
                return;
            }
            Map<String, Pack> merged = new TreeMap<>(cir.getReturnValue());
            extra.forEach(merged::putIfAbsent);
            cir.setReturnValue(merged);
        } catch (Throwable ignored) {
            // jangan pernah menjatuhkan game karena carpack
        }
    }
}
