package com.maou.maoudrift.fabric.mixin;

import com.maou.maoudrift.client.hook.CameraAngles;
import com.maou.maoudrift.client.hook.ClientHooks;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * カメラの向き（NeoForge の {@code ViewportEvent.ComputeCameraAngles} にあたる場面）。
 *
 * <p>NeoForge と同じく、{@code Camera#setup} で乗っている実体の向きにカメラを回した直後（位置を決める前）に
 * {@link ClientHooks} を呼び、書き換えられた向きで回し直す。<b>roll（画面の傾き）は素の Minecraft には無い</b>
 * ので、NeoForge の {@code Camera#setRotation(yaw, pitch, roll)} と同じ計算でここが足す。後ろ向きの三人称
 * （{@code mirrored}）は、NeoForge と同じく roll を逆にする。</p>
 */
@Mixin(Camera.class)
public abstract class CameraSetupMixin {

    @Shadow
    private float xRot;
    @Shadow
    private float yRot;
    @Shadow
    @Final
    private Quaternionf rotation;
    @Shadow
    @Final
    private Vector3f forwards;
    @Shadow
    @Final
    private Vector3f up;
    @Shadow
    @Final
    private Vector3f left;
    @Shadow
    @Final
    private static Vector3f FORWARDS;
    @Shadow
    @Final
    private static Vector3f UP;
    @Shadow
    @Final
    private static Vector3f LEFT;

    @Shadow
    protected abstract void setRotation(float yRot, float xRot);

    /** この回の setup で決まった roll。後ろ向きの三人称で逆にするために覚えておく。 */
    @Unique
    private float maoudrift$roll;

    @Inject(method = "setup", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/Camera;setRotation(FF)V", ordinal = 0, shift = At.Shift.AFTER))
    private void maoudrift$computeAngles(BlockGetter level, Entity entity, boolean detached, boolean mirrored,
                                      float partialTick, CallbackInfo ci) {
        CameraAngles angles = new CameraAngles((Camera) (Object) this, partialTick, yRot, xRot, 0.0F);
        ClientHooks.computeCameraAnglesNormal(angles);
        ClientHooks.computeCameraAnglesLow(angles);
        maoudrift$roll = angles.getRoll();
        maoudrift$rotate(angles.getYaw(), angles.getPitch(), maoudrift$roll);
    }

    /** 後ろ向きの三人称。バニラが yaw + 180・-pitch で回し直した後に、roll も逆にして足す（NeoForge と同じ）。 */
    @Inject(method = "setup", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/Camera;setRotation(FF)V", ordinal = 1, shift = At.Shift.AFTER))
    private void maoudrift$mirrorRoll(BlockGetter level, Entity entity, boolean detached, boolean mirrored,
                                   float partialTick, CallbackInfo ci) {
        if (maoudrift$roll != 0.0F) {
            maoudrift$rotate(yRot, xRot, -maoudrift$roll);
        }
    }

    /** NeoForge の {@code Camera#setRotation(float, float, float)} と同じ計算。roll が 0 ならバニラのまま。 */
    @Unique
    private void maoudrift$rotate(float yaw, float pitch, float roll) {
        if (roll == 0.0F) {
            setRotation(yaw, pitch);
            return;
        }
        xRot = pitch;
        yRot = yaw;
        float toRad = (float) (Math.PI / 180.0);
        rotation.rotationYXZ((float) Math.PI - yaw * toRad, -pitch * toRad, -roll * toRad);
        FORWARDS.rotate(rotation, forwards);
        UP.rotate(rotation, up);
        LEFT.rotate(rotation, left);
    }
}
