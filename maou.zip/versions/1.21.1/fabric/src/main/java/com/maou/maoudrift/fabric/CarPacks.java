package com.maou.maoudrift.fabric;

import com.mojang.logging.LogUtils;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import net.minecraft.server.packs.FilePackResources;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.PackSelectionConfig;
import net.minecraft.server.packs.repository.PackSource;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Pemuat carpack: semua {@code *.zip} (atau folder) di {@code config/maoudrift/carpacks/} dipasang otomatis sebagai
 * resource pack DAN data pack sekaligus (selalu aktif, tanpa perlu dipilih di menu). Satu zip berisi
 * {@code assets/<ns>/...} (model, tekstur, suara, bahasa, vehicles/*.json) dan {@code data/<ns>/cars/*.json}.
 * Format lengkap: lihat CARPACK.md.
 *
 * <p>Dipanggil dari {@code PackRepositoryMixin} setiap kali daftar pack dibaca ulang (mulai game, F3+T, buka dunia).
 * Satu pack yang rusak dilewati saja; tidak pernah menjatuhkan game.</p>
 */
public final class CarPacks {

    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String ID_PREFIX = "maoudrift_carpack/";

    private CarPacks() {
    }

    public static Path directory() {
        return FabricLoader.getInstance().getConfigDir().resolve("maoudrift").resolve("carpacks");
    }

    /** Pack yang ditemukan, kuncinya id pack. Kosong bila folder belum ada / kosong. */
    public static Map<String, Pack> discover() {
        Map<String, Pack> found = new LinkedHashMap<>();
        Path dir = directory();
        try {
            if (!Files.isDirectory(dir)) {
                Files.createDirectories(dir);
                return found;
            }
        } catch (IOException e) {
            LOGGER.warn("[MaouDrift] folder carpack tidak bisa dibuat: {}", dir, e);
            return found;
        }
        try (Stream<Path> files = Files.list(dir)) {
            files.sorted().forEach(path -> {
                String name = path.getFileName().toString();
                boolean zip = Files.isRegularFile(path) && name.toLowerCase().endsWith(".zip");
                boolean folder = Files.isDirectory(path) && Files.isRegularFile(path.resolve("pack.mcmeta"));
                if (!zip && !folder) {
                    return;
                }
                try {
                    String id = ID_PREFIX + name;
                    PackLocationInfo info = new PackLocationInfo(id, Component.literal("CarPack: " + name),
                            PackSource.BUILT_IN, Optional.empty());
                    Pack.ResourcesSupplier supplier = zip
                            ? new FilePackResources.FileResourcesSupplier(path)
                            : new PathPackResources.PathResourcesSupplier(path);
                    Pack pack = Pack.readMetaAndCreate(info, supplier, PackType.CLIENT_RESOURCES,
                            new PackSelectionConfig(true, Pack.Position.TOP, false));
                    if (pack != null) {
                        found.put(id, pack);
                    } else {
                        LOGGER.warn("[MaouDrift] carpack dilewati (pack.mcmeta hilang/rusak): {}", name);
                    }
                } catch (RuntimeException e) {
                    LOGGER.warn("[MaouDrift] carpack dilewati: {}", name, e);
                }
            });
        } catch (IOException e) {
            LOGGER.warn("[MaouDrift] gagal membaca folder carpack: {}", dir, e);
        }
        return found;
    }
}
